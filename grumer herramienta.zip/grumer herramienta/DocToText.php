<?
//Contamos las palabras en cada archivo y lo listamos via json
function docx2text($filename) {
	 return readZippedXML($filename, "word/document.xml");
 }

function readZippedXML($archiveFile, $dataFile) {
// Create new ZIP archive
$zip = new ZipArchive;

// Open received archive file
if (true === $zip->open($archiveFile)) {
		// If done, search for the data file in the archive
		if (($index = $zip->locateName($dataFile)) !== false) {
				// If found, read it to the string
				$data = $zip->getFromIndex($index);
				// Close archive file
				$zip->close();
				// Load XML from a string
				// Skip errors and warnings
				$xml = new DOMDocument();
		$xml->loadXML($data, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
				// Return data without XML formatting tags
				return strip_tags($xml->saveXML());
		}
		$zip->close();
}

// In case of failure return empty string
return "";
}

function readWord($filename) {
	if(file_exists($filename))
	{
			if(($fh = fopen($filename, 'r')) !== false )
			{
				 $headers = fread($fh, 0xA00);

				 // 1 = (ord(n)*1) ; Document has from 0 to 255 characters
				 $n1 = ( ord($headers[0x21C]) - 1 );

				 // 1 = ((ord(n)-8)*256) ; Document has from 256 to 63743 characters
				 $n2 = ( ( ord($headers[0x21D]) - 8 ) * 256 );

				 // 1 = ((ord(n)*256)*256) ; Document has from 63744 to 16775423 characters
				 $n3 = ( ( ord($headers[0x21E]) * 256 ) * 256 );

				 // 1 = (((ord(n)*256)*256)*256) ; Document has from 16775424 to 4294965504 characters
				 $n4 = ( ( ( ord($headers[0x21F]) * 256 ) * 256 ) * 256 );

				 // Total length of text in the document
				 $textLength = ($n1 + $n2 + $n3 + $n4);

				 $extracted_plaintext = fread($fh, filesize($filename));

				 // if you want to see your paragraphs in a new line, do this
				 // return nl2br($extracted_plaintext);
				 return $extracted_plaintext;
			} else {
				return false;
			}

	} else {
		return false;
	}
}
