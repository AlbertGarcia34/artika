<?php
function shortcode_end() {
  /*JS*/
  //wp_enqueue_script('jquery3', 'https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js');
  wp_enqueue_script('popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js');
  wp_enqueue_script('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js');
  wp_enqueue_script('corejs', plugins_url(). '/grumer/js/core.js');
  /*CSS*/
  wp_enqueue_style( 'Serif', 'https://fonts.googleapis.com/css?family=PT+Serif:400,400i,700,700i&display=swap' );
  wp_enqueue_style( 'bootstrap_styles', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' );
  wp_enqueue_style( 'styles_principal', plugins_url(). '/grumer/style/main.css' );

  $options = get_option('Grumer_sample');


  if($_GET['response'] == "true"){

    global $wpdb;

    $usuarioTMP = $_COOKIE['userID'];
    $usuarioID = $wpdb->get_results($wpdb->prepare(
      "
        SELECT *
        FROM ".$wpdb->prefix."usuariosfile
        WHERE usuarioTMP = %s
      ",
      $usuarioTMP
    ));

    $npalabras = $wpdb->get_var($wpdb->prepare(
      "
        SELECT SUM(totalwords)
        FROM ".$wpdb->prefix."archivos
        WHERE `usuarioID` = %d
      ",
      $usuarioID[0]->id
    ));

    $res_rows = $wpdb->get_results("

        SELECT idioma1.idioma AS idiomaoriginal, idioma2.idioma AS idiomafinal, ".$wpdb->prefix."idiomas_to.preciotraduccion, ".$wpdb->prefix."idiomas_to.servicio, ".$wpdb->prefix."tipocontenido.nombre AS nombrecontenido, ".$wpdb->prefix."tipotraco.nombre AS nombretipotrabajo
        FROM `".$wpdb->prefix."trabajospendientes`
        LEFT JOIN `".$wpdb->prefix."idiomas_to` ON ".$wpdb->prefix."trabajospendientes.servicioID = ".$wpdb->prefix."idiomas_to.id
        LEFT JOIN `".$wpdb->prefix."idiomas` AS idioma1 ON ".$wpdb->prefix."idiomas_to.idiomafromID = idioma1.id
        LEFT JOIN `".$wpdb->prefix."idiomas` AS idioma2 ON ".$wpdb->prefix."idiomas_to.idiomatoID = idioma2.id
        LEFT JOIN `".$wpdb->prefix."tipocontenido` ON `".$wpdb->prefix."tipocontenido`.`id` = `".$wpdb->prefix."trabajospendientes`.`tipocontenidoID`
        LEFT JOIN `".$wpdb->prefix."tipotraco` ON `".$wpdb->prefix."tipotraco`.`id` = `".$wpdb->prefix."trabajospendientes`.`tipotracoID`
        WHERE `usuarioID` = ".$usuarioID[0]->id."

    ");


    $total_files_words = $wpdb->get_results($wpdb->prepare(
      "
        SELECT totalwords, id, fileurl, nombrefile, textotra
        FROM ".$wpdb->prefix."archivos
        WHERE usuarioID = %s
      ",
      $usuarioID[0]->id
    ));


    $total_words = 0;
    $total_compra = 0;

    foreach ($total_files_words as $key => $value) {
      $total_words = $total_words + $value->totalwords;
    }

    foreach ( $res_rows as $row )
    {

      $_pdf_idioma_original = $row->idiomaoriginal;

      if($row->servicio == 1){
        $name_servicio = "Traducción";
      }else if($row->servicio == 2){
        $name_servicio = "Corrección";
      }

      $cuerpo_rows .= '
      <tr>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">'.$name_servicio.'</td>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">'.$row->idiomafinal.'</td>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">'.$total_words.'</td>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">$ '.money_format("%n", $row->preciotraduccion).' MXN</td>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">$ '.money_format("%n", $row->preciotraduccion * $npalabras).' MXN</td>
      </tr>';

      $precio_final_pdf = $precio_final_pdf + ($row->preciotraduccion * $npalabras);

      $nombrecontenido = $row->nombrecontenido;
      $nombretipotrabajo = $row->nombretipotrabajo;


    }

    $cuerpo_rows .= '
    <tr>
      <td style="border: 1px solid #92D050; border-collapse: collapse;" colspan="2">Total</td>
      <td style="border: 1px solid #92D050; border-collapse: collapse;" colspan="3">$ '.money_format("%n", $precio_final_pdf).' MXN</td>
    </tr>';


    $to = $usuarioID[0]->mail;
    $asunto = 'Gracias por tu compra';
    $cabeceras= array('Content-Type: text/html; charset=UTF-8','From: GRUMER <no-reply@consultoriagrumer.mx>');

    $cuerpo = '
    <!DOCTYPE html>
    <html>
    <head>
    <title>Gracias por tu compra</title>
    </head>
    <body>

    <div style="margin:0 auto;width: 700px; font-size:12px;">

      <div style="text-align: center;">
        <img width="200" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPsAAAA/CAYAAAAmC74EAAAgAElEQVR4nO193W/bWJanXhfYwGrRCmlRirm2bCuxa0aY7cbW9KIXHGB7ql01mXJNTc8OahsLYReDsSV+XEpKo96W29XVTmI7dCsKTVO0qHaSSmGnu53P7sXuA/8E/wn6E/Q4D7PVZx8uL0lRJCUnTsXu1QEuYIuXh/frd++5555zbio1pSlNaUpTmtKUpjSlKU1pSlOa0pSmNKUpTWlKU5rSlP7IaU3Q+Otb2saNqqaOpj31va07G6vVu+V3Xc4pTWlKZ6QS2ubopoZY+cBhBQsYqQs0SbIFOREnWraAlk1gZB0Y2QBa6kEW9Zy5+iEqIY2b5FscOuBpZEB2kqToOCEDKMWATN3szyqWk5N+pS5VzTNPNmvVPTUnmZCTjMjEyoZzVp4rv/1swD3/GAqv1qHwux/C/KsfAvfqgxOvvq8+LM+/XMfPX63D/Mt1eO9/fww/ePjpRphX6fO9ypXmL4FSTMjK3chES12Yk44HZy1nFC1v3dmYEzrwHekxfEd+CDnhEAq1+8BKbWAkE7LSI6DkR0ApJkzCb626o7KiCbiNE5JoxSfJgILUgoLUAlawgBUsyMv3Y/ulIBhOodaDQq0HXE2HgtgGGhlAKSZQiuEmC7LIAkoxgUYGsJIOBcGAvPDQYcXHdkE8qpQnHL+XlspI45Zr+zYrtYFGGMCMZAEtdYFSLKAUDDhWagMrtSGr6EApBtDIAEYycV7ZAkYygZXaUBQ0Z7V6t5L0TQ51+JxkAi3HJGS4SQcGtXGSdcgiE9L1LmSULuQk3KnXRKO/KLYSvxekteodlUxUuPyhJHfOBHb+YYUv/ebHsPD8I5h/9QHMv1wH7uU6LLz8CHn1fbmuFV6tQ+7368D8r3XI/e4jWP4/fwvvP6lwYX4ltKNSigGzcgdoqReZsvIxUNLXsLh1ODJZnJUK4oMTRjK9iZ1MhDTCEyye3C3IKjqUkZYex29Z2FGzKKJdR5KVkExgUBtycgsKog7zgg55tB/bL6xsOGRSYKU25CQdcmIXGKkLWWRCFpnAiMeQE469xQpP7njSYdx6F0QdlqvayWpV++OSWMtIS8/JHS2qI2gZNxClmJBu6EDV28C6My2NMOB9sMck2bLjvp13wZ70PgE8BiYGZxaZkFHwJJST8QQwUz+Gmfox0OjwtIS2uXH1Xqtuq/hdI3KiYdDZwP7+4/+irvz2Uyg+/wgWXnwACy/WoXRyE95/8vdeWbiXH50WXq1D/ncY6PlXN2H+dx+fRvErSZqaRRbMSke+ZBVKBOxc1TyJ4jEpcchOx/c/lqxIP2QVHUrCNj+OZ1HaUTN1ty2T+lc2vYlkNGHJMSfpMC8YMC/owKL4lZ2RO05OtIAVTW9c5MQu5ISe972ccAyM6IJ93NiVLMhJD9U3adsLQ6tVrXxNOugnAS2r6EDVdUg3DMjUceNg8QyLu+M68ioy4sHePOBjV1aPBxa7hsRXV4JgZGNopU/X8Qyel1uDcYD/7uaXKie08Op1DmBf/fVPnOLTT2Hp2Uew8nQdVp6uw59/9TceCN9/8vfcwvOb7kTwASw8/xgWnn8Mi69+VInityJrJxTqQkbueKvSaLKAEXvAVa2JVts4YpFZeZdgj6sfIxtQEAyYr5lQqHWBFbrAoPjtVTTYLQx4yfAWCkoxgarrkFXaYwCPV3uuFj+GLwWtVvcqnHg4mGRlzbr7HiyWkf0U3nMlvctKOiyi3VgRk2l2+HEzK17FepCVsdhKSz0sbokY8Hj/ZUHGTXhPZgKNDiNXTELnCfbySSVdPPlPUHz6CSw9vYnB/uwD+MHjH1dInu8/rlSKzz6G4vMPoPh8HZaefgJrv/4x8CeVSJAW0a6TrlvwHeUAqLoemWiERdCCYMJi1axE8ZmE5mTz5ExgF7fHfqso7b052N26zdcsYIUe5IQe5MX4fhkCu4S3fp6YLhnu/t2AdMOAdEOHTH0CydQd59fEDor77oWmItL4haoO87VxgHX3MWIX74NEPNvSyAdIUiMt1u4lKnMY9IRnpG6yGCWS7+OUE7vAiD2gxUeQlR5BRulBRul6YM8oFqTrXZipH8OCdF+N+/aa8OW5ifHLLz7dWHr6CSw9/QSKz27CAhblB0Egv/+oYi88+wQWXqzDwvOPoPj0U/h3jyuxK8a1xu3Tf3XrAL5Tvw/Zeisy0UrL1WMYwMj2mRWKqRTexiUDMXJlV8fxLUp7KqVMAnZXcotItGwN7adZwYLF2gQru2Dh/brc9vbu/pbUgHTDhCtNC2YaFkyiV6BlCyh0PCgj+7Wlp3dCS0grs7I+KAgGFIQJwC72gKva/dJm216r7qg3hG11WdpWi9Keyon7J6ysn8a9f716N3EvyaB/4ukEsBcEw1muPlDXqppa3ryjljfvqGubu87y1oM+WzuGrPRVItivSQf9uG+XhG2VkfWhiet1wV58ua6tPL0JKycfu+L5R7D08oMhIH/3q58MFp59AtyLj4B7cRPmn/4N/PnD/xYr9bD1O/Cvmw8go9wHWmlFpmy9BVmljbXMqAuTnoIEaUlsRYrwbwr2ZWE82FlJhwVhH5aq9yLTypabqruwUr0LN7buwr/9h9sJYLccsjD5YG9BTm5DFhmQQwdqUdLUorSnLki/VFn5gc3KhjNO6qAUCyj5GIq19uVa3Rdq+mlBMPCM565sURWdkzuDOflIY5DNjePJITvNIrMSFgev1+4kNs5s80ki2IvCL9W4d0vCAc9Ix/2s3HXF+K6ntMP7PR3mxRasVh9EalTXqjtqLtCpbwL2hVd/0V95uu6D/emHUD75jzx5/v3Hn5XXfv0pFJ99jIH+4mMoPN+InYhSqVTqGtKAQW2gpQcB5eRwyiIDZhompBsm0EiH1dovzjwYC8K4wT4K9hXhF2MVguPAnkMd9axlHUdhsGNNPj7FoertWCmTQ3Y6hzpqVP0zdbzHz0k6/MnWLxK3hheKOOmBWhBMVyQ3PPEGH3PpXsrLbed1VolUCh/hLdb2bVY0xq40s02b95RtEakk7KlJ75fQAZeXDgfe7BsAOjk1uCbqkQBYq+6pZN//JmDnn2xwxRd/4SrlbkLx2U248ZubQ0C+fnITLT29CQvPb8L8y5tQeHkTCs//WovjyX1uc9ekB8BKOsyJB7Htk0VEHMUKqeu1O2cajByyOe+IKwrsAfsGRsJbuKyiw5KwPbZtLgrYsfSmJ4KdUFH4pVoQDE8fRcumN6bmBR3e+8fbE9kYvHMqIzWdR/sDIpJg44MuZJEFmboBVGMfsvV7cLWxfy6axxI64MblmW12+CQx70Y1GeypVCpVFPe1IVEcYa0rEePy6EEkjxvVPTUO6GcB+/efbFSKL34IxefrUHz6I1g++RG8//hvh7658vRHzsKzvwTu5Qf42O3lh8D9fiO2ffLNDs/KHSC2C3GJUvC+M1PHg3NeaMMSmvxsmEU6SjwNkQ1fL+CefdPobGDPotj2VcfxOCuNgF329+pZNJkx0FKtNSD6qZy7lWWFLnBbPVjaNOFSGNysCf9DzaF9SNctyCg9YAUCdvcYot4CFu19q0cM447eblR31HE8StW9ClZQRaccOozksSzsqVgJ9GZg//ePP7WLzz8A7uU6/JtnH0Lx6YfAh4xklk9+BAvP/hLmX30Aud+vA/firxJX4Hyzw8/JNlZESt1YBRaxBMsi3xKNRoexEkOY5tCD03Fgz8lYFGYFwt8ATtwdC5yLA3b32BZZE4G9tLWPeYjuEbPYBVbowXz1GOarXcijA/68y33uxMl7fRq5yhzF70gGtVxFhtn/trWNRXSfZ8X4wVYS7qjjeCyJd+PBLlnAoGijCA5p6kwD7/HfBOw/ePjjQfH5RzD/8ibkX/w1cE8/HXqPf/gTfuW3f+WD/Xc3YfU3/pFcFOXqh+qcbMOc9KsIsB8NfG21CayIz6IJGBkUr5QMUglpXNKx05zcGeQkn/98DQ9+fKypXzqwU8pkYC8K+05W7gWOlvHpT060gJF1mG3e58+73OdK7K0HZWLx5qe2K6Ltw7zYgrXNDv9tl+s8wF4UNS0O7LRswdUYsC9I5wP2D83/Wnn/8Wfqnz35TP2zJz9Rv/f4H4bE6A0bpf/Drz5Tv//w79T3n/yd+t2v//NYJVoy2C3nKjrqB8GO29A1MZV1WBO+4Me2W01DicdismUzrhiLz/Lxd7LIAgp1gVOTF4Z3D3Z/DGCwTybGzwttoFDP2wp6th4y1oucd5nPnTLNI5XYtkelBXF/otXgvCmPksX4kpAsxpeRnb4m6YNkMd6KPN66UT0fMf5t0Fz9UEtY2TW6foT8/7G2OOMqklhJh9Xql2O3Y6x8P16ElztODlkbtGx5x5pEF4IHfw9m0T/xSfzfLdi7nhENNsbqQlYZL40UaxpiJKyUY1ALWHkfWEnHq7zQg5Wt9rk4Hb1VopSeQynmkOdYcM+XdMT1NolpYq+32KM3Kb5cZWSnWcE6zbl7y6jESu1YM9K16o4ad8b+rsHOIMOJA/vV+pHKfG5zYcvBdAMbjLCiAdere4mDkvn8IFGEZ5FZyaMOT8Cerlue01NOtLCtOXrCJ32jJOypcUAfTfFKSDIh59GBOrbdIsGOTawZORnsS1WtPCd3sAJbMT2pNye3XbPwLlzf2n8jH4RvhVix1yfHJhjsFtDiV0CLXwGlWFBEGv8uysUgrI2PS1EdXEZaelHUKpzU6uNZN35VLwpaLGBLwh2V2EZfOLArZiLYU6lUKossJyt3gZKPgUI9zysRa+V1WBTizZSx4xP2Bgsfvc3JnYFrN1EmYjw+gsLn7ayIj24ZZFeS6jAp2ImVZlTCYDc9g5ix7TYixuvepMFI0WL8EnpQ5sQHNjGbphR8to59Qfzj6Exdh0V05429C986zVfJTOeu6nIXaPFrD+xn4bWEvizPNvcdBh04jNxxZpWOk0WGUxDbTl5uO7ONAyfd7DjpRs+hlJ4zJx/FaocZZCeCnZZNzzyXGM6Qc8+cpLt7KhOGzuo95ZwJJWGHj/v22wQ79/kTflbo8LPCAc807/NM84BnUIdnUIfPNw94Xk12WplTzMGcbMOcbEPYEWi2afOpVCqVrZsV/Dv2F/BcgcnePcEBiZHNPu0qngjgPVDIR7afz/COoMjxleeHHnPKQei8wc7Uzwp2/+jNHx+W6y2IeRPPQdyGXQ/s6YbpOX6RcqYbxjvZ6p6ZsCbR8Jxassjy3SSRcSawF9E2n27oniNB2HDCM3BBeEVK9FIas7IzsgEFsQ0F0Q2gIHeBQngPRjqPko+B8hxkLN8bDx0l7ltvVPfUxG+/AdiDK6ZngebyzSrtsV5jWMQmA950+6sHFOpB2gU7p9ppfyAHrRB9X/CoLcwSulumFMN7Lyf0gBGxoxGFupBD9oZfjnbANt0Xq7PIAqZ+fmCPC17BSHj7QNX11wf7yGQecJ/1vo19LmjZ8lZ1yl3VWQFvW2abyduWC0Frwg4GFDF3RMNKk6vobDNWEe3w6YYOmUYLqHrb5ZXgj5wE9uZ4sLOS7mmb8UyMB6bv090DSj72fstJJnDCg9NxLp83qppKRNTzBjsePJY3+XntjfAgKqHJwe6BWMTHQfmmv+W6igzbXx1H01JEMA9O1jSyYmGnEexNlpW7wITGwlXlwSkj+Y4otNQFCnVdBdZBYvtMAnZGCkgKESk4WU4mxg87wiT5PpDve9sSd8UngVpo19S2IFjAVZO3LBeGPLBHJLwKd86kYSyhL3iqsQ85dA9YqeUdb7wu2ON9tfGKlkHHkEGPhgBOQE5LXU9sx2JuD3KyeTKJb/dFBfuasM0TsOfELhQEC+Zr2M1zpTpszEI1DjfiwE7LFuTF0aAWOdnsZxGW9PAZuul5MxblnaEt16xiOG8f7NFhwYL+53H6mzBFubiOA3tBwPWjEPat8KRDuQUsag8K4lFl3HcvDK1W75aTwJ6pT3b+SKiEvuBpZR/HBhP9PfPbADuljAG7bPmODsjuM2jyjrk8YDfdKC0GvLf585G+YuXDQVJoJy7gyISVbpYHMhJ/rSDqkJNbUA4F/JitH50QUTcMdhrpiVaAk4CdlXRYqu3Cja3bkalUve16vO3CWnW8p91I8IoJwI59REzPkYqRTOCEFiyL23a4PS4FJa/s4x1WgoQHYzDcTzxg3hTstOzHCAsGssCp6/Jvw9UJ9nNhuqhgvy7c2QiL8TlJh4LUgj+p/mxECiuK+1oc0HOSASzy3TJZ2dBwDEF9KKgDK7WBRfsj4L2KbDUB7ImLxDiwv51z9jOCnViRyjo+0ZCPgUaHg9d1ArsQFAtGV4N7lkCN36uq5dLWjlPabDtLm4aTFzsOjTqDtwH2vNx2SsIdtVS93Z8XsDMG0Z7iwawDrbSAqrcH6VuPzxQc8G2CfTiSzijYiwlgvyFsq8MKOmzQkpNbsLb1xUiZVqtaORLoRCnb0DwQzyF9kJNb2MebhBSTDWBQG9j66BjIIVv1lWWXH+wM6qgMsmxvvCIDsgr2dacQVoDSyIAFaefyuLKGiUEdx1/NfUMFMrMVxAdvZCwQ5H+eYC9Kvtfb9eqdk5xkQgY9ggx6hPeb0j7Qyj5Q9RZk6p0zzcjjwE6js+kyCJUEjScnA3FgX0LxcfaHwC72gJaOPd3E2tbPI9uSkY/6UYDPIgPSzRakPz/gqIa1kUWmG+Fm3wW75TlCRZm/FgRrIwnsSWLuRQM7I/unTiwyyzTqDHDgUgvSdcuNVuybIHO1g8sZd45BBzaNdDf8M/H9Nr242aykD+3tzs7/zcAe927QXLaMtPQcOhxk0DH22pPaUJDuQQ7dg2y9BZm6CYWEmOJhem9rdyPJxZWWzdeK/LIotipZuQdElPfOp924feNWxBXhyxO82pB48e6xomzAanU7cgAyyFaHJAHZ8oA8c6sN6Z8aGlU/sjGwcYQbYvqaRRbMIT1yss8jm08C+1rCEeJFADuN2tij0zX1DeZl0UEli0ygUA9HO3KDVNCy5YY9+xoWhWhT6wtNhcb9Dbq+C1TjHr5gQbHgyi0ceC8nYQVNQb7/2qt7EtizY4/e4pVLYX/2bP2gQoL9Z5U2MGgfCtI9YKU2ZBA+flupaRNFaylX75aJKBtX9jhf+OS2MBwK9bx4AYTXfLULXNUCVko+6izKqpO+dQ+DtGEChdxourIeq6Ri0BOOEfF5uQdG2bd8o+oH/Sw6HGSJ2KrgCEXE9HVZuB85qFn0P8s5oXdpwZ6tt+DKT1swc6sdaS5Lo84puVTCP+YzgZaOgan9GvLCo8GbRO19J1RGWjqPdgbZ+j6QSLFXbukw09S9cL0FqQXXazuvFWPrbYF9raqpI+8oWj9bb0GmgQdtQWoBKxq+eC93BpMGGLgmHg6SA1gY/XHeXUHKNzU+U8fx4FgBH5uRlb0gmMBVTciLh4mTalH8uQv2Fsw0dQ+42Jvty5H2IMQK1ql/oYcfsHHkRh03kci01wQ7cbtSEOJX9qQwWBcG7LfacOUWtqQL5y+i+/x8tQuF6jGe9JHuSlQ9z8L0KkrurwtJpapme+F2kAGZRhsyDWzkj0Px4FBOS6JWOSvvtwf20Ug1i+iLjWx9H0fXUXyrMWJsw0gWcEJ7InGeEw9Pkm6kySo6UBNG7uGQlqaV+6dUHd+UQww60m6MOBw3oAXZ+oNKEp8bm7tuGCU8oXmipazDe8IvYsXKRbFV8a85Cobpivd2zEkGFGvJwS5WtvbjV/aE47CLAHYatSFTx8dqtNSL3D4VhI6TQcdeW5E9PjFPphQTCki/XOJ8GWlc0EGAhCP2j7ZMz42RRvrJWVa0WLAjA7JKvPHF64A9lUqlZhv3HdKJ5M6zYGIkC1g0Po76e5t7lYKox4MdGUDVW8Ch24mA51QM9KyCAxtSdSx1UHUdZpp4u0QrLcgjbaxYuLJ1DxjZAKreds2Rgyt7vNhcRlo6Uze8SXASsBekFpTHXHF0Y+tu//KCHTt9Ue4JTtQ7RXSfxz4XJgwF1hy6L6EzOAseLgSxsqExMom66YbYVbDo4ltKYVvhvGgPuJplL8VEZw1SFhlOOAqpH430LYC92eFxeC1iSTdqcEOhyfZby1WtHz0gfVtwVjSgtLnff29zb+jSv5Jwn6fRoZZuHA4ydd0DOQF6pq5DuonBz8gGlKpa4qRRQhrHyveAVlqQbhgw07CG9+xjbOqpxuEJ1iz7wTeTwL4g7I49Ylrb3HFixfit+Fh048CeRR0n74Z2Lgl76nJs0tRlAYd/Lkp31CX0s0rcNyO18TIWy7PSo1jFKCu3bay518Efx7r/v6LDHNqfONzXhaAy0tKsfP+UQX7wfPdGVA/sZK9XECysYCL26Mh2riL75CqyVQbZKi3bWhZZThZ1PKB/W2BPpbAiLKNY8WCXHwEntseK4Ne3djdiwe4a8TAiVrbN1ywoCO4tJVUcm4xCPXxsUzcCYNe9lRVvl1pAI33s5MM0D/ic3AIGtSDdMGGm0R0C+7i6LKLdDUoxYKbecx2RksG+MibUdyr1+mBfHgt23yQ6OcYenvDwdw2YbcZf7DgKdvdOQmTGruypVCpVRtscJ+5iS0xXKiJWhngctyGHdqGExkcAulC0hLTyHNIHRBPt7SldMX6mqcPMrfZQVNFRMTl4zGOOAPz8wD6qoCNUQhoX9N4KOsjkRAvHTRPaE/nq08g8iR+Ulmd3T0s9N/hgDxY2e7CweQzz1WNghZ5noEG5ondW+gqy0lcYtLdaQH0+XheSRx2eq+LJhJwBnwXsqVQqdU3eH6SVnucdmAT2SY4W/ZDbEWCvxsdRHwf2sAQVZ26N/ehN8AyVULw+ZkSMV/Yh27gLVGMfaDnZlXu1+nOblVrYbBYdQ8ENMMnIuhfI4hoaLwldOFpCD8p5WR9kkeVdiEh8h2eaBly5hUVSGiVffDe0B5O9/X4gGk4y2GfHHr3Fgz2Vwl5fvoLO91PGx4lYermKrLEdhCWew1MShZSEewp6ClIIB4pghEdQqD6C+eoxcFs4zVd7rlstFgVp2QJG+Apo8WugUBeuNsZLGKlUKsXVOmhx0wKuigc63oO7579In8jIZ7m2a1OITH7DYMeiKe7Xq/Xos/UwrVV3VM/F1QM71lwvCvFx1JeFncSwVN64GXLLDTvzkAsYdWBFPAlOcrEjsWfI1jHYs/V7Y8HOIy09h1qDmYYJaaUHbA2DnZXakEP7brvpMFePvofgQlMJHXCzSuc0o/TcM2p8To2vUyIDxXIHSTsm6Z6LK1b04UCWmQZWLmXqOlCN+M6ZbdqJRjXLYy6JYJDNkRVgCKSByYeRDSigg8q49igjO51Bj0+J0Q4xOiJBMvB9X/hyyaz0CJ/Fijj5oYddmwXBcG8d7QEjPprYEosTjlQMduz3PnOrDTNNfINu0qlGkFarX5aDd5vRgf0ng9rAyvuQk1vA1Me3CeZ317seKovcMFh1LMXkUPxdfvgW1+it3UhKUJASXQgrtXBcg0Sw2w721+ji8ddoe5c7xmnjgzT70wN15hZud3wLjAHz0j0oSPveliIvtwZlpF4uZR2hHDpSKXQ8IBrL4dSNBDuD2uArNCwvmARxK8wqGOzphgGzyniwx6VxYE+lUqk8OlSTHGlY0QDWDbU0jheH7PRV9PAkg46x6CjrnoUhjQzvHrm00nPP9Y/x3lj23VG5mgFcTYeCqAMXcxtNHBXkjjZfw5FcqToedFdu4XY8i60+Kx/0PbAHxGVGMoGV2sBJ+xObAq8JO7wnPXlgx5NRtt4C5vPoy0CK0s5EFzsmJXLrKlVvu/HgWomutYxsOzjIRxfSDdO9YtxyLwON37MTKqt2+mpTH6Qb+JZcBrWhIO2DJ94rPchJOlwXf3G5lHVBwgEMj7QsOhpEuqmGOsEPLmABLbkTg+sjXRDxQM8iA2aVw1OmHn8ENi4s1SQ3wpSRnY5zxCFKx5xoQQ4djeVF6Cp6uJGTzT4OnIFneAy+Fly5peMrl5RHkFYeeTey0BIW/Qq1LlwTDZub4Eac0fY4cMj5PLltlGjWc/Kob3oc5dCRShSMjNgDRngEWQnHHGTEYyhVJ7/1Z03Q+JzYjdizu2GwmtEhyEvCnkq2aHGRaMYlMsEQwFONfZhtxscVnFU6TrrehZkGTuR8PSccQ04YD/ZUKpUqNo/RbP2xt3jRCCuxZxpdrPhUTMjJLShdRvfXMF3f2t0oVffs0tZef7G2PxyTfCR1PTGWE9qwUts9LW/etsubdyuTKH9Wq3exB11M+t6mWpmozLUdNPRu7bZTqt12Vrd2nLXNXWd1c9cpbe2e2YutLGzzf7q5a5eqd/s55TZkmrtw5actuHLLwKu6fIxNWus6cDX99Po/trXy5uu7R65u3dFKtW2nVNt2loQdpyjsOovCrlMUdp3V6t3KpHxK6IBjRVepJfQgJzwCWvwaGOERcFUTvlf98kwegqUtzSGpKGhOUdh1SsJtpyRsO6sxTj3f2/xZpbSF231184xpa8dZ9fpyF7eFuO0UxS+covzfY1fVJXFP40TN4UTNWRQ0Z6mGy7y6idOk9S0j8+RPa7vO2hbuh0W3HxYFze2PHWeSk4xLR0VBI8ES1XDKIWsjjx7yS1XzTIPnMlIZqel8c5uf/fw+P9vs8Hlk8xyy+biV7V3TsvBLNY86al7qqAXB2sgjmy8Kl+DqoilNaUpTmtKUpjSlKU1pSlOajAAg/c/wz9y7Lse5EQBUAOAEAJw/wB+cb+AbGwD4d12ucQQAZYD/6wD8Cx/zPA0ADgBUzvGb58rv2yaAPzgAf3jt0Fq4zcEJpj8AnHwDoAIAdz5lBAAA9Tx4Tfi92D79Br7RvoF/gfOq2zslALDdxnUAd5gKAP1vu8FfhwCAd8vZB4CR83J3AjvXerjtw58Xv2+bCEDf4H3S5k4oDdzEn0MZv22wR/ZpoK6Vb6ssb43cSkZWxl3tIw1OAIB7nZnOXWn5pHcnyXu+8/EAAAVYSURBVBPISzoDAEALPdsIPFMj3i2fJ2gJv4Q2G1snN0/sCYbb7hO1TeCdofaMA/uk7UHaPOY7/Rjek9Yr7f4/0meBesQaQU3QB4nP4/KPyTPxeH2n5M7EExlSEEC5gwXIbBjT8V5nBWdHGCYn2Ohuo9kReZIGCeFNJi0+wGsA7tYkOHDcDuwHvjEAd7IDABTkE/qt7P4/jh9AYOIBX7og1A/WyeV3EuLRh8DgAX87Em6bxEELuL+CdAIApxAAZEx7xAZlgJg+d5+pANAP/F9x+cXVPapepC9VNw8Ho+07VHe3DqehPFroeZhH8DnAcJ9vRLSJGm4DGO3bi2lBFygwP2H+YIdVwJ+NJwW7N4jcxhzA8KBzQnl4twP7kLxagvu3l9fthAH4g4mUhUwCp275gxMM5+ax3Txe/SAg+STxc39D5H33/0qgTmRQ9kP8AABQoE5Dk7D7zin4kxnJEyuOQwA0bjk58AHhhMrvuH+T9vDKn9Tmod/Jyn7i/s+537IDvE9JvyT0OZkcgm2MwJ9sKxHPY/vATeE+D/cRBNq2HCg3yU/aMthHQPoEhscRH9cn74wCBU5H/OZR4BkEOyqYP4J3sDMiJ5VAp5UDDbwRykN+ryTVIZCXDFyPFwyDk3wzHeIzgOHBQ8A1IvmE+KEofhHlJBMHT8oQ4hf+hgY+IMl2pBzKE/l74Hk/gq8H7rjyB/JEWoLBsDRFkg3+np2A0obApBZoB3DLTv6uxPGP+J13+9lOqkNEWw7inrt5AHywn4TLHajPIFTG8HgdKfeFIIgAIfj7D540YuAZwOi+eGKwR+RJk+/H5XHzncY1YPi9QMefBH5zAmVRwZ8QgiksZZBJZmSQhPidQPLqGhRTieQBoTJ7/AK/qYHBrJJBFsE/dnC5zyoRvzth3jHtEceXjBuS9zTwfzr0nSjeAIEtYLh9w/WC4dXeCf7tPvcmxpjyOknPA9/jA/lH6g7u5BpqAz7iW5Ht9s4JEvbsMAqkkYEV12ERnRWVhwCKD+ThYsqohn+PKqP7mx0x6EhZyODmI1I5xIMMqkqIf5CfBhGrQCAv+V6Qd7hdRwYIjII9qv3SUeULPB/pL/f3UxgFe1R7cDF8o9qcbJvCuojTON6BPg9LLKReqvt/3+Uf7NNw+yT1wQkAJMYuIOMwUO4R5yIISGRwScFOBtKIyEaeBf4fGTzgAxYFfuODeQP/h0XK4L7aU6iF8gwpxyLKGCsRBPI4gbJEbgvc75B9ZIV0JPgiYHgQh+sWyc9tw9OIZ2cBO+d+IyxV2ZAgnoKv9AuChNSN8I4rfyUVQ1FtDv5+/TTQjiN95+YLjpWoPrdD4yeq7k5EHVAoD+kDUudK4Bn5Paj9592/CSbC5e6Dr4+4fGBPpYYa9xTw4NbAFzfDGks14n0ixtkwvCKq7nPSMERJogbeqQT4kE4heZy4bwbeORPYQ/W1A2UhqxvZ96uh9/uBgRHH7wR8G4WBy2sj9IzknRjs7v8EOE6obSqpGArUZQC4T8m3w1uWuPbgztLmEFBsBX47DXw/2Dac+5z0eT/wbTI21ED5gjwIz6g6jPRBTB3D5QAYPskJjmky4QfzX06wp1Je4TXw91VquLMh3vAgHXjXdjvdyxtomHC+KF68+yw2Tyg/N65x3QHFR/x24n5HCw2+8ApBVmj+rPwCdQo+K8PwZBHFj4doxdXEbeO+w0X0TSWCd2z5Y3iqMc823LYKShMoNK7C25FgvbRwe4d4nJD2OmsdxvRR1HgPltuT/IJtEPMNPvX/K8EEq++UpjSlPwJyV5PXNs+c0pSmNKUpTWlKU5rSlP546P8BoVCa0fn7PvgAAAAASUVORK5CYII=" />
      </div>

      <div style="text-align: right;margin-right: 70px;">'.date("d").' de '.date("F").' del '.date("Y").'</div>
      <div style="text-align: right;margin-right: 70px;">Folio: <span style="color:#92d050; font-weight: bold;">'.$usuarioTMP.'</span></div>

      <div style="text-align: left;margin-left: 70px; margin-top: 40px;">En atención a: '.$usuarioID[0]->nombre.' '.$usuarioID[0]->apellidos.'</div>
      <div style="text-align: left;margin-left: 70px; margin-top: 10px; max-width: 570px;">
        Gracias por realizar tu compra, en breve te escribiremos para tratar cualquier petición adicional, resolver alguna duda contigo o bien para confirmarte que ya comenzamos tu proyecto.
      </div>


      <div style="text-align: left;margin-left: 70px; margin-top: 15px;">Concepto: '.$name_servicio.' de '.$_pdf_idioma_original.' a:</div>

    <div style="text-align: center; margin-top: 15px;">

    <table style="border: 1px solid #92D050; border-collapse: collapse; margin-left: 55px; font-size:12px; text-align: center;">
      <tr>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">SERVICIO</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">IDIOMA</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">Palabras</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">PRECIO UNITARIO</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">PRECIO TOTAL</th>
      </tr>
      '.$cuerpo_rows.'
    </table>

    </div>

    <div style="text-align: left;margin-left: 70px; margin-top: 15px;"><span style="color:#0070C0;">Tiempo de entrega máximo:</span> '.tiempoentrega().' hábiles</div>
    <div style="text-align: left;margin-left: 70px; margin-top: 5px;">Forma de entrega: Word y PDF por correo electrónico.</div>

    <div style="text-align: left;margin-left: 70px; margin-top: 15px;">
      Si deseas más información contáctanos a: <br/>
      <a href="mailto:ventas@consultoriagrumer.mx">ventas@consultoriagrumer.mx</a> o <a href="mailto:fernanda.toral@consultoriagrumer.mx">fernanda.toral@consultoriagrumer.mx</a>.
    </div>


  <div style="page-break-after:always;"></div>

  <p style="text-align: center;"><strong>Calidad en el servicio</strong></p>
  <p>Nos da mucho gusto poder trabajar con usted y contribuir al &eacute;xito de sus comunicaciones. La calidad de los servicios ling&uuml;&iacute;sticos depende siempre varios factores. Nuestros servicios est&aacute;n dise&ntilde;ados para documentos profesionales y para documentos personales. Recuerde que los mejores trabajos son aquellos en los que un cliente nos proporciona sus listas terminol&oacute;gicas, glosarios, manuales de estilo, contenidos, borradores o materiales previos que contruibuyan a proveerlo de la mejor manera posible. Pero sobre todo, los mejores trabajos son en los que se nos da el contexto y las instrucciones claras.</p>
  <p>Nuestros colaboradores sa&ntilde;alar&aacute;n trabajos que parezcan ser demasiado especializados para GRUMER. En ese caso, usted recibir&aacute; un correo donde se le avise que un colaborador encontr&oacute; un problema con su trabajo, y que necesitamos que proporcione m&aacute;s informaci&oacute;n para completarlo, o bien, una invitaci&oacute;n para que reconsidere el asunto. Los colaboradores tambi&eacute;n se&ntilde;alar&aacute;n trabajos que parezcan tener una cuenta de palabras incorrecta o que tengan otros problemas que condicionen la correcta traducci&oacute;n.</p>
  <p>Si entrega contenido que no puede ser soportado, que es compatible con nuestros softwares, o que el archivo de origen est&aacute; da&ntilde;ado, se solicitar&aacute; que se vuelva a enviar en el formato correcto.</p>
  <p>GRUMER no garantiza y no aceptar&aacute; ninguna responsabilidad legal de ninguna manera que surgiera de o en conjunto con la precisi&oacute;n, confiabilidad o completitud de cualquier material entregado por nosotros. Por tanto, GRUMER se deslinda de todas las consecuencias legales que deriven del fin para el que el cliente o las personas que posean el documento lo utilicen. Favor de revisar nuestros t&eacute;rminos y condiciones legales para mayor informaci&oacute;n.</p>
  <p>Una solicitud de rechazo se aprobar&aacute; si vemos que el trabajo no cumple con los est&aacute;ndares de calidad de GRUMER. Todos los clientes tienen la oportunidad de revisar su trabajo antes de que se apruebe. Si el cliente no revisa el material dentro de las siguientes 96 horas naturales desde que entregado, el trabajo se dar&aacute; como aprobado en autom&aacute;tico. Si usted considera que hay problemas de calidad con la traducci&oacute;n, puede solicitar correcciones por parte del colaborador. Si hay problemas graves con el trabajo, tienes la opci&oacute;n de rechazarlo y pedir un reembolso total o de pasar el trabajo a otro colaborador de GRUMER sin ning&uacute;n costo adicional.</p>

  <div style="page-break-after:always;"></div>

  <p style="text-align: center;"><strong>Acuerdo de confidencialidad</strong></p>
  <p>Grumer Grupo Mexicano de Redacci&oacute;n, S.C. (&ldquo;Grumer&rdquo;) es una persona moral debidamente constituida de conformidad con las leyes mexicanas y tiene por negocio principal la prestaci&oacute;n de servicios profesionales de consultor&iacute;a y asesor&iacute;a en redacci&oacute;n, edici&oacute;n y traducci&oacute;n de todo tipo de textos y en cualquier idioma; as&iacute; como dise&ntilde;ar, editar, imprimir, publicar, vender, importar, exportar, consignar y distribuir toda clase de libros, cat&aacute;logos, reproducciones y todo tipo de publicaciones, incluyendo, de forma enunciativa mas no limitativa, todo tipo de revistas de inter&eacute;s general; as&iacute; como cualquier texto susceptible de ser editado en formato digital.</p>
  <p>Considerando lo anterior:</p>
  <ol style="list-style-type: lower-alpha;">
  <li><p>Grumer se compromete a salvaguardar la Informaci&oacute;n Confidencial a la que tenga acceso con motivo de una posible prestaci&oacute;n de servicios a un cliente determinado (&ldquo;Posible Negocio&rdquo;), impidiendo y evitando su sustracci&oacute;n, destrucci&oacute;n, ocultamiento, inutilizaci&oacute;n, divulgaci&oacute;n o alteraci&oacute;n total o parcial, as&iacute; como su uso para cualquier otro fin no relacionado con la posible transacci&oacute;n que Posible Negocio, manteni&eacute;ndola bajo el mismo nivel de cuidado que le aplicar&iacute;a a su propia Informaci&oacute;n Confidencial.</p>
  </li>
  <li>Para efectos del presente Aviso de Confidencialidad, se considera como &ldquo;Informaci&oacute;n Confidencial&rdquo; toda aquella informaci&oacute;n proporcionada de forma escrita, verbal o gr&aacute;fica en cualquier tipo de medio impreso, electr&oacute;nico o electromagn&eacute;tico, que se identifique con tal car&aacute;cter y que, con motivo de un Posible Negocio, sea proporcionada a Grumer.
  <p>Dentro de este tipo de informaci&oacute;n se incluye, de manera enunciativa m&aacute;s no limitativa, propiedad intelectual, derechos de autor, secretos industriales o, en general, cualquier informaci&oacute;n que, de divulgarse, pudiera ocasionar un da&ntilde;o en la posici&oacute;n competitiva o econ&oacute;mica del cliente, y respecto de la cual hayan adoptado los medios o sistemas suficientes para preservar su confidencialidad y el acceso restringido a la misma; as&iacute; como aquella que se encuentra protegida por la legislaci&oacute;n, reglamentos y dem&aacute;s disposiciones legales aplicables, conforme a los cuales ning&uacute;n tercero puede, sin autorizaci&oacute;n previa, divulgar o utilizar la referida Informaci&oacute;n Confidencial, en provecho propio o de terceros.</p>
  </li>
  <li><p>Grumer no tendr&aacute; obligaci&oacute;n alguna de mantener como confidencial la informaci&oacute;n a que se refiere este Aviso de Confidencialidad cuando la Informaci&oacute;n Confidencial encuadre en los siguientes supuestos:</p>
  <ul>
  <li>Que se halle en registros o fuentes de acceso p&uacute;blicos;</li>
  <li>Que se halle en registros o fuentes de acceso p&uacute;blicos;</li>
  <li>Que previamente a su divulgaci&oacute;n, la Informaci&oacute;n Confidencial fuera conocida por Grumer libre de cualquier obligaci&oacute;n de mantenerla como Informaci&oacute;n Confidencial, seg&uacute;n se evidencie por documentaci&oacute;n que posea;</li>
  <li>Que se haga p&uacute;blica durante la vigencia del Posible Negocio sin que medie violaci&oacute;n a este Aviso de Confidencialidad, o</li>
  <li>Que haya sido obtenida legalmente de un tercero, siempre que este no haya violado alguna obligaci&oacute;n de confidencialidad de la que Grumer tenga conocimiento para su obtenci&oacute;n o divulgaci&oacute;n.</li>
  </ul>
  </li>
  <li><p>Grumer reconoce que la Informaci&oacute;n Confidencial del cliente es de su propiedad exclusiva. En ninguna circunstancia se entender&aacute; que exista una transmisi&oacute;n de propiedad de la Informaci&oacute;n Confidencial respecto de la que Grumer tenga acceso en virtud del Posible Negocio.</p>
  </li>
  <li><p>Grumer reconoce que el acceso que tenga a Informaci&oacute;n Confidencial del cliente con motivo de un Posible Negocio no le confiere derecho, autorizaci&oacute;n, permiso, o licencia de propiedad industrial o intelectual alguna.</p>
  </li>
  <li><p>Grumer s&oacute;lo podr&aacute; revelar la Informaci&oacute;n Confidencial proporcionada por el cliente a sus empleados, prestadores de servicios, agentes, asesores, representantes o personas que la requieran de manera justificada y &uacute;nicamente para los fines relacionados con el Posible Negocio.</p>
  <p>Grumer har&aacute; que sus empleados, prestadores de servicios, agentes, asesores, representantes o personas que la requieran de manera justificada que tengan acceso o conocimiento de la Informaci&oacute;n Confidencial, la guarden y mantengan bajo dicho car&aacute;cter, cumpliendo con las obligaciones de confidencialidad que aqu&iacute; se estipulan. Lo anterior, en el entendido que, en caso de ser necesario, celebrar&aacute; todos aquellos convenios de confidencialidad que resulten necesarios a fin de que sus empleados, prestadores de servicios o representantes protejan la Informaci&oacute;n Confidencial.</p>
  </li>
  </ol>

  <div style="page-break-after:always;"></div>

  <p style="text-align: center;"><strong>&nbsp;</strong></p>
  <p style="text-align: center;"><strong>T&eacute;rminos de Servicio GRUMER</strong></p>
  <p>Al usar nuestro Servicio, est&aacute;s de acuerdo con estos t&eacute;rminos.<br />DEFINICIONES</p>
  <p>&ldquo;Cliente&rdquo; quiere decir la persona que solicita los Servicios proporcionados por Grumer.</p>
  <p>&ldquo;Usuarios&rdquo; quiere decir visitantes de este sitio web o el servicio que no sean usuarios registrados.</p>
  <p>&ldquo;Clientes&rdquo; quiere decir visitantes que tambi&eacute;n son usuarios registrados del servicio que procuran usar los servicios.</p>
  <p>&ldquo;Traductores&rdquo; quiere decir terceros que colaboran con Grumer para proporcionar servicios de traducci&oacute;n como contratistas de Grumer (no empleados).</p>
  <p>&ldquo;Servicio&rdquo; quiere decir todos los sitios de internet, servicios, apps, tecnolog&iacute;a relacionada y todos los servicios de traducci&oacute;n de Grumer.</p>
  <p>&ldquo;Partes&rdquo; quiere decir Grumer y el Cliente.</p>
  <p>&ldquo;Pedidos&rdquo; quiere decir cualquier pedido para los servicios, creado por un cliente y aceptado por Grumer por medio de aceptar en la plataforma o bien por escrito.</p>
  <p>&ldquo;Materiales de cliente&rdquo; quiere decir el contenido de la fuente para traducci&oacute;n por el Servicio, y cualquier directriz, glosario y otro material proporcionado por el cliente.</p>
  <p>&ldquo;Trabajos traducidos&rdquo; quiere decir el contenido traducido a partir de los materiales del cliente.</p>
  <p>&ldquo;Pol&iacute;tica de calidad de Grumer&rdquo; se localiza en /quality-policy/</p>
  <p>&ldquo;Niveles de calidad&rdquo; se definen y describen en la Pol&iacute;tica de calidad de Grumer.</p>
  <p>&ldquo;Plataforma&rdquo; quiere decir el portal y la plataforma en l&iacute;nea de Grumer donde puedes acceder a tu cuenta Grumer, iniciar &oacute;rdenes y acceder al servicio.</p>
  <p>&ldquo;TDS&rdquo; quiere decir estos t&eacute;rminos de servicio de Grumer y cualquier pol&iacute;tica, directriz u otros documentos referidos en la presente.</p>

  <div style="page-break-after:always;"></div>

  <p><br />POL&Iacute;TICA DE PEDIDOS, APROBACIONES Y DEVOLUCIONES</p>
  <p><span style="text-decoration: underline;">Cuenta</span>. Antes de iniciar un pedido, primero debe registrarse como Cliente y crear una cuenta Grumer. Usted est&aacute; de acuerdo en mantener toda la informaci&oacute;n de la cuenta actualizada y precisa en todo momento.</p>
  <p>Cualquier informaci&oacute;n personal que proporcione estar&aacute; sujeta a la Aviso de privacidad de Grumer y al Aviso de Confidencialidad de Grumer.</p>
  <p><span style="text-decoration: underline;">Pago</span>. El costo por la prestaci&oacute;n de los servicios profesionales se determinar&aacute; cada vez que el Cliente solicite por correo electr&oacute;nico o en nuestro servicio en l&iacute;nea la cotizaci&oacute;n del Servicio a Grumer y &eacute;ste, a su vez, le haga llegar por el mismo canal la cotizaci&oacute;n que el Cliente, en su caso, aceptar&aacute; para que se lleve a cabo el Servicio.</p>
  <p>Contra el pago de los Servicios, y en caso de solicitud, se realizar&aacute; la entrega de las facturas electr&oacute;nicas correspondientes que sean solicitadas, mismas que deber&aacute;n cumplir con todos los requisitos establecidos en la Legislaci&oacute;n aplicable vigente.</p>
  <p><span style="text-decoration: underline;">Pedido</span>. El cliente puede iniciar un pedido proporcionando toda la informaci&oacute;n requerida a trav&eacute;s de la plataforma, incluyendo el Nivel de calidad para su trabajo seg&uacute;n se describe en la Pol&iacute;tica de Calidad de Grumer.</p>
  <p><span style="text-decoration: underline;">Materiales de cliente.</span> El Cliente es responsable de proporcionar los materiales para trabajar, los materiales que describan el contexto del objetivo del servicio solicitado y todos los dem&aacute;s materiales que sean necesarios (gu&iacute;a de glosario, etc.) al realizar el pedido.</p>
  <p>Grumer puede hacer recomendaciones sobre qu&eacute; materiales de fuentes y en qu&eacute; formato se proporcionan los materiales de fuente, pero en &uacute;ltima instancia la calidad de los resultados depender&aacute; de la claridad, la precisi&oacute;n y la comprensibilidad de los materiales de fuente y las instrucciones proporcionadas del Cliente.</p>
  <p><span style="text-decoration: underline;">Cancelaciones</span>. El Cliente puede cancelar cualquier pedido si ning&uacute;n traductor colabora a&uacute;n con el proyecto.</p>
  <p>Para intentar cancelar un pedido, el cliente puede hacer clic en el &ldquo;bot&oacute;n de cancelaci&oacute;n&rdquo; o en la p&aacute;gina de detalles del trabajo mientras espera a un traductor o contactar a soporte de clientes de Grumer directamente en contacto@consultoriagrumer.mx para saber si el pedido puede cancelarse.</p>
  <p>Si la orden ya la tiene un colaborador, la orden no puede cancelarse y no habr&aacute; reembolso.</p>
  <p><span style="text-decoration: underline;">Entrega de los trabajos</span>. Grumer no puede garantizar que un colaborador en particular o que cualquier colaborador que se escoja colabore en su pedido. Si un colaborador completa la orden, Grumer entregar&aacute; el material al Cliente de acuerdo con el nivel de calidad que el Cliente especifique en el pedido.</p>
  <p>Grumer otorga un plazo estimado para completar el servicio, pero no puede garantizar el plazo de entrega exacto. Le enviaremos un correo electr&oacute;nico cuando los materiales entregables est&eacute;n listos para su revisi&oacute;n. A menos que Grumer acuerde expresamente de otra manera, el tiempo no es la esencia para su entrega o desempe&ntilde;o y ninguna demora le da derecho al Cliente de rechazar ninguna entrega.</p>
  <p><span style="text-decoration: underline;">Aprobaci&oacute;n o rechazo</span>. Tras la notificaci&oacute;n de entrega de los trabajos traducidos por parte de Grumer, el cliente tendr&aacute; estrictamente 96 horas para revisar los trabajos traducidos. El cliente puede aprobar los trabajos traducidos a trav&eacute;s de la plataforma.</p>
  <p>Si el cliente no lleva a cabo ninguna acci&oacute;n a trav&eacute;s de la plataforma en el plazo de revisi&oacute;n se&ntilde;alado, los trabajos traducidos se considerar&aacute;n como &ldquo;aprobados&rdquo; y se le pagar&aacute; al traductor por los trabajos traducidos. Una vez que &ldquo;se aprueba&rdquo;, no se proporcionar&aacute;n alteraciones, revisiones o reembolsos de los trabajos traducidos.</p>
  <p>Los clientes pueden rechazar los trabajos dentro del plazo de revisi&oacute;n de 96 horas si determina justificadamente que no cumple con el nivel de calidad con el que fue pedido. Llevaremos a cabo una auditor&iacute;a de calidad y nos comunicaremos con usted dentro de un d&iacute;a h&aacute;bil a partir del rechazo. Si Grumer determina que los trabajos que usted rechaz&oacute; no cumplen con el nivel de calidad especificado en el Pedido, Grumer cumplir&aacute; con el rechazo y proporcionar&aacute; un segundo entregable o permitir&aacute; que se cancele el pedido.</p>
  <p>La responsabilidad de Grumer se limitar&aacute; a corregir los errores o a proporcionar un reembolso.</p>
  <p><span style="text-decoration: underline;">Advertencia</span>. Usted acepta revisar cualquier trabajo antes de hacer dicho contenido p&uacute;blico y aceptas expresamente que Grumer no tendr&aacute; ninguna responsabilidad ni se obligar&aacute; a indemnizarte con base en los trabajos traducidos si no cumples con hacerlo.</p>
  <p>CONFIDENCIALIDAD</p>
  <p>La prestaci&oacute;n del servicio por Grumer se acota a lo establecido en el Aviso de Confidencialidad de Grumer.</p>
  <p>INDEMNIZACI&Oacute;N</p>
  <p>El cliente indemnizar&aacute; y eximir&aacute; de responsabilidad a Grumer, sus afiliados, directores actuales y antiguos, oficiales y empleados de y contra toda reclamaci&oacute;n, impuesto, p&eacute;rdida, da&ntilde;o, responsabilidad, juicio, arreglo, costo y gasto, incluyendo honorarios de abogados o costas legales que surjan directa o indirectamente a partir de o en conjunto con:</p>
  <p>(1) incumplimiento del cliente de alguna de sus declaraciones u obligaciones bajo este TDS;</p>
  <p>(2) negligencia, falta de cuidad o dolo por parte de sus asistentes, empleados, contratistas o agentes;</p>
  <p>(3) que el cliente no pueda llevar a cabo sus obligaciones o ejercer sus derechos de acuerdo con las leyes, reglamentos u otras disposiciones aplicables.</p>
  <p>LIMITACI&Oacute;N DE RESPONSABILIDAD</p>
  <p>Ni Grumer ni sus traductores ser&aacute; responsables de ning&uacute;n da&ntilde;o directo, indirecto o perjuicio del cliente que pudiera estar relacionado con la prestaci&oacute;n del servicio.<br />Lo anterior ya que la utilizaci&oacute;n de los textos y trabajos proporcionados por Grumer implican la aceptaci&oacute;n y conformidad con los mismos por parte del cliente.</p>
  <p>GENERAL</p>
  <p>Las Partes convienen expresamente en someterse y sujetarse, para todos los efectos de resoluci&oacute;n de cualquier controversia, o en su caso, para la debida interpretaci&oacute;n, cumplimiento y ejecuci&oacute;n del presente Contrato, a las leyes vigentes en la Rep&uacute;blica Mexicana y a los tribunales competentes de la Ciudad de M&eacute;xico, por tal efecto, las mismas renuncian a cualquier otra jurisdicci&oacute;n que pudiere corresponderles por raz&oacute;n de sus domicilios presentes o futuros, por la ubicaci&oacute;n de sus bienes o por cualquier otra causa.</p>
  <p>Grumer puede modificar este TDS en cualquier momento. El Cliente debe de revisar los t&eacute;rminos regularmente, si no aceptas los t&eacute;rminos modificados para un Servicio, debe descontinuar el uso del Servicio. Los servicios se regir&aacute;n por los TDs aplicables al momento de realizar el pedido.</p>
  <p>SI hay un conflicto entre los t&eacute;rminos en este TDS y un pedido, este &uacute;ltimo prevalecer&aacute; para dicho conflicto.</p>
  <p>Si no respetas este TDS y no tomamos medidas de inmediato, no significa que renunciamos a ning&uacute;n derecho que podamos tener (como tomar medidas en un futuro).</p>
  <p>No puedes asignar, transferir o delegar ninguna porci&oacute;n de este acuerdo sin previo permiso por escrito de Grumer. Cualquier intento de asignar, transferir o delegar este Acuerdo sin permiso de Grumer ser&aacute; inv&aacute;lido.</p>
  <p>POL&Iacute;TICA DE COOKIES</p>
  <p>Al usar nuestro sitio, acepta que pongamos este tipo de cookies en tu dispositivo y que accedamos a ellos cuando visite el sitio en el futuro. Si quiere borrar alguna cookie que ya est&eacute; en su computadora, la secci&oacute;n &ldquo;Ayuda&rdquo; en su buscador debe proporcionarle instrucciones sobre c&oacute;mo localizar el archivo o directorio que almacena las cookies. Note que al borrar o desactivar cookies futuras, su experiencia como usuario puede verse afectada y puede que no aproveche ciertas funciones del sitio de Grumer.</p>

  <div style="page-break-after:always;"></div>

  <p style="text-align: center;"><strong>&nbsp;Aviso de Privacidad</strong></p>
  <p>Grumer Grupo Mexicano de Redacci&oacute;n S.C. (en adelante Grumer) es responsable del tratamiento y la protecci&oacute;n de sus datos personales, los cuales son tratados de forma estrictamente confidencial, de conformidad con lo dispuesto en la Ley Federal de la Protecci&acute;pn de Datos Personales en Posesi&oacute;n de los Particulares (la &ldquo;ley de datos personales&rdquo;).</p>
  <p>Los datos personales que recabamos de usted a trav&eacute;s de este o cualquier otro medio, los utilizaremos para fines acad&eacute;micos y para la efectiva prestaci&oacute;n de los servicios que nos sean encomendados, as&iacute; como para integrarlos a nuestros registros internos para el env&iacute;o de informaci&oacute;n y novedades respecto a la prestaci&oacute;n de nuestros servicios, as&iacute; como para prop&oacute;sitos administrativos y de facturaci&oacute;n. Para la finalidad antes mencionada, requerimos obtener los siguientes datos personales: nombre, organizaci&oacute;n para la que labora (en su caso), domicilio, correo electr&oacute;nico, tel&eacute;fono, as&iacute; como toda aquella informaci&oacute;n que nos proporcione en relaci&oacute;n con los fines antes indicados.</p>
  <p>En t&eacute;rminos del art&iacute;culo 68 del Reglamento de la Ley de Datos Personales y el art&iacute;culo 36 de dicha ley, usted consiente y autoriza expresamente cualquier transferencia de sus datos personales que Grumer realice a sus empresas relacionadas, subsidiarias o proveedores. Adem&aacute;s, Grumer garantiza que las transferencias realizadas cumplir&aacute;n en todo momento con lo dispuesto por los art&iacute;culos 36 de la Ley de Datos Personales y 68 del Reglamento de la Ley de Datos Personales.</p>
  <p>Contamos con las medidas de seguridad suficientes para la protecci&oacute;n, confidencialidad y aseguramiento de sus datos personales con la finalidad de restringir el acceso a los mismos a personas no autorizadas. Asimismo, nuestros empleados, representantes, subcontratistas, consultores y/o los terceros que intervengan en cualquier fase del tratamiento de sus datos personales guardaran confidencialidad respecto de &eacute;stos, obligaci&oacute;n que subsistir&aacute; hasta despu&eacute;s de finalizar la relaci&oacute;n entre dichas personas.</p>
  <p>Usted tiene derecho a acceder, rectificar y cancelar sus datos personales, oponerse al tratamiento de los mismos, limitar su uso o divulgaci&oacute;n, o revocar el consentimiento que nos ha otorgado para el tratamiento de dichos datos, enviando un correo electr&oacute;nico a contacto@consultoriagrumer.mx.</p>
  <p>El presente aviso de privacidad puede sufrir modificaciones, cambios o actualizaciones derivadas de nuevos requerimientos legales, de nuestras propias necesidades por los servicios que ofrecemos; de nuestras pr&aacute;cticas de privacidad o por otras causas. Nos comprometemos a mantenerlo informado sobre los cambios que pueda sufrir el presente aviso de privacidad, a trav&eacute;s de nuestro sitio web www.consultoriagrumer.mx</p>
  <p>Fecha de &uacute;ltima actualizaci&oacute;n: 3 de septiembre de 2019.</p>

  <div style="page-break-after:always;"></div>

  <p style="text-align: center;"><strong>El contrato de confidencialidad como lo tiene GRUMER con el traductor</strong></p>
  <p><br />PRIMERA. <span style="text-decoration: underline;">Informaci&oacute;n Confidencial</span>. Para efectos del presente Convenio, se considera como &ldquo;Informaci&oacute;n Confidencial&rdquo; toda aquella informaci&oacute;n escrita, verbal o gr&aacute;fica en cualquier tipo de medio impreso, electr&oacute;nico o electromagn&eacute;tico, que se encuentre identificada claramente por Grumer como confidencial y que, por motivo del Negocio tenga acceso el Traductor.</p>
  <p>Dentro de este tipo de informaci&oacute;n se incluye, de manera enunciativa m&aacute;s no limitativa, informaci&oacute;n t&eacute;cnica, estrat&eacute;gica jur&iacute;dica, contable o fiscal, financiera, bancaria, fiduciaria, comercial, t&eacute;cnica, procedimientos o m&eacute;todos, factibilidad de negocios, planes de negocios, listas de clientes y proyectos, documentos de trabajo, estudios, informaci&oacute;n relativa a socios, directores o empleados de Grumer, contratos, know how, presupuestos, proyectos fallidos o no terminados, programas de c&oacute;mputo, software, propiedad intelectual, secretos industriales o, en general, cualquier informaci&oacute;n que, de divulgarse, pudiera ocasionar un da&ntilde;o en la posici&oacute;n competitiva o econ&oacute;mica de alguna de las Partes, y respecto de la cual hayan adoptado los medios o sistemas suficientes para preservar su confidencialidad y el acceso restringido a la misma; as&iacute; como aquella que se encuentra protegida por la legislaci&oacute;n, reglamentos y dem&aacute;s disposiciones legales aplicables, conforme a los cuales ning&uacute;n tercero puede, sin autorizaci&oacute;n previa, divulgar o utilizar la referida Informaci&oacute;n Confidencial, en provecho propio o de terceros.</p>
  <p>SEGUNDA. <span style="text-decoration: underline;">Objeto del Convenio</span>. El presente Convenio tiene por objeto establecer las obligaciones y medidas de confidencialidad que el Traductor adoptar&aacute; respecto a la Informaci&oacute;n Confidencial proporcionada por Grumer con motivo del Negocio.</p>
  <p>En este sentido, el Traductor se obliga a custodiar y salvaguardar la Informaci&oacute;n Confidencial a la que tenga acceso, impidiendo y evitando su sustracci&oacute;n, destrucci&oacute;n, ocultamiento, inutilizaci&oacute;n, divulgaci&oacute;n o alteraci&oacute;n total o parcial, as&iacute; como su uso para cualquier otro fin no relacionado con el Negocio, manteni&eacute;ndola bajo el mismo nivel de cuidado que le aplicar&iacute;a a su propia Informaci&oacute;n Confidencial.</p>
  <p>TERCERA. <span style="text-decoration: underline;">Propiedad de la Informaci&oacute;n</span>. Las Partes reconocen que la celebraci&oacute;n del presente Convenio no confiere a el Traductor, respecto de la Informaci&oacute;n Confidencial de Grumer, derechos, autorizaciones, permisos, o licencias de propiedad industrial o intelectual.</p>
  <p>CUARTA. <span style="text-decoration: underline;">Confidencialidad de la Informaci&oacute;n</span>. El Traductor est&aacute; obligado a preservar y mantener bajo car&aacute;cter confidencial la informaci&oacute;n al a que tenga acceso, cumpliendo con las obligaciones que aqu&iacute; se estipulan.</p>
  <p>No obstante, el Traductor no tendr&aacute; obligaci&oacute;n alguna de mantener como confidencial la informaci&oacute;n a que se refiere este Convenio cuando la Informaci&oacute;n Confidencial encuadre en los siguientes supuestos:</p>
  <ol style="list-style-type: lower-alpha;">
  <li>Que se halle en registros o fuentes de acceso p&uacute;blicos;</li>
  <li>Que previamente a su divulgaci&oacute;n, la Informaci&oacute;n Confidencial fuera conocida por el Traductor libre de cualquier obligaci&oacute;n de mantenerla como Informaci&oacute;n Confidencial, seg&uacute;n se evidencie por documentaci&oacute;n que posea;</li>
  <li>Que se haga p&uacute;blica durante la vigencia de este Convenio o que sea o se vuelva disponible al p&uacute;blico sin que medie violaci&oacute;n a este Convenio, o</li>
  <li>Que haya sido obtenida legalmente de un tercero, siempre que &eacute;ste no haya violado alguna obligaci&oacute;n de confidencialidad de la que el Traductor tenga conocimiento para su obtenci&oacute;n o divulgaci&oacute;n.</li>
  </ol>
  <p>En el supuesto que cualquier autoridad, sea administrativa o judicial, solicite a el Traductor acceso a la Informaci&oacute;n Confidencial de Grumer, deber&aacute; dar aviso inmediato al Cliente previo a la entrega de dicha Informaci&oacute;n Confidencial, a fin de que Grumer adopte las medidas que considere pertinentes<br /> <br />Asimismo, en caso de que exista un plazo para la entrega de la Informaci&oacute;n Confidencial y Grumer no se haya pronunciado respecto del aviso al que refiere el p&aacute;rrafo anterior, el Traductor se obliga a dar &uacute;nicamente la Informaci&oacute;n Confidencial que le haya sido expresamente requerida, haciendo su mejor esfuerzo para, en caso de que la autoridad no haya especificado el tipo de informaci&oacute;n requerida, realizar el mejor m&eacute;todo posible para afectar lo menos posible la obligaci&oacute;n de no divulgar la Informaci&oacute;n Confidencial.</p>
  <p>Asimismo, El Traductor se obliga a entregar la Informaci&oacute;n confidencial requerida haciendo referencia expresa de su car&aacute;cter confidencial.</p>
  <p>&nbsp;</p>

    </div>

    </body>
    </html>

    ';


    wp_mail( $to, $asunto , $cuerpo, $cabeceras);

    //Mail de facturacion

    $to = $usuarioID[0]->mail;
    $asunto = 'Datos de facturacion';
    $cabeceras= array('Content-Type: text/html; charset=UTF-8','From: GRUMER Facturación <administracion@consultoriagrumer.mx>');

    $cuerpo = '
    <!DOCTYPE html>
    <html>
    <head>
    <title>Datos de facturacion</title>
    </head>
    <body>

    <div style="margin:0 auto;width: 700px; font-size:12px;">

      <div style="text-align: center;">
        <img width="200" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPsAAAA/CAYAAAAmC74EAAAgAElEQVR4nO193W/bWJanXhfYwGrRCmlRirm2bCuxa0aY7cbW9KIXHGB7ql01mXJNTc8OahsLYReDsSV+XEpKo96W29XVTmI7dCsKTVO0qHaSSmGnu53P7sXuA/8E/wn6E/Q4D7PVZx8uL0lRJCUnTsXu1QEuYIuXh/frd++5555zbio1pSlNaUpTmtKUpjSlKU1pSlOa0pSmNKUpTWlKU5rSlP7IaU3Q+Otb2saNqqaOpj31va07G6vVu+V3Xc4pTWlKZ6QS2ubopoZY+cBhBQsYqQs0SbIFOREnWraAlk1gZB0Y2QBa6kEW9Zy5+iEqIY2b5FscOuBpZEB2kqToOCEDKMWATN3szyqWk5N+pS5VzTNPNmvVPTUnmZCTjMjEyoZzVp4rv/1swD3/GAqv1qHwux/C/KsfAvfqgxOvvq8+LM+/XMfPX63D/Mt1eO9/fww/ePjpRphX6fO9ypXmL4FSTMjK3chES12Yk44HZy1nFC1v3dmYEzrwHekxfEd+CDnhEAq1+8BKbWAkE7LSI6DkR0ApJkzCb626o7KiCbiNE5JoxSfJgILUgoLUAlawgBUsyMv3Y/ulIBhOodaDQq0HXE2HgtgGGhlAKSZQiuEmC7LIAkoxgUYGsJIOBcGAvPDQYcXHdkE8qpQnHL+XlspI45Zr+zYrtYFGGMCMZAEtdYFSLKAUDDhWagMrtSGr6EApBtDIAEYycV7ZAkYygZXaUBQ0Z7V6t5L0TQ51+JxkAi3HJGS4SQcGtXGSdcgiE9L1LmSULuQk3KnXRKO/KLYSvxekteodlUxUuPyhJHfOBHb+YYUv/ebHsPD8I5h/9QHMv1wH7uU6LLz8CHn1fbmuFV6tQ+7368D8r3XI/e4jWP4/fwvvP6lwYX4ltKNSigGzcgdoqReZsvIxUNLXsLh1ODJZnJUK4oMTRjK9iZ1MhDTCEyye3C3IKjqUkZYex29Z2FGzKKJdR5KVkExgUBtycgsKog7zgg55tB/bL6xsOGRSYKU25CQdcmIXGKkLWWRCFpnAiMeQE469xQpP7njSYdx6F0QdlqvayWpV++OSWMtIS8/JHS2qI2gZNxClmJBu6EDV28C6My2NMOB9sMck2bLjvp13wZ70PgE8BiYGZxaZkFHwJJST8QQwUz+Gmfox0OjwtIS2uXH1Xqtuq/hdI3KiYdDZwP7+4/+irvz2Uyg+/wgWXnwACy/WoXRyE95/8vdeWbiXH50WXq1D/ncY6PlXN2H+dx+fRvErSZqaRRbMSke+ZBVKBOxc1TyJ4jEpcchOx/c/lqxIP2QVHUrCNj+OZ1HaUTN1ty2T+lc2vYlkNGHJMSfpMC8YMC/owKL4lZ2RO05OtIAVTW9c5MQu5ISe972ccAyM6IJ93NiVLMhJD9U3adsLQ6tVrXxNOugnAS2r6EDVdUg3DMjUceNg8QyLu+M68ioy4sHePOBjV1aPBxa7hsRXV4JgZGNopU/X8Qyel1uDcYD/7uaXKie08Op1DmBf/fVPnOLTT2Hp2Uew8nQdVp6uw59/9TceCN9/8vfcwvOb7kTwASw8/xgWnn8Mi69+VInityJrJxTqQkbueKvSaLKAEXvAVa2JVts4YpFZeZdgj6sfIxtQEAyYr5lQqHWBFbrAoPjtVTTYLQx4yfAWCkoxgarrkFXaYwCPV3uuFj+GLwWtVvcqnHg4mGRlzbr7HiyWkf0U3nMlvctKOiyi3VgRk2l2+HEzK17FepCVsdhKSz0sbokY8Hj/ZUHGTXhPZgKNDiNXTELnCfbySSVdPPlPUHz6CSw9vYnB/uwD+MHjH1dInu8/rlSKzz6G4vMPoPh8HZaefgJrv/4x8CeVSJAW0a6TrlvwHeUAqLoemWiERdCCYMJi1axE8ZmE5mTz5ExgF7fHfqso7b052N26zdcsYIUe5IQe5MX4fhkCu4S3fp6YLhnu/t2AdMOAdEOHTH0CydQd59fEDor77oWmItL4haoO87VxgHX3MWIX74NEPNvSyAdIUiMt1u4lKnMY9IRnpG6yGCWS7+OUE7vAiD2gxUeQlR5BRulBRul6YM8oFqTrXZipH8OCdF+N+/aa8OW5ifHLLz7dWHr6CSw9/QSKz27CAhblB0Egv/+oYi88+wQWXqzDwvOPoPj0U/h3jyuxK8a1xu3Tf3XrAL5Tvw/Zeisy0UrL1WMYwMj2mRWKqRTexiUDMXJlV8fxLUp7KqVMAnZXcotItGwN7adZwYLF2gQru2Dh/brc9vbu/pbUgHTDhCtNC2YaFkyiV6BlCyh0PCgj+7Wlp3dCS0grs7I+KAgGFIQJwC72gKva/dJm216r7qg3hG11WdpWi9Keyon7J6ysn8a9f716N3EvyaB/4ukEsBcEw1muPlDXqppa3ryjljfvqGubu87y1oM+WzuGrPRVItivSQf9uG+XhG2VkfWhiet1wV58ua6tPL0JKycfu+L5R7D08oMhIH/3q58MFp59AtyLj4B7cRPmn/4N/PnD/xYr9bD1O/Cvmw8go9wHWmlFpmy9BVmljbXMqAuTnoIEaUlsRYrwbwr2ZWE82FlJhwVhH5aq9yLTypabqruwUr0LN7buwr/9h9sJYLccsjD5YG9BTm5DFhmQQwdqUdLUorSnLki/VFn5gc3KhjNO6qAUCyj5GIq19uVa3Rdq+mlBMPCM565sURWdkzuDOflIY5DNjePJITvNIrMSFgev1+4kNs5s80ki2IvCL9W4d0vCAc9Ix/2s3HXF+K6ntMP7PR3mxRasVh9EalTXqjtqLtCpbwL2hVd/0V95uu6D/emHUD75jzx5/v3Hn5XXfv0pFJ99jIH+4mMoPN+InYhSqVTqGtKAQW2gpQcB5eRwyiIDZhompBsm0EiH1dovzjwYC8K4wT4K9hXhF2MVguPAnkMd9axlHUdhsGNNPj7FoertWCmTQ3Y6hzpqVP0zdbzHz0k6/MnWLxK3hheKOOmBWhBMVyQ3PPEGH3PpXsrLbed1VolUCh/hLdb2bVY0xq40s02b95RtEakk7KlJ75fQAZeXDgfe7BsAOjk1uCbqkQBYq+6pZN//JmDnn2xwxRd/4SrlbkLx2U248ZubQ0C+fnITLT29CQvPb8L8y5tQeHkTCs//WovjyX1uc9ekB8BKOsyJB7Htk0VEHMUKqeu1O2cajByyOe+IKwrsAfsGRsJbuKyiw5KwPbZtLgrYsfSmJ4KdUFH4pVoQDE8fRcumN6bmBR3e+8fbE9kYvHMqIzWdR/sDIpJg44MuZJEFmboBVGMfsvV7cLWxfy6axxI64MblmW12+CQx70Y1GeypVCpVFPe1IVEcYa0rEePy6EEkjxvVPTUO6GcB+/efbFSKL34IxefrUHz6I1g++RG8//hvh7658vRHzsKzvwTu5Qf42O3lh8D9fiO2ffLNDs/KHSC2C3GJUvC+M1PHg3NeaMMSmvxsmEU6SjwNkQ1fL+CefdPobGDPotj2VcfxOCuNgF329+pZNJkx0FKtNSD6qZy7lWWFLnBbPVjaNOFSGNysCf9DzaF9SNctyCg9YAUCdvcYot4CFu19q0cM447eblR31HE8StW9ClZQRaccOozksSzsqVgJ9GZg//ePP7WLzz8A7uU6/JtnH0Lx6YfAh4xklk9+BAvP/hLmX30Aud+vA/firxJX4Hyzw8/JNlZESt1YBRaxBMsi3xKNRoexEkOY5tCD03Fgz8lYFGYFwt8ATtwdC5yLA3b32BZZE4G9tLWPeYjuEbPYBVbowXz1GOarXcijA/68y33uxMl7fRq5yhzF70gGtVxFhtn/trWNRXSfZ8X4wVYS7qjjeCyJd+PBLlnAoGijCA5p6kwD7/HfBOw/ePjjQfH5RzD/8ibkX/w1cE8/HXqPf/gTfuW3f+WD/Xc3YfU3/pFcFOXqh+qcbMOc9KsIsB8NfG21CayIz6IJGBkUr5QMUglpXNKx05zcGeQkn/98DQ9+fKypXzqwU8pkYC8K+05W7gWOlvHpT060gJF1mG3e58+73OdK7K0HZWLx5qe2K6Ltw7zYgrXNDv9tl+s8wF4UNS0O7LRswdUYsC9I5wP2D83/Wnn/8Wfqnz35TP2zJz9Rv/f4H4bE6A0bpf/Drz5Tv//w79T3n/yd+t2v//NYJVoy2C3nKjrqB8GO29A1MZV1WBO+4Me2W01DicdismUzrhiLz/Lxd7LIAgp1gVOTF4Z3D3Z/DGCwTybGzwttoFDP2wp6th4y1oucd5nPnTLNI5XYtkelBXF/otXgvCmPksX4kpAsxpeRnb4m6YNkMd6KPN66UT0fMf5t0Fz9UEtY2TW6foT8/7G2OOMqklhJh9Xql2O3Y6x8P16ElztODlkbtGx5x5pEF4IHfw9m0T/xSfzfLdi7nhENNsbqQlYZL40UaxpiJKyUY1ALWHkfWEnHq7zQg5Wt9rk4Hb1VopSeQynmkOdYcM+XdMT1NolpYq+32KM3Kb5cZWSnWcE6zbl7y6jESu1YM9K16o4ad8b+rsHOIMOJA/vV+pHKfG5zYcvBdAMbjLCiAdere4mDkvn8IFGEZ5FZyaMOT8Cerlue01NOtLCtOXrCJ32jJOypcUAfTfFKSDIh59GBOrbdIsGOTawZORnsS1WtPCd3sAJbMT2pNye3XbPwLlzf2n8jH4RvhVix1yfHJhjsFtDiV0CLXwGlWFBEGv8uysUgrI2PS1EdXEZaelHUKpzU6uNZN35VLwpaLGBLwh2V2EZfOLArZiLYU6lUKossJyt3gZKPgUI9zysRa+V1WBTizZSx4xP2Bgsfvc3JnYFrN1EmYjw+gsLn7ayIj24ZZFeS6jAp2ImVZlTCYDc9g5ix7TYixuvepMFI0WL8EnpQ5sQHNjGbphR8to59Qfzj6Exdh0V05429C986zVfJTOeu6nIXaPFrD+xn4bWEvizPNvcdBh04jNxxZpWOk0WGUxDbTl5uO7ONAyfd7DjpRs+hlJ4zJx/FaocZZCeCnZZNzzyXGM6Qc8+cpLt7KhOGzuo95ZwJJWGHj/v22wQ79/kTflbo8LPCAc807/NM84BnUIdnUIfPNw94Xk12WplTzMGcbMOcbEPYEWi2afOpVCqVrZsV/Dv2F/BcgcnePcEBiZHNPu0qngjgPVDIR7afz/COoMjxleeHHnPKQei8wc7Uzwp2/+jNHx+W6y2IeRPPQdyGXQ/s6YbpOX6RcqYbxjvZ6p6ZsCbR8Jxassjy3SSRcSawF9E2n27oniNB2HDCM3BBeEVK9FIas7IzsgEFsQ0F0Q2gIHeBQngPRjqPko+B8hxkLN8bDx0l7ltvVPfUxG+/AdiDK6ZngebyzSrtsV5jWMQmA950+6sHFOpB2gU7p9ppfyAHrRB9X/CoLcwSulumFMN7Lyf0gBGxoxGFupBD9oZfjnbANt0Xq7PIAqZ+fmCPC17BSHj7QNX11wf7yGQecJ/1vo19LmjZ8lZ1yl3VWQFvW2abyduWC0Frwg4GFDF3RMNKk6vobDNWEe3w6YYOmUYLqHrb5ZXgj5wE9uZ4sLOS7mmb8UyMB6bv090DSj72fstJJnDCg9NxLp83qppKRNTzBjsePJY3+XntjfAgKqHJwe6BWMTHQfmmv+W6igzbXx1H01JEMA9O1jSyYmGnEexNlpW7wITGwlXlwSkj+Y4otNQFCnVdBdZBYvtMAnZGCkgKESk4WU4mxg87wiT5PpDve9sSd8UngVpo19S2IFjAVZO3LBeGPLBHJLwKd86kYSyhL3iqsQ85dA9YqeUdb7wu2ON9tfGKlkHHkEGPhgBOQE5LXU9sx2JuD3KyeTKJb/dFBfuasM0TsOfELhQEC+Zr2M1zpTpszEI1DjfiwE7LFuTF0aAWOdnsZxGW9PAZuul5MxblnaEt16xiOG8f7NFhwYL+53H6mzBFubiOA3tBwPWjEPat8KRDuQUsag8K4lFl3HcvDK1W75aTwJ6pT3b+SKiEvuBpZR/HBhP9PfPbADuljAG7bPmODsjuM2jyjrk8YDfdKC0GvLf585G+YuXDQVJoJy7gyISVbpYHMhJ/rSDqkJNbUA4F/JitH50QUTcMdhrpiVaAk4CdlXRYqu3Cja3bkalUve16vO3CWnW8p91I8IoJwI59REzPkYqRTOCEFiyL23a4PS4FJa/s4x1WgoQHYzDcTzxg3hTstOzHCAsGssCp6/Jvw9UJ9nNhuqhgvy7c2QiL8TlJh4LUgj+p/mxECiuK+1oc0HOSASzy3TJZ2dBwDEF9KKgDK7WBRfsj4L2KbDUB7ImLxDiwv51z9jOCnViRyjo+0ZCPgUaHg9d1ArsQFAtGV4N7lkCN36uq5dLWjlPabDtLm4aTFzsOjTqDtwH2vNx2SsIdtVS93Z8XsDMG0Z7iwawDrbSAqrcH6VuPzxQc8G2CfTiSzijYiwlgvyFsq8MKOmzQkpNbsLb1xUiZVqtaORLoRCnb0DwQzyF9kJNb2MebhBSTDWBQG9j66BjIIVv1lWWXH+wM6qgMsmxvvCIDsgr2dacQVoDSyIAFaefyuLKGiUEdx1/NfUMFMrMVxAdvZCwQ5H+eYC9Kvtfb9eqdk5xkQgY9ggx6hPeb0j7Qyj5Q9RZk6p0zzcjjwE6js+kyCJUEjScnA3FgX0LxcfaHwC72gJaOPd3E2tbPI9uSkY/6UYDPIgPSzRakPz/gqIa1kUWmG+Fm3wW75TlCRZm/FgRrIwnsSWLuRQM7I/unTiwyyzTqDHDgUgvSdcuNVuybIHO1g8sZd45BBzaNdDf8M/H9Nr242aykD+3tzs7/zcAe927QXLaMtPQcOhxk0DH22pPaUJDuQQ7dg2y9BZm6CYWEmOJhem9rdyPJxZWWzdeK/LIotipZuQdElPfOp924feNWxBXhyxO82pB48e6xomzAanU7cgAyyFaHJAHZ8oA8c6sN6Z8aGlU/sjGwcYQbYvqaRRbMIT1yss8jm08C+1rCEeJFADuN2tij0zX1DeZl0UEli0ygUA9HO3KDVNCy5YY9+xoWhWhT6wtNhcb9Dbq+C1TjHr5gQbHgyi0ceC8nYQVNQb7/2qt7EtizY4/e4pVLYX/2bP2gQoL9Z5U2MGgfCtI9YKU2ZBA+flupaRNFaylX75aJKBtX9jhf+OS2MBwK9bx4AYTXfLULXNUCVko+6izKqpO+dQ+DtGEChdxourIeq6Ri0BOOEfF5uQdG2bd8o+oH/Sw6HGSJ2KrgCEXE9HVZuB85qFn0P8s5oXdpwZ6tt+DKT1swc6sdaS5Lo84puVTCP+YzgZaOgan9GvLCo8GbRO19J1RGWjqPdgbZ+j6QSLFXbukw09S9cL0FqQXXazuvFWPrbYF9raqpI+8oWj9bb0GmgQdtQWoBKxq+eC93BpMGGLgmHg6SA1gY/XHeXUHKNzU+U8fx4FgBH5uRlb0gmMBVTciLh4mTalH8uQv2Fsw0dQ+42Jvty5H2IMQK1ql/oYcfsHHkRh03kci01wQ7cbtSEOJX9qQwWBcG7LfacOUWtqQL5y+i+/x8tQuF6jGe9JHuSlQ9z8L0KkrurwtJpapme+F2kAGZRhsyDWzkj0Px4FBOS6JWOSvvtwf20Ug1i+iLjWx9H0fXUXyrMWJsw0gWcEJ7InGeEw9Pkm6kySo6UBNG7uGQlqaV+6dUHd+UQww60m6MOBw3oAXZ+oNKEp8bm7tuGCU8oXmipazDe8IvYsXKRbFV8a85Cobpivd2zEkGFGvJwS5WtvbjV/aE47CLAHYatSFTx8dqtNSL3D4VhI6TQcdeW5E9PjFPphQTCki/XOJ8GWlc0EGAhCP2j7ZMz42RRvrJWVa0WLAjA7JKvPHF64A9lUqlZhv3HdKJ5M6zYGIkC1g0Po76e5t7lYKox4MdGUDVW8Ch24mA51QM9KyCAxtSdSx1UHUdZpp4u0QrLcgjbaxYuLJ1DxjZAKreds2Rgyt7vNhcRlo6Uze8SXASsBekFpTHXHF0Y+tu//KCHTt9Ue4JTtQ7RXSfxz4XJgwF1hy6L6EzOAseLgSxsqExMom66YbYVbDo4ltKYVvhvGgPuJplL8VEZw1SFhlOOAqpH430LYC92eFxeC1iSTdqcEOhyfZby1WtHz0gfVtwVjSgtLnff29zb+jSv5Jwn6fRoZZuHA4ydd0DOQF6pq5DuonBz8gGlKpa4qRRQhrHyveAVlqQbhgw07CG9+xjbOqpxuEJ1iz7wTeTwL4g7I49Ylrb3HFixfit+Fh048CeRR0n74Z2Lgl76nJs0tRlAYd/Lkp31CX0s0rcNyO18TIWy7PSo1jFKCu3bay518Efx7r/v6LDHNqfONzXhaAy0tKsfP+UQX7wfPdGVA/sZK9XECysYCL26Mh2riL75CqyVQbZKi3bWhZZThZ1PKB/W2BPpbAiLKNY8WCXHwEntseK4Ne3djdiwe4a8TAiVrbN1ywoCO4tJVUcm4xCPXxsUzcCYNe9lRVvl1pAI33s5MM0D/ic3AIGtSDdMGGm0R0C+7i6LKLdDUoxYKbecx2RksG+MibUdyr1+mBfHgt23yQ6OcYenvDwdw2YbcZf7DgKdvdOQmTGruypVCpVRtscJ+5iS0xXKiJWhngctyGHdqGExkcAulC0hLTyHNIHRBPt7SldMX6mqcPMrfZQVNFRMTl4zGOOAPz8wD6qoCNUQhoX9N4KOsjkRAvHTRPaE/nq08g8iR+Ulmd3T0s9N/hgDxY2e7CweQzz1WNghZ5noEG5ondW+gqy0lcYtLdaQH0+XheSRx2eq+LJhJwBnwXsqVQqdU3eH6SVnucdmAT2SY4W/ZDbEWCvxsdRHwf2sAQVZ26N/ehN8AyVULw+ZkSMV/Yh27gLVGMfaDnZlXu1+nOblVrYbBYdQ8ENMMnIuhfI4hoaLwldOFpCD8p5WR9kkeVdiEh8h2eaBly5hUVSGiVffDe0B5O9/X4gGk4y2GfHHr3Fgz2Vwl5fvoLO91PGx4lYermKrLEdhCWew1MShZSEewp6ClIIB4pghEdQqD6C+eoxcFs4zVd7rlstFgVp2QJG+Apo8WugUBeuNsZLGKlUKsXVOmhx0wKuigc63oO7579In8jIZ7m2a1OITH7DYMeiKe7Xq/Xos/UwrVV3VM/F1QM71lwvCvFx1JeFncSwVN64GXLLDTvzkAsYdWBFPAlOcrEjsWfI1jHYs/V7Y8HOIy09h1qDmYYJaaUHbA2DnZXakEP7brvpMFePvofgQlMJHXCzSuc0o/TcM2p8To2vUyIDxXIHSTsm6Z6LK1b04UCWmQZWLmXqOlCN+M6ZbdqJRjXLYy6JYJDNkRVgCKSByYeRDSigg8q49igjO51Bj0+J0Q4xOiJBMvB9X/hyyaz0CJ/Fijj5oYddmwXBcG8d7QEjPprYEosTjlQMduz3PnOrDTNNfINu0qlGkFarX5aDd5vRgf0ng9rAyvuQk1vA1Me3CeZ317seKovcMFh1LMXkUPxdfvgW1+it3UhKUJASXQgrtXBcg0Sw2w721+ji8ddoe5c7xmnjgzT70wN15hZud3wLjAHz0j0oSPveliIvtwZlpF4uZR2hHDpSKXQ8IBrL4dSNBDuD2uArNCwvmARxK8wqGOzphgGzyniwx6VxYE+lUqk8OlSTHGlY0QDWDbU0jheH7PRV9PAkg46x6CjrnoUhjQzvHrm00nPP9Y/x3lj23VG5mgFcTYeCqAMXcxtNHBXkjjZfw5FcqToedFdu4XY8i60+Kx/0PbAHxGVGMoGV2sBJ+xObAq8JO7wnPXlgx5NRtt4C5vPoy0CK0s5EFzsmJXLrKlVvu/HgWomutYxsOzjIRxfSDdO9YtxyLwON37MTKqt2+mpTH6Qb+JZcBrWhIO2DJ94rPchJOlwXf3G5lHVBwgEMj7QsOhpEuqmGOsEPLmABLbkTg+sjXRDxQM8iA2aVw1OmHn8ENi4s1SQ3wpSRnY5zxCFKx5xoQQ4djeVF6Cp6uJGTzT4OnIFneAy+Fly5peMrl5RHkFYeeTey0BIW/Qq1LlwTDZub4Eac0fY4cMj5PLltlGjWc/Kob3oc5dCRShSMjNgDRngEWQnHHGTEYyhVJ7/1Z03Q+JzYjdizu2GwmtEhyEvCnkq2aHGRaMYlMsEQwFONfZhtxscVnFU6TrrehZkGTuR8PSccQ04YD/ZUKpUqNo/RbP2xt3jRCCuxZxpdrPhUTMjJLShdRvfXMF3f2t0oVffs0tZef7G2PxyTfCR1PTGWE9qwUts9LW/etsubdyuTKH9Wq3exB11M+t6mWpmozLUdNPRu7bZTqt12Vrd2nLXNXWd1c9cpbe2e2YutLGzzf7q5a5eqd/s55TZkmrtw5actuHLLwKu6fIxNWus6cDX99Po/trXy5uu7R65u3dFKtW2nVNt2loQdpyjsOovCrlMUdp3V6t3KpHxK6IBjRVepJfQgJzwCWvwaGOERcFUTvlf98kwegqUtzSGpKGhOUdh1SsJtpyRsO6sxTj3f2/xZpbSF231184xpa8dZ9fpyF7eFuO0UxS+covzfY1fVJXFP40TN4UTNWRQ0Z6mGy7y6idOk9S0j8+RPa7vO2hbuh0W3HxYFze2PHWeSk4xLR0VBI8ES1XDKIWsjjx7yS1XzTIPnMlIZqel8c5uf/fw+P9vs8Hlk8xyy+biV7V3TsvBLNY86al7qqAXB2sgjmy8Kl+DqoilNaUpTmtKUpjSlKU1pSlOajAAg/c/wz9y7Lse5EQBUAOAEAJw/wB+cb+AbGwD4d12ucQQAZYD/6wD8Cx/zPA0ADgBUzvGb58rv2yaAPzgAf3jt0Fq4zcEJpj8AnHwDoAIAdz5lBAAA9Tx4Tfi92D79Br7RvoF/gfOq2zslALDdxnUAd5gKAP1vu8FfhwCAd8vZB4CR83J3AjvXerjtw58Xv2+bCEDf4H3S5k4oDdzEn0MZv22wR/ZpoK6Vb6ssb43cSkZWxl3tIw1OAIB7nZnOXWn5pHcnyXu+8/EAAAVYSURBVBPISzoDAEALPdsIPFMj3i2fJ2gJv4Q2G1snN0/sCYbb7hO1TeCdofaMA/uk7UHaPOY7/Rjek9Yr7f4/0meBesQaQU3QB4nP4/KPyTPxeH2n5M7EExlSEEC5gwXIbBjT8V5nBWdHGCYn2Ohuo9kReZIGCeFNJi0+wGsA7tYkOHDcDuwHvjEAd7IDABTkE/qt7P4/jh9AYOIBX7og1A/WyeV3EuLRh8DgAX87Em6bxEELuL+CdAIApxAAZEx7xAZlgJg+d5+pANAP/F9x+cXVPapepC9VNw8Ho+07VHe3DqehPFroeZhH8DnAcJ9vRLSJGm4DGO3bi2lBFygwP2H+YIdVwJ+NJwW7N4jcxhzA8KBzQnl4twP7kLxagvu3l9fthAH4g4mUhUwCp275gxMM5+ax3Txe/SAg+STxc39D5H33/0qgTmRQ9kP8AABQoE5Dk7D7zin4kxnJEyuOQwA0bjk58AHhhMrvuH+T9vDKn9Tmod/Jyn7i/s+537IDvE9JvyT0OZkcgm2MwJ9sKxHPY/vATeE+D/cRBNq2HCg3yU/aMthHQPoEhscRH9cn74wCBU5H/OZR4BkEOyqYP4J3sDMiJ5VAp5UDDbwRykN+ryTVIZCXDFyPFwyDk3wzHeIzgOHBQ8A1IvmE+KEofhHlJBMHT8oQ4hf+hgY+IMl2pBzKE/l74Hk/gq8H7rjyB/JEWoLBsDRFkg3+np2A0obApBZoB3DLTv6uxPGP+J13+9lOqkNEWw7inrt5AHywn4TLHajPIFTG8HgdKfeFIIgAIfj7D540YuAZwOi+eGKwR+RJk+/H5XHzncY1YPi9QMefBH5zAmVRwZ8QgiksZZBJZmSQhPidQPLqGhRTieQBoTJ7/AK/qYHBrJJBFsE/dnC5zyoRvzth3jHtEceXjBuS9zTwfzr0nSjeAIEtYLh9w/WC4dXeCf7tPvcmxpjyOknPA9/jA/lH6g7u5BpqAz7iW5Ht9s4JEvbsMAqkkYEV12ERnRWVhwCKD+ThYsqohn+PKqP7mx0x6EhZyODmI1I5xIMMqkqIf5CfBhGrQCAv+V6Qd7hdRwYIjII9qv3SUeULPB/pL/f3UxgFe1R7cDF8o9qcbJvCuojTON6BPg9LLKReqvt/3+Uf7NNw+yT1wQkAJMYuIOMwUO4R5yIISGRwScFOBtKIyEaeBf4fGTzgAxYFfuODeQP/h0XK4L7aU6iF8gwpxyLKGCsRBPI4gbJEbgvc75B9ZIV0JPgiYHgQh+sWyc9tw9OIZ2cBO+d+IyxV2ZAgnoKv9AuChNSN8I4rfyUVQ1FtDv5+/TTQjiN95+YLjpWoPrdD4yeq7k5EHVAoD+kDUudK4Bn5Paj9592/CSbC5e6Dr4+4fGBPpYYa9xTw4NbAFzfDGks14n0ixtkwvCKq7nPSMERJogbeqQT4kE4heZy4bwbeORPYQ/W1A2UhqxvZ96uh9/uBgRHH7wR8G4WBy2sj9IzknRjs7v8EOE6obSqpGArUZQC4T8m3w1uWuPbgztLmEFBsBX47DXw/2Dac+5z0eT/wbTI21ED5gjwIz6g6jPRBTB3D5QAYPskJjmky4QfzX06wp1Je4TXw91VquLMh3vAgHXjXdjvdyxtomHC+KF68+yw2Tyg/N65x3QHFR/x24n5HCw2+8ApBVmj+rPwCdQo+K8PwZBHFj4doxdXEbeO+w0X0TSWCd2z5Y3iqMc823LYKShMoNK7C25FgvbRwe4d4nJD2OmsdxvRR1HgPltuT/IJtEPMNPvX/K8EEq++UpjSlPwJyV5PXNs+c0pSmNKUpTWlKU5rSlP546P8BoVCa0fn7PvgAAAAASUVORK5CYII=" />
      </div>

      <div style="text-align: right;margin-right: 70px;">'.date("d").' de '.date("F").' del '.date("Y").'</div>
      <div style="text-align: right;margin-right: 70px;">Folio: <span style="color:#92d050; font-weight: bold;">'.$usuarioTMP.'</span></div>

      <div style="text-align: left;margin-left: 70px; margin-top: 40px;">Hola, '.$usuarioID[0]->nombre.' '.$usuarioID[0]->apellidos.'</div>




      <div style="text-align: left;margin-left: 70px; margin-top: 15px;">

        Para poder generarte la factura, por favor envíanos por este medio tus datos fiscales:
        <br/><br/>

        <ul>
          <li>razón social.</li>
          <li>domicilio fiscal.</li>
          <li>cédula fiscal.</li>
          <li>correo electrónico.</li>
        </ul>

        <br/><br/>
        También haznos saber de cualquier otro comentario o indicación para tu factura.

      </div>

      <div style="text-align: left;margin-left: 70px; margin-top: 40px;">Muchas gracias, Lizeth Robles.</div>



    </div>

    </body>
    </html>

    ';

    wp_mail( $to, $asunto , $cuerpo, $cabeceras);

    // Notificacion a grumer

    $attachments = array();

    foreach ($total_files_words as $file) {

      $texto_mano = $file->textotra;

      if($texto_mano == ""){
        $nombrefile_text = $file->nombrefile;
      }else{
        $nombrefile_text = "Texto";
      }


      $archivos_rows .= '
      <tr>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">'.$nombrefile_text.'</td>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">'.$file->totalwords.'</td>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">'.$nombrecontenido.'</td>
        <td style="border: 1px solid #92D050; border-collapse: collapse;">'.$nombretipotrabajo.'</td>
      </tr>';

      array_push($attachments,$file->fileurl);

    }

    //fernanda.toral@consultoriagrumer.mx,traduccion@consultoriagrumer.mx
    //$to = "oscar@imagencentral.com";
    $to = "fernanda.toral@consultoriagrumer.mx";
    $asunto = 'Se ha realizado una venta';
    $cabeceras= array('Content-Type: text/html; charset=UTF-8','From: GRUMER <no-reply@consultoriagrumer.mx>','Cc: Oscar Aparicio <oscar@imagencentral.com>','Cc:Traduccion Grumer <traduccion@consultoriagrumer.mx>');

    $cuerpo = '
    <!DOCTYPE html>
    <html>
    <head>
    <title>Page Title</title>
    </head>
    <body>

    <div style="margin:0 auto;width: 700px; font-size:12px;">

      <div style="text-align: center;">
        <img width="200" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPsAAAA/CAYAAAAmC74EAAAgAElEQVR4nO193W/bWJanXhfYwGrRCmlRirm2bCuxa0aY7cbW9KIXHGB7ql01mXJNTc8OahsLYReDsSV+XEpKo96W29XVTmI7dCsKTVO0qHaSSmGnu53P7sXuA/8E/wn6E/Q4D7PVZx8uL0lRJCUnTsXu1QEuYIuXh/frd++5555zbio1pSlNaUpTmtKUpjSlKU1pSlOa0pSmNKUpTWlKU5rSlP7IaU3Q+Otb2saNqqaOpj31va07G6vVu+V3Xc4pTWlKZ6QS2ubopoZY+cBhBQsYqQs0SbIFOREnWraAlk1gZB0Y2QBa6kEW9Zy5+iEqIY2b5FscOuBpZEB2kqToOCEDKMWATN3szyqWk5N+pS5VzTNPNmvVPTUnmZCTjMjEyoZzVp4rv/1swD3/GAqv1qHwux/C/KsfAvfqgxOvvq8+LM+/XMfPX63D/Mt1eO9/fww/ePjpRphX6fO9ypXmL4FSTMjK3chES12Yk44HZy1nFC1v3dmYEzrwHekxfEd+CDnhEAq1+8BKbWAkE7LSI6DkR0ApJkzCb626o7KiCbiNE5JoxSfJgILUgoLUAlawgBUsyMv3Y/ulIBhOodaDQq0HXE2HgtgGGhlAKSZQiuEmC7LIAkoxgUYGsJIOBcGAvPDQYcXHdkE8qpQnHL+XlspI45Zr+zYrtYFGGMCMZAEtdYFSLKAUDDhWagMrtSGr6EApBtDIAEYycV7ZAkYygZXaUBQ0Z7V6t5L0TQ51+JxkAi3HJGS4SQcGtXGSdcgiE9L1LmSULuQk3KnXRKO/KLYSvxekteodlUxUuPyhJHfOBHb+YYUv/ebHsPD8I5h/9QHMv1wH7uU6LLz8CHn1fbmuFV6tQ+7368D8r3XI/e4jWP4/fwvvP6lwYX4ltKNSigGzcgdoqReZsvIxUNLXsLh1ODJZnJUK4oMTRjK9iZ1MhDTCEyye3C3IKjqUkZYex29Z2FGzKKJdR5KVkExgUBtycgsKog7zgg55tB/bL6xsOGRSYKU25CQdcmIXGKkLWWRCFpnAiMeQE469xQpP7njSYdx6F0QdlqvayWpV++OSWMtIS8/JHS2qI2gZNxClmJBu6EDV28C6My2NMOB9sMck2bLjvp13wZ70PgE8BiYGZxaZkFHwJJST8QQwUz+Gmfox0OjwtIS2uXH1Xqtuq/hdI3KiYdDZwP7+4/+irvz2Uyg+/wgWXnwACy/WoXRyE95/8vdeWbiXH50WXq1D/ncY6PlXN2H+dx+fRvErSZqaRRbMSke+ZBVKBOxc1TyJ4jEpcchOx/c/lqxIP2QVHUrCNj+OZ1HaUTN1ty2T+lc2vYlkNGHJMSfpMC8YMC/owKL4lZ2RO05OtIAVTW9c5MQu5ISe972ccAyM6IJ93NiVLMhJD9U3adsLQ6tVrXxNOugnAS2r6EDVdUg3DMjUceNg8QyLu+M68ioy4sHePOBjV1aPBxa7hsRXV4JgZGNopU/X8Qyel1uDcYD/7uaXKie08Op1DmBf/fVPnOLTT2Hp2Uew8nQdVp6uw59/9TceCN9/8vfcwvOb7kTwASw8/xgWnn8Mi69+VInityJrJxTqQkbueKvSaLKAEXvAVa2JVts4YpFZeZdgj6sfIxtQEAyYr5lQqHWBFbrAoPjtVTTYLQx4yfAWCkoxgarrkFXaYwCPV3uuFj+GLwWtVvcqnHg4mGRlzbr7HiyWkf0U3nMlvctKOiyi3VgRk2l2+HEzK17FepCVsdhKSz0sbokY8Hj/ZUHGTXhPZgKNDiNXTELnCfbySSVdPPlPUHz6CSw9vYnB/uwD+MHjH1dInu8/rlSKzz6G4vMPoPh8HZaefgJrv/4x8CeVSJAW0a6TrlvwHeUAqLoemWiERdCCYMJi1axE8ZmE5mTz5ExgF7fHfqso7b052N26zdcsYIUe5IQe5MX4fhkCu4S3fp6YLhnu/t2AdMOAdEOHTH0CydQd59fEDor77oWmItL4haoO87VxgHX3MWIX74NEPNvSyAdIUiMt1u4lKnMY9IRnpG6yGCWS7+OUE7vAiD2gxUeQlR5BRulBRul6YM8oFqTrXZipH8OCdF+N+/aa8OW5ifHLLz7dWHr6CSw9/QSKz27CAhblB0Egv/+oYi88+wQWXqzDwvOPoPj0U/h3jyuxK8a1xu3Tf3XrAL5Tvw/Zeisy0UrL1WMYwMj2mRWKqRTexiUDMXJlV8fxLUp7KqVMAnZXcotItGwN7adZwYLF2gQru2Dh/brc9vbu/pbUgHTDhCtNC2YaFkyiV6BlCyh0PCgj+7Wlp3dCS0grs7I+KAgGFIQJwC72gKva/dJm216r7qg3hG11WdpWi9Keyon7J6ysn8a9f716N3EvyaB/4ukEsBcEw1muPlDXqppa3ryjljfvqGubu87y1oM+WzuGrPRVItivSQf9uG+XhG2VkfWhiet1wV58ua6tPL0JKycfu+L5R7D08oMhIH/3q58MFp59AtyLj4B7cRPmn/4N/PnD/xYr9bD1O/Cvmw8go9wHWmlFpmy9BVmljbXMqAuTnoIEaUlsRYrwbwr2ZWE82FlJhwVhH5aq9yLTypabqruwUr0LN7buwr/9h9sJYLccsjD5YG9BTm5DFhmQQwdqUdLUorSnLki/VFn5gc3KhjNO6qAUCyj5GIq19uVa3Rdq+mlBMPCM565sURWdkzuDOflIY5DNjePJITvNIrMSFgev1+4kNs5s80ki2IvCL9W4d0vCAc9Ix/2s3HXF+K6ntMP7PR3mxRasVh9EalTXqjtqLtCpbwL2hVd/0V95uu6D/emHUD75jzx5/v3Hn5XXfv0pFJ99jIH+4mMoPN+InYhSqVTqGtKAQW2gpQcB5eRwyiIDZhompBsm0EiH1dovzjwYC8K4wT4K9hXhF2MVguPAnkMd9axlHUdhsGNNPj7FoertWCmTQ3Y6hzpqVP0zdbzHz0k6/MnWLxK3hheKOOmBWhBMVyQ3PPEGH3PpXsrLbed1VolUCh/hLdb2bVY0xq40s02b95RtEakk7KlJ75fQAZeXDgfe7BsAOjk1uCbqkQBYq+6pZN//JmDnn2xwxRd/4SrlbkLx2U248ZubQ0C+fnITLT29CQvPb8L8y5tQeHkTCs//WovjyX1uc9ekB8BKOsyJB7Htk0VEHMUKqeu1O2cajByyOe+IKwrsAfsGRsJbuKyiw5KwPbZtLgrYsfSmJ4KdUFH4pVoQDE8fRcumN6bmBR3e+8fbE9kYvHMqIzWdR/sDIpJg44MuZJEFmboBVGMfsvV7cLWxfy6axxI64MblmW12+CQx70Y1GeypVCpVFPe1IVEcYa0rEePy6EEkjxvVPTUO6GcB+/efbFSKL34IxefrUHz6I1g++RG8//hvh7658vRHzsKzvwTu5Qf42O3lh8D9fiO2ffLNDs/KHSC2C3GJUvC+M1PHg3NeaMMSmvxsmEU6SjwNkQ1fL+CefdPobGDPotj2VcfxOCuNgF329+pZNJkx0FKtNSD6qZy7lWWFLnBbPVjaNOFSGNysCf9DzaF9SNctyCg9YAUCdvcYot4CFu19q0cM447eblR31HE8StW9ClZQRaccOozksSzsqVgJ9GZg//ePP7WLzz8A7uU6/JtnH0Lx6YfAh4xklk9+BAvP/hLmX30Aud+vA/firxJX4Hyzw8/JNlZESt1YBRaxBMsi3xKNRoexEkOY5tCD03Fgz8lYFGYFwt8ATtwdC5yLA3b32BZZE4G9tLWPeYjuEbPYBVbowXz1GOarXcijA/68y33uxMl7fRq5yhzF70gGtVxFhtn/trWNRXSfZ8X4wVYS7qjjeCyJd+PBLlnAoGijCA5p6kwD7/HfBOw/ePjjQfH5RzD/8ibkX/w1cE8/HXqPf/gTfuW3f+WD/Xc3YfU3/pFcFOXqh+qcbMOc9KsIsB8NfG21CayIz6IJGBkUr5QMUglpXNKx05zcGeQkn/98DQ9+fKypXzqwU8pkYC8K+05W7gWOlvHpT060gJF1mG3e58+73OdK7K0HZWLx5qe2K6Ltw7zYgrXNDv9tl+s8wF4UNS0O7LRswdUYsC9I5wP2D83/Wnn/8Wfqnz35TP2zJz9Rv/f4H4bE6A0bpf/Drz5Tv//w79T3n/yd+t2v//NYJVoy2C3nKjrqB8GO29A1MZV1WBO+4Me2W01DicdismUzrhiLz/Lxd7LIAgp1gVOTF4Z3D3Z/DGCwTybGzwttoFDP2wp6th4y1oucd5nPnTLNI5XYtkelBXF/otXgvCmPksX4kpAsxpeRnb4m6YNkMd6KPN66UT0fMf5t0Fz9UEtY2TW6foT8/7G2OOMqklhJh9Xql2O3Y6x8P16ElztODlkbtGx5x5pEF4IHfw9m0T/xSfzfLdi7nhENNsbqQlYZL40UaxpiJKyUY1ALWHkfWEnHq7zQg5Wt9rk4Hb1VopSeQynmkOdYcM+XdMT1NolpYq+32KM3Kb5cZWSnWcE6zbl7y6jESu1YM9K16o4ad8b+rsHOIMOJA/vV+pHKfG5zYcvBdAMbjLCiAdere4mDkvn8IFGEZ5FZyaMOT8Cerlue01NOtLCtOXrCJ32jJOypcUAfTfFKSDIh59GBOrbdIsGOTawZORnsS1WtPCd3sAJbMT2pNye3XbPwLlzf2n8jH4RvhVix1yfHJhjsFtDiV0CLXwGlWFBEGv8uysUgrI2PS1EdXEZaelHUKpzU6uNZN35VLwpaLGBLwh2V2EZfOLArZiLYU6lUKossJyt3gZKPgUI9zysRa+V1WBTizZSx4xP2Bgsfvc3JnYFrN1EmYjw+gsLn7ayIj24ZZFeS6jAp2ImVZlTCYDc9g5ix7TYixuvepMFI0WL8EnpQ5sQHNjGbphR8to59Qfzj6Exdh0V05429C986zVfJTOeu6nIXaPFrD+xn4bWEvizPNvcdBh04jNxxZpWOk0WGUxDbTl5uO7ONAyfd7DjpRs+hlJ4zJx/FaocZZCeCnZZNzzyXGM6Qc8+cpLt7KhOGzuo95ZwJJWGHj/v22wQ79/kTflbo8LPCAc807/NM84BnUIdnUIfPNw94Xk12WplTzMGcbMOcbEPYEWi2afOpVCqVrZsV/Dv2F/BcgcnePcEBiZHNPu0qngjgPVDIR7afz/COoMjxleeHHnPKQei8wc7Uzwp2/+jNHx+W6y2IeRPPQdyGXQ/s6YbpOX6RcqYbxjvZ6p6ZsCbR8Jxassjy3SSRcSawF9E2n27oniNB2HDCM3BBeEVK9FIas7IzsgEFsQ0F0Q2gIHeBQngPRjqPko+B8hxkLN8bDx0l7ltvVPfUxG+/AdiDK6ZngebyzSrtsV5jWMQmA950+6sHFOpB2gU7p9ppfyAHrRB9X/CoLcwSulumFMN7Lyf0gBGxoxGFupBD9oZfjnbANt0Xq7PIAqZ+fmCPC17BSHj7QNX11wf7yGQecJ/1vo19LmjZ8lZ1yl3VWQFvW2abyduWC0Frwg4GFDF3RMNKk6vobDNWEe3w6YYOmUYLqHrb5ZXgj5wE9uZ4sLOS7mmb8UyMB6bv090DSj72fstJJnDCg9NxLp83qppKRNTzBjsePJY3+XntjfAgKqHJwe6BWMTHQfmmv+W6igzbXx1H01JEMA9O1jSyYmGnEexNlpW7wITGwlXlwSkj+Y4otNQFCnVdBdZBYvtMAnZGCkgKESk4WU4mxg87wiT5PpDve9sSd8UngVpo19S2IFjAVZO3LBeGPLBHJLwKd86kYSyhL3iqsQ85dA9YqeUdb7wu2ON9tfGKlkHHkEGPhgBOQE5LXU9sx2JuD3KyeTKJb/dFBfuasM0TsOfELhQEC+Zr2M1zpTpszEI1DjfiwE7LFuTF0aAWOdnsZxGW9PAZuul5MxblnaEt16xiOG8f7NFhwYL+53H6mzBFubiOA3tBwPWjEPat8KRDuQUsag8K4lFl3HcvDK1W75aTwJ6pT3b+SKiEvuBpZR/HBhP9PfPbADuljAG7bPmODsjuM2jyjrk8YDfdKC0GvLf585G+YuXDQVJoJy7gyISVbpYHMhJ/rSDqkJNbUA4F/JitH50QUTcMdhrpiVaAk4CdlXRYqu3Cja3bkalUve16vO3CWnW8p91I8IoJwI59REzPkYqRTOCEFiyL23a4PS4FJa/s4x1WgoQHYzDcTzxg3hTstOzHCAsGssCp6/Jvw9UJ9nNhuqhgvy7c2QiL8TlJh4LUgj+p/mxECiuK+1oc0HOSASzy3TJZ2dBwDEF9KKgDK7WBRfsj4L2KbDUB7ImLxDiwv51z9jOCnViRyjo+0ZCPgUaHg9d1ArsQFAtGV4N7lkCN36uq5dLWjlPabDtLm4aTFzsOjTqDtwH2vNx2SsIdtVS93Z8XsDMG0Z7iwawDrbSAqrcH6VuPzxQc8G2CfTiSzijYiwlgvyFsq8MKOmzQkpNbsLb1xUiZVqtaORLoRCnb0DwQzyF9kJNb2MebhBSTDWBQG9j66BjIIVv1lWWXH+wM6qgMsmxvvCIDsgr2dacQVoDSyIAFaefyuLKGiUEdx1/NfUMFMrMVxAdvZCwQ5H+eYC9Kvtfb9eqdk5xkQgY9ggx6hPeb0j7Qyj5Q9RZk6p0zzcjjwE6js+kyCJUEjScnA3FgX0LxcfaHwC72gJaOPd3E2tbPI9uSkY/6UYDPIgPSzRakPz/gqIa1kUWmG+Fm3wW75TlCRZm/FgRrIwnsSWLuRQM7I/unTiwyyzTqDHDgUgvSdcuNVuybIHO1g8sZd45BBzaNdDf8M/H9Nr242aykD+3tzs7/zcAe927QXLaMtPQcOhxk0DH22pPaUJDuQQ7dg2y9BZm6CYWEmOJhem9rdyPJxZWWzdeK/LIotipZuQdElPfOp924feNWxBXhyxO82pB48e6xomzAanU7cgAyyFaHJAHZ8oA8c6sN6Z8aGlU/sjGwcYQbYvqaRRbMIT1yss8jm08C+1rCEeJFADuN2tij0zX1DeZl0UEli0ygUA9HO3KDVNCy5YY9+xoWhWhT6wtNhcb9Dbq+C1TjHr5gQbHgyi0ceC8nYQVNQb7/2qt7EtizY4/e4pVLYX/2bP2gQoL9Z5U2MGgfCtI9YKU2ZBA+flupaRNFaylX75aJKBtX9jhf+OS2MBwK9bx4AYTXfLULXNUCVko+6izKqpO+dQ+DtGEChdxourIeq6Ri0BOOEfF5uQdG2bd8o+oH/Sw6HGSJ2KrgCEXE9HVZuB85qFn0P8s5oXdpwZ6tt+DKT1swc6sdaS5Lo84puVTCP+YzgZaOgan9GvLCo8GbRO19J1RGWjqPdgbZ+j6QSLFXbukw09S9cL0FqQXXazuvFWPrbYF9raqpI+8oWj9bb0GmgQdtQWoBKxq+eC93BpMGGLgmHg6SA1gY/XHeXUHKNzU+U8fx4FgBH5uRlb0gmMBVTciLh4mTalH8uQv2Fsw0dQ+42Jvty5H2IMQK1ql/oYcfsHHkRh03kci01wQ7cbtSEOJX9qQwWBcG7LfacOUWtqQL5y+i+/x8tQuF6jGe9JHuSlQ9z8L0KkrurwtJpapme+F2kAGZRhsyDWzkj0Px4FBOS6JWOSvvtwf20Ug1i+iLjWx9H0fXUXyrMWJsw0gWcEJ7InGeEw9Pkm6kySo6UBNG7uGQlqaV+6dUHd+UQww60m6MOBw3oAXZ+oNKEp8bm7tuGCU8oXmipazDe8IvYsXKRbFV8a85Cobpivd2zEkGFGvJwS5WtvbjV/aE47CLAHYatSFTx8dqtNSL3D4VhI6TQcdeW5E9PjFPphQTCki/XOJ8GWlc0EGAhCP2j7ZMz42RRvrJWVa0WLAjA7JKvPHF64A9lUqlZhv3HdKJ5M6zYGIkC1g0Po76e5t7lYKox4MdGUDVW8Ch24mA51QM9KyCAxtSdSx1UHUdZpp4u0QrLcgjbaxYuLJ1DxjZAKreds2Rgyt7vNhcRlo6Uze8SXASsBekFpTHXHF0Y+tu//KCHTt9Ue4JTtQ7RXSfxz4XJgwF1hy6L6EzOAseLgSxsqExMom66YbYVbDo4ltKYVvhvGgPuJplL8VEZw1SFhlOOAqpH430LYC92eFxeC1iSTdqcEOhyfZby1WtHz0gfVtwVjSgtLnff29zb+jSv5Jwn6fRoZZuHA4ydd0DOQF6pq5DuonBz8gGlKpa4qRRQhrHyveAVlqQbhgw07CG9+xjbOqpxuEJ1iz7wTeTwL4g7I49Ylrb3HFixfit+Fh048CeRR0n74Z2Lgl76nJs0tRlAYd/Lkp31CX0s0rcNyO18TIWy7PSo1jFKCu3bay518Efx7r/v6LDHNqfONzXhaAy0tKsfP+UQX7wfPdGVA/sZK9XECysYCL26Mh2riL75CqyVQbZKi3bWhZZThZ1PKB/W2BPpbAiLKNY8WCXHwEntseK4Ne3djdiwe4a8TAiVrbN1ywoCO4tJVUcm4xCPXxsUzcCYNe9lRVvl1pAI33s5MM0D/ic3AIGtSDdMGGm0R0C+7i6LKLdDUoxYKbecx2RksG+MibUdyr1+mBfHgt23yQ6OcYenvDwdw2YbcZf7DgKdvdOQmTGruypVCpVRtscJ+5iS0xXKiJWhngctyGHdqGExkcAulC0hLTyHNIHRBPt7SldMX6mqcPMrfZQVNFRMTl4zGOOAPz8wD6qoCNUQhoX9N4KOsjkRAvHTRPaE/nq08g8iR+Ulmd3T0s9N/hgDxY2e7CweQzz1WNghZ5noEG5ondW+gqy0lcYtLdaQH0+XheSRx2eq+LJhJwBnwXsqVQqdU3eH6SVnucdmAT2SY4W/ZDbEWCvxsdRHwf2sAQVZ26N/ehN8AyVULw+ZkSMV/Yh27gLVGMfaDnZlXu1+nOblVrYbBYdQ8ENMMnIuhfI4hoaLwldOFpCD8p5WR9kkeVdiEh8h2eaBly5hUVSGiVffDe0B5O9/X4gGk4y2GfHHr3Fgz2Vwl5fvoLO91PGx4lYermKrLEdhCWew1MShZSEewp6ClIIB4pghEdQqD6C+eoxcFs4zVd7rlstFgVp2QJG+Apo8WugUBeuNsZLGKlUKsXVOmhx0wKuigc63oO7579In8jIZ7m2a1OITH7DYMeiKe7Xq/Xos/UwrVV3VM/F1QM71lwvCvFx1JeFncSwVN64GXLLDTvzkAsYdWBFPAlOcrEjsWfI1jHYs/V7Y8HOIy09h1qDmYYJaaUHbA2DnZXakEP7brvpMFePvofgQlMJHXCzSuc0o/TcM2p8To2vUyIDxXIHSTsm6Z6LK1b04UCWmQZWLmXqOlCN+M6ZbdqJRjXLYy6JYJDNkRVgCKSByYeRDSigg8q49igjO51Bj0+J0Q4xOiJBMvB9X/hyyaz0CJ/Fijj5oYddmwXBcG8d7QEjPprYEosTjlQMduz3PnOrDTNNfINu0qlGkFarX5aDd5vRgf0ng9rAyvuQk1vA1Me3CeZ317seKovcMFh1LMXkUPxdfvgW1+it3UhKUJASXQgrtXBcg0Sw2w721+ji8ddoe5c7xmnjgzT70wN15hZud3wLjAHz0j0oSPveliIvtwZlpF4uZR2hHDpSKXQ8IBrL4dSNBDuD2uArNCwvmARxK8wqGOzphgGzyniwx6VxYE+lUqk8OlSTHGlY0QDWDbU0jheH7PRV9PAkg46x6CjrnoUhjQzvHrm00nPP9Y/x3lj23VG5mgFcTYeCqAMXcxtNHBXkjjZfw5FcqToedFdu4XY8i60+Kx/0PbAHxGVGMoGV2sBJ+xObAq8JO7wnPXlgx5NRtt4C5vPoy0CK0s5EFzsmJXLrKlVvu/HgWomutYxsOzjIRxfSDdO9YtxyLwON37MTKqt2+mpTH6Qb+JZcBrWhIO2DJ94rPchJOlwXf3G5lHVBwgEMj7QsOhpEuqmGOsEPLmABLbkTg+sjXRDxQM8iA2aVw1OmHn8ENi4s1SQ3wpSRnY5zxCFKx5xoQQ4djeVF6Cp6uJGTzT4OnIFneAy+Fly5peMrl5RHkFYeeTey0BIW/Qq1LlwTDZub4Eac0fY4cMj5PLltlGjWc/Kob3oc5dCRShSMjNgDRngEWQnHHGTEYyhVJ7/1Z03Q+JzYjdizu2GwmtEhyEvCnkq2aHGRaMYlMsEQwFONfZhtxscVnFU6TrrehZkGTuR8PSccQ04YD/ZUKpUqNo/RbP2xt3jRCCuxZxpdrPhUTMjJLShdRvfXMF3f2t0oVffs0tZef7G2PxyTfCR1PTGWE9qwUts9LW/etsubdyuTKH9Wq3exB11M+t6mWpmozLUdNPRu7bZTqt12Vrd2nLXNXWd1c9cpbe2e2YutLGzzf7q5a5eqd/s55TZkmrtw5actuHLLwKu6fIxNWus6cDX99Po/trXy5uu7R65u3dFKtW2nVNt2loQdpyjsOovCrlMUdp3V6t3KpHxK6IBjRVepJfQgJzwCWvwaGOERcFUTvlf98kwegqUtzSGpKGhOUdh1SsJtpyRsO6sxTj3f2/xZpbSF231184xpa8dZ9fpyF7eFuO0UxS+covzfY1fVJXFP40TN4UTNWRQ0Z6mGy7y6idOk9S0j8+RPa7vO2hbuh0W3HxYFze2PHWeSk4xLR0VBI8ES1XDKIWsjjx7yS1XzTIPnMlIZqel8c5uf/fw+P9vs8Hlk8xyy+biV7V3TsvBLNY86al7qqAXB2sgjmy8Kl+DqoilNaUpTmtKUpjSlKU1pSlOajAAg/c/wz9y7Lse5EQBUAOAEAJw/wB+cb+AbGwD4d12ucQQAZYD/6wD8Cx/zPA0ADgBUzvGb58rv2yaAPzgAf3jt0Fq4zcEJpj8AnHwDoAIAdz5lBAAA9Tx4Tfi92D79Br7RvoF/gfOq2zslALDdxnUAd5gKAP1vu8FfhwCAd8vZB4CR83J3AjvXerjtw58Xv2+bCEDf4H3S5k4oDdzEn0MZv22wR/ZpoK6Vb6ssb43cSkZWxl3tIw1OAIB7nZnOXWn5pHcnyXu+8/EAAAVYSURBVBPISzoDAEALPdsIPFMj3i2fJ2gJv4Q2G1snN0/sCYbb7hO1TeCdofaMA/uk7UHaPOY7/Rjek9Yr7f4/0meBesQaQU3QB4nP4/KPyTPxeH2n5M7EExlSEEC5gwXIbBjT8V5nBWdHGCYn2Ohuo9kReZIGCeFNJi0+wGsA7tYkOHDcDuwHvjEAd7IDABTkE/qt7P4/jh9AYOIBX7og1A/WyeV3EuLRh8DgAX87Em6bxEELuL+CdAIApxAAZEx7xAZlgJg+d5+pANAP/F9x+cXVPapepC9VNw8Ho+07VHe3DqehPFroeZhH8DnAcJ9vRLSJGm4DGO3bi2lBFygwP2H+YIdVwJ+NJwW7N4jcxhzA8KBzQnl4twP7kLxagvu3l9fthAH4g4mUhUwCp275gxMM5+ax3Txe/SAg+STxc39D5H33/0qgTmRQ9kP8AABQoE5Dk7D7zin4kxnJEyuOQwA0bjk58AHhhMrvuH+T9vDKn9Tmod/Jyn7i/s+537IDvE9JvyT0OZkcgm2MwJ9sKxHPY/vATeE+D/cRBNq2HCg3yU/aMthHQPoEhscRH9cn74wCBU5H/OZR4BkEOyqYP4J3sDMiJ5VAp5UDDbwRykN+ryTVIZCXDFyPFwyDk3wzHeIzgOHBQ8A1IvmE+KEofhHlJBMHT8oQ4hf+hgY+IMl2pBzKE/l74Hk/gq8H7rjyB/JEWoLBsDRFkg3+np2A0obApBZoB3DLTv6uxPGP+J13+9lOqkNEWw7inrt5AHywn4TLHajPIFTG8HgdKfeFIIgAIfj7D540YuAZwOi+eGKwR+RJk+/H5XHzncY1YPi9QMefBH5zAmVRwZ8QgiksZZBJZmSQhPidQPLqGhRTieQBoTJ7/AK/qYHBrJJBFsE/dnC5zyoRvzth3jHtEceXjBuS9zTwfzr0nSjeAIEtYLh9w/WC4dXeCf7tPvcmxpjyOknPA9/jA/lH6g7u5BpqAz7iW5Ht9s4JEvbsMAqkkYEV12ERnRWVhwCKD+ThYsqohn+PKqP7mx0x6EhZyODmI1I5xIMMqkqIf5CfBhGrQCAv+V6Qd7hdRwYIjII9qv3SUeULPB/pL/f3UxgFe1R7cDF8o9qcbJvCuojTON6BPg9LLKReqvt/3+Uf7NNw+yT1wQkAJMYuIOMwUO4R5yIISGRwScFOBtKIyEaeBf4fGTzgAxYFfuODeQP/h0XK4L7aU6iF8gwpxyLKGCsRBPI4gbJEbgvc75B9ZIV0JPgiYHgQh+sWyc9tw9OIZ2cBO+d+IyxV2ZAgnoKv9AuChNSN8I4rfyUVQ1FtDv5+/TTQjiN95+YLjpWoPrdD4yeq7k5EHVAoD+kDUudK4Bn5Paj9592/CSbC5e6Dr4+4fGBPpYYa9xTw4NbAFzfDGks14n0ixtkwvCKq7nPSMERJogbeqQT4kE4heZy4bwbeORPYQ/W1A2UhqxvZ96uh9/uBgRHH7wR8G4WBy2sj9IzknRjs7v8EOE6obSqpGArUZQC4T8m3w1uWuPbgztLmEFBsBX47DXw/2Dac+5z0eT/wbTI21ED5gjwIz6g6jPRBTB3D5QAYPskJjmky4QfzX06wp1Je4TXw91VquLMh3vAgHXjXdjvdyxtomHC+KF68+yw2Tyg/N65x3QHFR/x24n5HCw2+8ApBVmj+rPwCdQo+K8PwZBHFj4doxdXEbeO+w0X0TSWCd2z5Y3iqMc823LYKShMoNK7C25FgvbRwe4d4nJD2OmsdxvRR1HgPltuT/IJtEPMNPvX/K8EEq++UpjSlPwJyV5PXNs+c0pSmNKUpTWlKU5rSlP546P8BoVCa0fn7PvgAAAAASUVORK5CYII=" />
      </div>

      <div style="text-align: right;margin-right: 70px;">'.date("d").' de '.date("F").' del '.date("Y").'</div>
      <div style="text-align: right;margin-right: 70px;">Folio: <span style="color:#92d050; font-weight: bold;">'.$usuarioTMP.'</span></div>

      <div style="text-align: left;margin-left: 70px; margin-top: 40px;">Se ha realizado una venta a: '.$usuarioID[0]->nombre.' '.$usuarioID[0]->apellidos.'</div>
      <div style="text-align: left;margin-left: 70px; margin-top: 5px;">Teléfono: '.$usuarioID[0]->telefono.'</div>
      <div style="text-align: left;margin-left: 70px; margin-top: 15px;">Concepto: '.$name_servicio.' de '.$_pdf_idioma_original.' a:</div>

    <div style="text-align: center; margin-top: 15px;">

    <table style="border: 1px solid #92D050; border-collapse: collapse; margin-left: 55px; font-size:12px; text-align: center;">
      <tr>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">SERVICIO</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">IDIOMA</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">Palabras</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">PRECIO UNITARIO</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">PRECIO TOTAL</th>
      </tr>
      '.$cuerpo_rows.'
    </table>

    </div>

    <div style="text-align: left;margin-left: 70px; margin-top: 15px;"><span style="color:#0070C0;">Tiempo de entrega máximo:</span> '.tiempoentrega().' hábiles</div>

    <div style="text-align: left;margin-left: 70px; margin-top: 15px;">Archivos a traducir: </div>

    <table style="border: 1px solid #92D050; border-collapse: collapse; margin-left: 55px; font-size:12px; text-align: center;">
      <tr>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">Nombre de archivo</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">Numero de palabras</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">Tipo de contenido</th>
        <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">Tipo de servicio</th>
      </tr>
      '.$archivos_rows.'
    </table>

    <div style="text-align: left;margin-left: 70px; margin-top: 15px;">Texto: </div>
    <div style="text-align: left;margin-left: 70px; margin-top: 15px;">'.$texto_mano.'</div>

    <div style="text-align: left;margin-left: 70px; margin-top: 15px;">Instrucciones finales: </div>
    <div style="text-align: left;margin-left: 70px; margin-top: 15px;">'.$usuarioID[0]->instrucciones_cliente.'</div>


    </div>

    </body>
    </html>

    ';

    wp_mail( $to, $asunto , $cuerpo, $cabeceras, $attachments);

    $htmlplug = '
    <center>
      <h1>Gracias por tu compra</h1>
    </center>
    <center>
      <p>Folio de compra: <span style="color:#92d050; font-weight: bold;">'.$usuarioTMP.'</span></p>
    </center>
    <center>
      <br/>
      <table style="border: 1px solid #92D050; border-collapse: collapse;font-size:12px; text-align: center;">
        <tr>
          <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">SERVICIO</th>
          <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">IDIOMA</th>
          <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">Palabras</th>
          <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">PRECIO UNITARIO</th>
          <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">PRECIO TOTAL</th>
        </tr>
        '.$cuerpo_rows.'
      </table>
      <br/>
    </center>
    <center>
      <h2>Recibirás más información por email</h2>
    </center>';

    $wpdb->update(
      $wpdb->prefix.'usuariosfile',
      array(
        'folio_compra' => $usuarioTMP,
        'usuarioTMP' => ""
      ),
      array( 'usuarioTMP' => $usuarioTMP ),
      array(
        '%s',
        '%s'
      ),
      array( '%s' )
    );

    del_cookie();

  }else{

    $htmlplug = '
      <div id="site_url" style="display:none;">'.get_site_url().'</div>
      <div id="plugins_url" style="display:none;">'.plugins_url().'</div>
      <div class="container grumer_principal">
        <div class="row">
          <div class="col-sm-8">
            <div class="border rounded customspace">
              <div class="loader_grumer">
                <img src="'.plugins_url().'/grumer/style/ULOADER.gif">
              </div>
              <div class="stepone" style="">
                <h5 class="text-center titulo_fileload">Archivos para traducir</h5>
                <div class="loadzone">
                  <textarea id="text_trasl" class="w-100"></textarea>
                  <div class="file_upload_section">
                    <form id="formuploadajax" method="POST" enctype="multipart/form-data">
                      <div class="fileupload-buttonbar">
                        <span class="btn fileinput-button">
                            <span><img src="'.plugins_url().'/grumer/style/clip_grumer.png"> Subir un documento (.doc, .docx, .pdf)</span>
                            <input type="file" name="file" id="file" multiple="multiple" size="1">
                        </span>
                      </div>
                    </form>
                    <div class="solopalabras btn btn-info"># de palabras para cotizar</div>
                  </div>
                  <div id="cancel_inicial">Cancelar</div>
                  <div id="textarea_num">Palabras</div>
                  <div class="textomasfile">Puedes arrastrar archivos sobre la zona de texto</div>
                  <div id="zone_file" style="display: block;">
                    <span class="instruc_text">Copia y pega el texto aquí</span>
                    <!--div class="file_upload_section">
                      <form id="formuploadajax" method="POST" enctype="multipart/form-data">
                        <div class="fileupload-buttonbar">
                          <span class="btn fileinput-button">
                              <span>Subir un documento <br/>(.txt, .doc, .docx, .pdf)</span>
                              <input type="file" name="file" id="file" multiple="multiple" size="1">
                          </span>
                        </div>
                      </form>
                    </div-->
                    <div id="file_drop_over_section">
                  		<p class="img"></p>
                  		<p class="text">Suelta archivos aquí</p>
                  	</div>
                  </div>
                </div>

                <div class="controls">
                  <div id="siguiente_text" class="npButton npButton_posr">Siguiente</div>
                </div>

                <!-- Modal contactanos -->
                <div class="modal fade bd-example-modal-sm" id="onlypalabras" tabindex="1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        Ingresa un numero estimado de palabras.
                      </div>
                      <div class="modal-body">
                        Numero de palabras: <input type="number" min="100" id="inputsolopalabras"/>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-primary btnselectlang" data-dismiss="modal">Ok</button>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              <div class="steptwo" style="">

                <h5 class="text-center titulo_fileload">Elementos para traducir</h5>
                <div class="file_line_box">
                  <div class="del_file_line"><span id="del_all_files" class="size_file">Borrar todos los elementos</span></div>
                </div>
                <div class="controls">
                  <div id="selec_idioma" class="npButton npButton_posr">Selecciona un idioma</div>
                </div>
                <div style="margin-left: 20px;margin-right: 20px;font-size: 9px;margin-top: 20px;">
                Algunos documentos pueden contener caracteres ocultos debido a la forma en que interpreta el código y diseño el programa donde se elaboró. El contador de GRUMER cuenta palabra por palabra los documentos y no por sus caracteres. Por esto, en excepciones podría no coincidir exactamente con el contador de Word o Pages.
                </div>
              </div>

              <div class="stepthree" style="">

                <div class="select_servicio">
                  <h5 class="text-left titulo_fileload">Selecciona uno de nuestros servicios</h5>
                  <div id="grup_service" class="btn-group" role="group" aria-label="Selecciona un servicio">
                    <button type="button" stype="traduccion" class="btn btn-success btnselectlang btn_tservicio disabled">Traducción</button>
                    <button type="button" stype="correcion" class="btn btn-primary btnselectlang btn_tservicio">Corección de estilo</button>
                  </div>
                </div>

                <div class="btn_all_languages btn_all_languages_from">

                <h5 class="text-left titulo_fileload">Traducir desde</h5>
                <!-- Button trigger modal -->
                <button id="langbtn_from" type="button" class="btn btn-primary btnselectlang" data-toggle="modal" data-target="#langone">
                  Seleciona un idioma
                </button>

                <!-- Modal -->
                <div class="modal fade" id="langone" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Selecciona un idioma</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">';

                        global $wpdb;
                        $idiomas = $wpdb->get_results("
                            SELECT DISTINCT idiomafromID, idioma
                            FROM ".$wpdb->prefix."idiomas_to
                            LEFT JOIN ".$wpdb->prefix."idiomas
                            ON ".$wpdb->prefix."idiomas_to.idiomafromID = ".$wpdb->prefix."idiomas.id WHERE ".$wpdb->prefix."idiomas_to.servicio = 1
                        ");
                        foreach ( $idiomas as $res_idiomas )
          							{

                        $htmlplug .=  '<span id="from_'.$res_idiomas->idiomafromID.'" class="badge badge-success custom_badge lenguagefrom">'.$res_idiomas->idioma.'</span>';

                        }
                      $htmlplug .= '
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btnselectlang" data-dismiss="modal">Cerrar</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

                <div class="btn_all_languages btn_all_languages_to">
                <h5 class="text-left titulo_fileload btn_all_languages_to_hidde">Traducir a</h5>
                <!-- Button trigger modal -->
                <button id="langbtn_to" type="button" class="btn btn-primary btnselectlang disabled btn_all_languages_to_hidde" data-toggle="modal" data-target="#langtwo">
                  Seleciona un idioma
                </button>

                <!-- Modal -->
                <div class="modal fade" id="langtwo" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Selecciona un idioma</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body"></div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-primary btnselectlang" data-dismiss="modal">Ok</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="table_all_languages"></div>
              <div class="controls">
                <div id="atras_idiomatolementos" class="npButton npButton_posl">Atrás</div>
                <div id="selec_calidad" class="npButton npButton_posr" style="display:none;">Siguiente</div>
              </div>
              </div>

              <div class="stepfor">

                <h5 class="text-left marginall">Selecciona el tipo de contenido</h5>
                <div class="showtipocont marginall">
                </div>
                <div class="controls">
                  <div id="atras_seleclang" class="npButton npButton_posl">Atrás</div>
                  <div id="select_tipotraco" class="npButton npButton_posr" style="display:none;">Siguiente</div>
                </div>
                <div style="margin-left: 20px;margin-right: 20px;font-size: 9px;margin-top: 20px;">
                Para una traducción certificada, selecciona la opción o contáctanos
                </div>
              </div>

              <div class="stepfive">

                <h5 class="text-left marginall">Selecciona el tipo de servicio</h5>
                <div class="showtiptraco marginall">
                </div>
                <div class="controls">
                  <div id="atras_selecontenido" class="npButton npButton_posl">Atrás</div>
                  <div id="select_traco" class="npButton npButton_posr" style="display:none;">Siguiente</div>
                </div>
                <div style="margin-left: 20px;margin-right: 20px;font-size: 9px;margin-top: 20px;">
                Estándar se refiere a los tiempos que proponemos; Urgente aplica cuando el cliente tenga una fecha límite y requiera trabajarlo con prontitud
                </div>
              </div>

              <div class="stepsix">

                <h5 class="text-left marginall">Tiempo de entrega</h5>
                <div class="showtraco marginall">
                  <h2>3 días y 4 horas</h2>
                </div>
                <div class="controls">
                  <div id="atras_seleservicio" class="npButton npButton_posl">Atrás</div>
                  <div id="select_fromalidad" class="npButton npButton_posr" style="display:none;">Siguiente</div>
                </div>
              </div>

              <div class="stepfinal">

                <h5 class="text-left marginall" style="margin-bottom: 0px !important;">Información extra</h5>
                <div class="showpfinal">

                  <form id="form_pdf">

                  <label>Nombre *</label><br/>
                  <input id="nombre_cliente" type="text" placeholder="Nombre" class="inputfinal" required>
                  <br/>
                  <label>Apellidos *</label><br/>
                  <input id="apellido_cliente" type="text" placeholder="Apellidos" class="inputfinal" required>
                  <br/>
                  <label>Correo *</label><br/>
                  <input id="correo_cliente" type="mail" placeholder="Correo" class="inputfinal" required>
                  <br/>
                  <label>Confirma tu correo *</label><br/>
                  <input id="correoconfirm_cliente" type="mail" placeholder="Confirma tu correo"  class="inputfinal" required>
                  <br/>
                  <label>Teléfono</label><br/>
                  <input id="telefono_cliente" type="tel" placeholder="Teléfono"  class="inputfinal" required>
                  <br/>
                  <label>Instrucciones finales (Opcional)</label><br/>
                  <textarea id="instrucciones_cliente" class="w-100"></textarea>
                  <div class="terminosy">
                    <input type="checkbox" id="checkbox_atyc" value="atyc"> Acepto los <a href="" class="clickshowTYC">términos y condiciones</a> para solicitar este servicio<br>
                    <input type="checkbox" id="checkbox_arf" value="arf"> <span id="checkbox_arf_span">Deseo recibir la factura (Opcional)</span><br>
                    <div style="margin-left: 0px;margin-right: 20px;font-size: 9px;margin-top: 5px;">
                    Se te contactará para solicitarte tus datos fiscales y hacerte llegar la factura correspondiente por el servicio.
                    </div>
                  </div>

                  </form>

                </div>
                <div class="controls">
                  <div id="atras_seleformalidad" class="npButton npButton_posl">Atrás</div>
                  <button type="button" class="btn btn-danger btnimpr disabled">Descargar mi cotización</button>
                </div>
              </div>

            </div>
          </div>
          <div class="col-sm-4">
            <div class="bar_desglose">
              <h5 class="text-center">Pedido</h5>
              <div class="narticulo">
                <span class="items">0</span>
                <span class="labelarticulo">archivos</span>
                <span class="labelpalabras">palabras</span>
                <span class="npalabrasarticulo">0</span>
              </div>
              <div class="c_tidiomas">
                <div class="tidiomas">Elegir idiomas</div>
                <div class="idioma_list"></div>
              </div>
              <div class="c_tipocontenido">
                <div class="ctraduccion" >Tipo de contenido</div>
              </div>
              <div class="c_tipotraco">
                <div class="ctipotraco" >Tipo de servicio</div>
              </div>
              <!--div class="c_traco">
                <div class="ctraco" >Calidad</div>
              </div-->
              <!--div class="c_cantpalabras">
                <div class="ccantpalabras" >Cantidad de palabras</div>
              </div-->
              <!--div class="c_formalidad">
                <div class="cformalidad" >Formalidad</div>
              </div-->
              <div class="c_tentrega">
                <div class="ctentrega" >Tiempo de entrega:</div>
                <div style="font-size: 9px;margin-bottom: 10px;margin-left: 20px;font-weight: bold;">Tan pronto como selecciones PAGAR y recibamos tu importe, nuestros colaboradores comienzan tu proyecto minutos después para entregarte a tiempo</div>
              </div>
              <div class="costo_total">
                <span>Total $0.00</span>
                <a id="boton_pago_f" href="'.get_site_url().'/wp-content/plugins/grumer/process.php" target="">
                  <button type="button" class="btn btn-danger btnpagar disabled">Pagar</button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal contactanos -->
      <div class="modal fade bd-example-modal-sm" id="langcontact" tabindex="1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
          <div class="modal-content">
            <div class="modal-header">
              Para esta opción es necesario contactar directamente al equipo de GRUMER.
            </div>
            <div class="modal-body">';

              if($options['mail'] != ""){

                $htmlplug .= 'Correo: <a href="mailto:'.$options['mail'].'">'.$options['mail'].'</a>
                <br/>';

              }

              if($options['telco'] != ""){

                  $htmlplug .= 'Telefono: <a href="tel:'.$options['telco'].'">'.$options['telco'].'</a>';

              }

    $htmlplug .= '
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary btnselectlang" data-dismiss="modal">Ok</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Modal terminos y condiciones -->
      <div class="modal fade bd-example-modal-lg" id="showTYC" tabindex="1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              Terminos y condiciones
            </div>
            <div class="modal-body">
              '.$options['ytSos'].'
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary btnselectlang" data-dismiss="modal">Ok</button>
            </div>
          </div>
        </div>
      </div>
      ';

  }

  return $htmlplug;
}
add_shortcode('contador-palabras', 'shortcode_end');
?>
