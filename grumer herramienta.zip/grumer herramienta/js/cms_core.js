$(document).ready(function(){

$("#save_new_item_lang").click(function(){

  if($(".idolditem_lang").val() == ""){

    typeaction = "add";

  }else{
    typeaction = "edit";
  }

  var site_url = $("#site_url").html();
  var data = {
    "action" : "cms-idioma-control",
    type: typeaction,
    idioma: $(".textnameidioma").val(),
    id: $(".idolditem_lang").val()
  };
  $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

    if(typeaction == "add"){

      $( ".items_cont" ).append( response[0].row );
      $(".textnameidioma").val("");
      $('#modal_add').modal('hide');
      $('.modal-backdrop').removeClass("modal-backdrop");

    }else if(typeaction == "edit"){
      var item_anterior = $( "#row_cms_item_"+$(".idolditem_lang").val() ).prev();
      $( "#row_cms_item_"+$(".idolditem_lang").val() ).remove();
      item_anterior.after( response[0].row );
      $('#modal_add').modal('hide');
      $('.modal-backdrop').removeClass("modal-backdrop");
    }

  });

});

$("#modal_add").on('hide.bs.modal', function(){

    $(".textnameidioma").val("");
    $(".idolditem_lang").val("");

    $("#idiomaorigen").val("0");
    $("#idiomafinal").val("0");
    $("#preciotraduccion").val("");
    $("#traduccionactivo").val("1");
    $(".idolditem_trad").val("");

});

$(document).on("click", ".action_edit_cms_lang" , function(){
  $(".idolditem_lang").val($(this).attr("id").split('edit_cms_id_')[1]);
  $(".textnameidioma").val($(this).attr("name_item"));
  $('#modal_add').modal('show');
});

$(document).on("click", ".action_deleted_cms_lang" , function(){

  var idlang = $(this).attr("id").split('delete_cms_id_')[1];

  var site_url = $("#site_url").html();
  var data = {
    "action" : "cms-idioma-control",
    type: "delete",
    idlang: idlang
  };
  $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

    $( "#row_cms_item_"+idlang ).remove();

  });

});

$("#save_new_item_trad").click(function(){

  if($(".idolditem_trad").val() == ""){

    typeaction = "add";

  }else{
    typeaction = "edit";
  }

  var site_url = $("#site_url").html();
  var data = {
    "action" : "cms-traduccion-control",
    type: typeaction,
    idioma1: $("#idiomaorigen").val(),
    idioma2: $("#idiomafinal").val(),
    precio: $("#preciotraduccion").val(),
    activo: $("#traduccionactivo").val(),
    id: $(".idolditem_trad").val()
  };
  $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

    if(typeaction == "add"){

      $( ".items_cont" ).append( response[0].row );

      $("#idiomaorigen").val("0");
      $("#idiomafinal").val("0");
      $("#preciotraduccion").val("");
      $("#traduccionactivo").val("1");

      $('#modal_add').modal('hide');
      $('.modal-backdrop').removeClass("modal-backdrop");

    }else if(typeaction == "edit"){

      var item_anterior = $( "#row_cms_item_"+$(".idolditem_trad").val() ).prev();
      $( "#row_cms_item_"+$(".idolditem_trad").val() ).remove();
      item_anterior.after( response[0].row );

      $('#modal_add').modal('hide');
      $('.modal-backdrop').removeClass("modal-backdrop");

    }

  });

});

$(document).on("click", ".action_edit_cms_trad" , function(){
  console.log("");
  var id_traduccion_real = $(this).attr("id").split('edit_cms_id_')[1];
  console.log($(this).attr("id").split('edit_cms_id_'));
  console.log(id_traduccion_real);

  $("#idiomaorigen").val( $("#row_cms_item_"+id_traduccion_real+" .traidifrom").attr("id") );
  $("#idiomafinal").val( $("#row_cms_item_"+id_traduccion_real+" .traidito").attr("id") );
  $("#preciotraduccion").val( $("#row_cms_item_"+id_traduccion_real+" .traidiprecio").html() );
  $("#traduccionactivo").val($("#row_cms_item_"+id_traduccion_real).attr("tradactivo") );

  $(".idolditem_trad").val(id_traduccion_real);

  $('#modal_add').modal('show');

});


$(document).on("click", ".action_deleted_cms_trad" , function(){

  var idlang = $(this).attr("id").split('delete_cms_id_')[1];

  var site_url = $("#site_url").html();
  var data = {
    "action" : "cms-traduccion-control",
    type: "delete",
    idtrad: idlang
  };
  $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

    $( "#row_cms_item_"+idlang ).remove();

  });

});

$('#dtHorizontalExample').DataTable({
"scrollX": true,
"language": {
    "sProcessing":     "Procesando...",
    "sLengthMenu":     "Mostrar _MENU_ registros",
    "sZeroRecords":    "No se encontraron resultados",
    "sEmptyTable":     "Ningún dato disponible en esta tabla",
    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sSearch":         "Buscar:",
    "sUrl":            "",
    "sInfoThousands":  ",",
    "sLoadingRecords": "Cargando...",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Último",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
    }
  }
});


$('#dtHorizontal_traducciones').DataTable({
"scrollX": true,
"language": {
    "sProcessing":     "Procesando...",
    "sLengthMenu":     "Mostrar _MENU_ registros",
    "sZeroRecords":    "No se encontraron resultados",
    "sEmptyTable":     "Ningún dato disponible en esta tabla",
    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sSearch":         "Buscar:",
    "sUrl":            "",
    "sInfoThousands":  ",",
    "sLoadingRecords": "Cargando...",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Último",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
    }
  }
});

});
