$(document).ready(function(){

  var url_values = new URL(window.location.href);
  var error = url_values.searchParams.get("response");
  if(error == "false"){

    regenera_ultimo_estado();

  }


  if($("#text_trasl").val() != ""){
      $("#zone_file").hide();
      $(".textomasfile").show();
      $(".solopalabras").hide();
      $("#cancel_inicial").show();
      var textio_numwords = upload_palabras($("#text_trasl").val());
      $("#textarea_num").html(textio_numwords+" Palabras");
      $("#textarea_num").show();
      $("#siguiente_text").show();
  }else{
      $("#zone_file").show();
      $(".textomasfile").hide();
      $(".solopalabras").show();
      $("#cancel_inicial").hide();
      $("#textarea_num").hide();
      $("#siguiente_text").hide();
  }


  $('body').on(
      'dragover',
      function(e) {
          e.preventDefault();
          e.stopPropagation();

          var textarea_size = $("#text_trasl").width() + 28;
          $("#file_drop_over_section").width(textarea_size);
          $("#file_drop_over_section").show();

      }
  )
  $('body').on(
      'dragleave',
      function(e) {
          e.preventDefault();
          e.stopPropagation();

          $("#file_drop_over_section").hide();
      }
  )
  $('body').on(
      'dragenter',
      function(e) {
          e.preventDefault();
          e.stopPropagation();
      }
  )
  $('.loadzone').on(
      'dragover',
      function(e) {
          e.preventDefault();
          e.stopPropagation();
          $("#file_drop_over_section").show();
          $(".loadzone textarea").addClass("textareactive");
      }
  )
  $('.loadzone').on(
      'dragleave',
      function(e) {
          e.preventDefault();
          e.stopPropagation();
          $("#file_drop_over_section").hide();
          $(".loadzone textarea").removeClass("textareactive");
      }
  )
  $('.loadzone').on(
      'dragenter',
      function(e) {
          e.preventDefault();
          e.stopPropagation();
      }
  )
  $('.loadzone').on(
      'drop',
      function(e){
          if(e.originalEvent.dataTransfer){
              if(e.originalEvent.dataTransfer.files.length) {
                  e.preventDefault();
                  e.stopPropagation();
                  /*UPLOAD FILES HERE*/
                  upload(e.originalEvent.dataTransfer.files);
                  $(".stepone").hide();
                  $("#file_drop_over_section").hide();
                  $(".loadzone textarea").removeClass("textareactive");
                  $(".steptwo").show();
              }
          }
      }
  );
  $("#text_trasl").keyup(function(e){
    if($("#text_trasl").val() != ""){
        var textio_numwords = upload_palabras($("#text_trasl").val());
        $("#zone_file").hide();
        $(".textomasfile").show();
        $(".solopalabras").hide();
        $("#siguiente_text").show();
        $("#cancel_inicial").show();
        $("#textarea_num").show();
        $("#textarea_num").html(textio_numwords+" Palabras");
    }else{
        $("#zone_file").show();
        $(".textomasfile").hide();
        $(".solopalabras").show();
        $("#siguiente_text").hide();
        $(".narticulo .items").attr("trastypetext","0");
        $(".narticulo .npalabrasarticulo").html("0");
        $(".narticulo .items").html("0");
        $("#cancel_inicial").hide();
        $("#textarea_num").hide();
    }
  });
  $("#file").change(function(e){
    var file_data = $('#file').prop('files');
    upload(file_data);
    $(".stepone").hide();
    $("#file_drop_over_section").hide();
    $(".steptwo").show();
  });
  $("#del_all_files").on("click", function(){
    var r = confirm("¿Estás seguro?");
    if (r == true) {
      $(".loader_grumer").show();
      $("#text_trasl").val("");
      $( ".file_line" ).remove();

      var site_url = $("#site_url").html();
      var data = {
        "action" : "deletefiles"
      };
      $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

        $(".steptwo").hide();
        $(".stepone").show();

        window.location.reload();

      });
    }
  });

  $("#selec_idioma").click(function(){
    $(".steptwo").hide();

    $(".stepthree").show();
  });

  $("#siguiente_text").click(function(){

    $(".loader_grumer").show();

    var words = "";
    var textio_numwords = "";

    if(parseInt($("#inputsolopalabras").val()) >= 100){

      words = "cotizacion";
      textio_numwords = $("#inputsolopalabras").val();
      $("#inputsolopalabras").val(0);


      $("#checkbox_arf").hide();
      $("#checkbox_arf_span").hide();
      $("#boton_pago_f").hide();

    }else{
      words = $("#text_trasl").val();
      textio_numwords = upload_palabras($("#text_trasl").val());
    }

    if(parseInt(textio_numwords) <= 8800){

      if(parseInt(textio_numwords) >= 100){

        var site_url = $("#site_url").html();
        var data = {
          "action" : "uploadwords",
          words: words,
          nwords: textio_numwords
        };
        $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){
          if(response[0].npalabrasmore == true){

            $(".loader_grumer").hide();

            $(".stepone").hide();
            $(".narticulo .npalabrasarticulo").html(textio_numwords);
            $(".narticulo .items").html("1");
            $(".narticulo .items").attr("trastypetext","1");
            //$(".stepthree").show();

            num_itesm = 1;

            if(num_itesm > 1){
              label_Elementos = "Elementos";
            }else{
              label_Elementos = "Elemento";
            }

            totwords = response[0].npalabras;

            $(".file_line_box").append('<div class="file_line"><div class="img_file icoowords"></div><span class="name_file">Palabras</span><span class="size_file">'+response[0].npalabras+' palabras</span></div>');

            if(totwords > 1){
              label_palabras = "palabras";
            }else{
              label_palabras = "palabra";
            }
            $(".file_line_box").append('<div class="file_line"><div class="img_file icofiles"></div><span class="name_file">'+num_itesm+' '+label_Elementos+'</span><span class="size_file">'+totwords+' '+label_palabras+'</span></div>');
            $("#selec_idioma").show();
            $("#del_all_files").show();

            $(".narticulo .items").html(num_itesm);
            $(".narticulo .npalabrasarticulo").html(totwords);
            $(".narticulo .labelarticulo").html(label_Elementos);
            $(".narticulo .labelpalabras").html(label_palabras);

            $(".steptwo").show();

          }else{

            $('#langcontact').modal('show');
            $(".loader_grumer").hide();
          }

        });

      }else{
        alert("El texto tiene que ser mayor a 100 palabras");
        $(".loader_grumer").hide();
      }

    }else {
      alert("El texto supera el tamaño permitido intenta usar un archivo");
      $(".loader_grumer").hide();
    }

  });
  $("#atras_idiomatolementos").click(function(){
    /*if($(".narticulo .items").attr("trastypetext") == 1){
      $(".stepthree").hide();
      $(".stepone").show();
    }else{*/
      $(".stepthree").hide();
      $(".steptwo").show();
    //}
  });
  $("#langone").on('show.bs.modal', function(){
   $("#langone").addClass("show");
  });
  $("#langone").on('hide.bs.modal', function(){
    $("#langone").removeClass("show");

    if($("#grup_service .btn-success").attr("stype") == "correcion"){

      console.log("calcula correcion");

    }

  });
  $("#langtwo").on('show.bs.modal', function(){
   $("#langtwo").addClass("show");
  });
  $("#langtwo").on('hide.bs.modal', function(){
    $("#langtwo").removeClass("show");
    if($(".idioma_list").html() != ""){

      $(".loader_grumer").show();

      $(".btn_all_languages_to_hidde").hide();

      var idiomas_get_precios = new Array();
      $(".idioma_list span").each(function(){
          var id_precio_idioma = $(this).attr("id").split("_");
          idiomas_get_precios.push(id_precio_idioma[1]);
    	});
      var site_url = $("#site_url").html();
      var data = {
  			"action" : "idiomas-precios",
        fromidioma: $(".tidiomas").attr("fromidioma"),
  			ididiomas: idiomas_get_precios
  		};
      $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

        $(".table_all_languages").html(response);
        $(".loader_grumer").hide();
        $(".table_all_languages").show();
        $(".costo_total span").html("Total "+$("#totalcompra_final").html());
        $("#selec_calidad").show();
      });

    }

  });
  $(document).on("click", ".lenguagefrom" , function() {

    if($("#grup_service .btn-success").attr("stype") == "traduccion"){

      $(".loader_grumer").show();

      $(".idioma_list").html("");
      $("#langbtn_to").removeClass("disabled");
      $("#langone").modal("hide");
      $(".tidiomas").attr("fromidioma",$(this).attr("id").split("_")[1]);
      $(".tidiomas").html($(this).html()+" a:");

      $(".tidiomas").css("color","#28a745");

      var site_url = $("#site_url").html();
      $("#langtwo .modal-body").html("");
      var ididioma = $(this).attr('id').split("_");
      var data = {
  			"action" : "idiomas-from",
  			ididioma: ididioma[1]
  		};
      $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){


        $.each( response, function( key, value ) {

          var ccs_activo = "";

          if(value.activo == 0){
            ccs_activo = "badge-warning";
          }else{
            ccs_activo = "badge-success";
          }

          $("#langtwo .modal-body").append('<span id="to_'+value.id+'" class="badge '+ccs_activo+' custom_badge lenguageto">'+value.nombre+'</span>');
        });

        $(".loader_grumer").hide();

        $(".table_all_languages").html("");
        $(".table_all_languages").hide();
        //$(".btn_all_languages_to").show();
        $(".btn_all_languages_to_hidde").show();
      });

    }else if ($("#grup_service .btn-success").attr("stype") == "correcion") {

      $(".idioma_list").html("");
      $("#langone").modal("hide");
      $(".tidiomas").attr("fromidioma",$(this).attr("id").split("_")[1]);
      $(".tidiomas").html("Corección desde: "+$(this).html());
      $(".tidiomas").css("color","#28a745");
      $("#selec_calidad").show();

      var site_url = $("#site_url").html();
      var data = {
  			"action" : "precios-correcion",
        fromidioma: $(".tidiomas").attr("fromidioma")
  		};
      $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

        $(".table_all_languages").html(response);
        $(".table_all_languages").show();
        $("#selec_calidad").show();
      });

    }

  });

  $("#langcontact").on('show.bs.modal', function(){
   $("#langcontact").addClass("show");
  });
  $("#langcontact").on('hide.bs.modal', function(){
    $("#langcontact").removeClass("show");
    $("#langtwo").modal('show');
  });
  $(document).on("click", ".lenguageto" , function() {

    if($( this ).hasClass( "badge-primary" )==false){

      if($( this ).hasClass( "badge-warning" )==false){

        $(this).removeClass("badge-success");
        $(this).addClass("badge-primary");
        var listo = $(this).attr("id").split("_");
        $(".idioma_list").append('<span id="listo_'+listo[1]+'" class="badge badge-success custom_badge">'+$(this).html()+'</span>');

      }else{

        $('#langtwo').modal('hide');
        $('.modal-backdrop').removeClass("modal-backdrop");

        $('#langcontact').modal('show');

      }

    }



  });
  function upload(files){
      var site_url = $("#site_url").html();
      var form_data = new FormData();
      $.each( files, function( key, value ) {
        form_data.append(key, value);
        $(".file_line_box").append('<div class="file_line"><div class="img_file icofilesload"></div><span class="name_file">'+value.name+'</span><span class="size_file">Calculando palabras</span></div>');
      });
      $.ajax({
         url: site_url+'/wp-admin/admin-ajax.php?action=submit_content',
         dataType: 'text',
         cache: false,
         contentType: false,
         processData: false,
         data: form_data,
         type: 'post',
         success: function(response){
          $(".steptwo").show();
          var obj = JSON.parse(response);
          var totwords = 0;
          var alert_error = false;
          var num_itesm = 0;
          $( ".file_line" ).remove();
          $.each(obj, function(i,item){

            if(item.error == false){

               var claseimg;
               if(item.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"){
                  claseimg = "icodocx";
               }else if(item.type == "application/pdf"){
                  claseimg = "icopdf";
               }else if(item.type == "application/msword"){
                  claseimg = "icoword";
               }

               totwords = totwords + item.npalabras
               $(".file_line_box").append('<div class="file_line"><div class="img_file '+claseimg+'"></div><span class="name_file">'+item.name+'</span><span class="size_file">'+item.npalabras+' palabras</span></div>');


               num_itesm++;

             }else{

               alert_error = true;

             }


           });

           if(alert_error == true){
             if(num_itesm >= 1){
                alert("Algunos elementos tienen menos de 100 palabras ");
             }else{
               alert("El elmento tienen menos de 100 palabras ");
                window.location.reload();
             }

           }


           if(num_itesm > 1){
             label_Elementos = "Archivos";
           }else{
             label_Elementos = "Archivo";
           }

           if(totwords > 1){
             label_palabras = "palabras";
           }else{
             label_palabras = "palabra";
           }
           $(".file_line_box").append('<div class="file_line"><div class="img_file icofiles"></div><span class="name_file">'+num_itesm+' '+label_Elementos+'</span><span class="size_file">'+totwords+' '+label_palabras+'</span></div>');
           $("#selec_idioma").show();
           $("#del_all_files").show();

           $(".narticulo .items").html(num_itesm);
           $(".narticulo .npalabrasarticulo").html(totwords);
           $(".narticulo .labelarticulo").html(label_Elementos);
           $(".narticulo .labelpalabras").html(label_palabras);

         }
      });


  }

  function upload_palabras(palabras){


    textoAreaDividido = palabras.split(/ |\n/);
    var textoAreaDividido_f = new Array();
    var index_f = 0;

    textoAreaDividido.forEach(function(element, index) {
      if(element != ""){
        textoAreaDividido_f[ index_f ] = textoAreaDividido[ index ];
        index_f++;
      }
    });

    numeroPalabras = textoAreaDividido_f.length;

    return numeroPalabras;
  }

  $("#cancel_inicial").click(function(){
    $("#text_trasl").val("");
    var site_url = $("#site_url").html();
    var data = {
      "action" : "deletewords"
    };
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

      window.location.reload();

    });

  });

  $(".btn_tservicio").click(function(){
    $("#grup_service button").removeClass("btn-success");
    $("#grup_service button").removeClass("disabled");
    $("#grup_service button").addClass("btn-primary");
    $("#selec_calidad").hide();

    if($(this).attr("stype") == "correcion"){

      $(this).removeClass("btn-primary");
      $(this).addClass("btn-success");
      $(this).addClass("disabled");
      $(".btn_all_languages_from h5").html("Corección desde");

      //$(".btn_all_languages_to").hide();
      $(".btn_all_languages_to_hidde").hide();

      $(".table_all_languages").html("");
      $(".table_all_languages").hide();
      idiomasfromservice(2);

    }else if($(this).attr("stype") == "traduccion"){

      $(this).removeClass("btn-primary");
      $(this).addClass("btn-success");
      $(this).addClass("disabled");
      $(".btn_all_languages_from h5").html("Traducir desde");

      //$(".btn_all_languages_to").show();
      $(".btn_all_languages_to_hidde").show();

      $(".table_all_languages").html("");
      $(".table_all_languages").hide();
      idiomasfromservice(1);

    }

  });

  function idiomasfromservice(service){
    var site_url = $("#site_url").html();
    var data = {
			"action" : "service-idioma",
			service: service
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){
      $("#langone .modal-body").html("");
      $.each( response, function( key, value ) {
        $("#langone .modal-body").append('<span id="from_'+value.id+'" class="badge badge-success custom_badge lenguagefrom">'+value.nombre+'</span>');
      });
    });


  }

  $("#selec_calidad").click(function(){

    if($(".btn_tservicio.disabled").attr("stype") == "correcion"){

      service = 2;

      $(".tidiomas").attr("servicio",service);

    }else if($(".btn_tservicio.disabled").attr("stype") == "traduccion"){

      service = 1;
      $(".tidiomas").attr("servicio",service);
    }

    $(".loader_grumer").show();

    var site_url = $("#site_url").html();
    var data = {
			"action" : "tipo-contenido",
			service: service
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){
      $(".showtipocont").html("");
      var ccs_activo = "";
      $.each( response, function( key, value ) {

        if(value.activo == 0){
          ccs_activo = "badge-warning";
        }else{
          ccs_activo = "badge-success";
        }

        $(".showtipocont").append('<span id="tipocontenido_'+value.id+'" class="badge '+ccs_activo+' custom_badge tipocontitem">'+value.nombre+'</span>');
      });
      $(".loader_grumer").hide();
    });

    $(".stepthree").hide();
    $(".stepfor").show();

  });

  $(document).on("click", ".tipocontitem" , function(){

    if($( this ).hasClass( "badge-warning" )==false){


      $(".stepfor").find(".badge-primary").removeClass("badge-primary");
      $(".stepfor").find(".badge").addClass("badge-success");

      $(this).removeClass("badge-success");
      $(this).addClass("badge-primary");

      var listo = $(this).attr("id").split("_");
      $(".ctraduccion").html("Tipo de contenido: "+$(this).html());
      $(".ctraduccion").attr("id",listo[1]);
      var site_url = $("#site_url").html();
      var data = {
  			"action" : "trabajo-pendiente",
  			id: listo[1],
        type: "tipocontitem"
  		};
      $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

        $(".costo_total span").html("Total "+response+" MXN");

      });

      $("#select_tipotraco").show();

    }else{
      $('#langcontact').modal('show');
    }

  });

  $("#atras_seleclang").click(function(){
    $(".stepfor").hide();
    $(".stepthree").show();
  });

  $("#atras_selecontenido").click(function(){
    $(".stepfive").hide();
    $(".stepfor").show();
  });

  $("#atras_seleservicio").click(function(){
    $(".stepsix").hide();
    $(".stepfive").show();
  });

  $("#atras_selecalidad").click(function(){
    $(".stepseven").hide();
    $(".stepsix").show();
  });

  $("#atras_seleformalidad").click(function(){
    $(".stepfinal").hide();
    $(".stepfive").show();
  });

  $("#select_tipotraco").click(function(){

    if($(".tidiomas").attr("servicio") == "2"){
      service = 2;
    }else if($(".tidiomas").attr("servicio") == "1"){
      service = 1;
    }

    $(".loader_grumer").show();

    var site_url = $("#site_url").html();
    var data = {
			"action" : "tipo-traco",
			service: service
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){
      $(".showtiptraco").html("");
      var tarjetitas = ""
      var ccs_activo = "";
      $.each( response, function( key, value ) {

        if(value.activo == 0){
          ccs_activo = "badge-warning";
        }else{
          ccs_activo = "badge-success";
        }

        //tarjetitas = tarjetitas + '<div id="tipotraco_'+value.id+'" class="card bg-light mb-3 tipotracoitem"><div class="card-header"><h5 class="card-title">'+value.nombre+'</h5></div><div class="card-body"><p class="card-text">'+value.info+'</p></div></div>';
        tarjetitas = tarjetitas + '<span id="tipotraco_'+value.id+'" class="badge '+ccs_activo+' custom_badge tipotracoitem">'+value.nombre+'</span>';
      });

      $(".showtiptraco").append(tarjetitas);

      $(".loader_grumer").hide();

    });

    $(".stepfor").hide();
    $(".stepfive").show();
  });

  $(document).on("click", ".tipotracoitem" , function() {

    if($( this ).hasClass( "badge-warning" )==false){

        $(".ctipotraco").html("");

        $(".stepfive").find(".badge-primary").removeClass("badge-primary");
        $(".stepfive").find(".badge").addClass("badge-success");

        $(this).removeClass("badge-success");
        $(this).addClass("badge-primary");

        var listo = $(this).attr("id").split("_");
        $(".ctipotraco").attr("id",listo[1]);

        var site_url = $("#site_url").html();
        var data = {
    			"action" : "trabajo-pendiente",
    			id: listo[1],
          type: "tipotracoitem"
    		};
        $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

          $(".costo_total span").html("Total "+response);

        });

        var addtipotraco = $("#tipotraco_"+listo[1]).html();
        $(".ctipotraco").append('Tipo de servicio: '+ addtipotraco);
        $("#select_traco").show();

    }else{

      $('#langcontact').modal('show');

    }

  });

  $("#select_traco").click(function(){

    if($(".tidiomas").attr("servicio") == "2"){
      service = 2;
    }else if($(".tidiomas").attr("servicio") == "1"){
      service = 1;
    }

    var site_url = $("#site_url").html();
    var data = {
			//"action" : "traco",
      "action" : "ccantpalabras",
			service: service
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

      /*$(".showtraco").html("");
      $.each( response, function( key, value ) {
        $(".showtraco").append('<span id="traco_'+value.id+'" class="badge badge-success custom_badge tracoitem">'+value.nombre+'</span>');
      });*/

      var diasdetrabajofinal = "";

      $(".ccantpalabras").html("Cantidad de palabras: ≤ "+response[0].rango_pre);
      $(".costo_total span").html("Total "+response[0].nuevoprecio+" MXN");

      /*if(response[0].tiempoentrega.d > 1){
        diasdetrabajofinal += response[0].tiempoentrega.d+" dias";
      }else if(response[0].tiempoentrega.d == 1){
        diasdetrabajofinal += response[0].tiempoentrega.d+" dia";
      }else{
        diasdetrabajofinal += "";
      }

      if(response[0].tiempoentrega.h > 1){
        diasdetrabajofinal += response[0].tiempoentrega.d+" horas";
      }else if(response[0].tiempoentrega.h > 1){
        diasdetrabajofinal += response[0].tiempoentrega.d+" hora";
      }else{
        diasdetrabajofinal += "";
      }*/

      $(".ctentrega").html("Tiempo de entrega: "+response[0].tiempoentrega+" hábiles");

    });


    //$(".stepsix").show();

    $(".stepfive").hide();
    $(".stepfinal").show();

  });

  $(document).on("click", ".tracoitem" , function() {
    $(".ctraco").html("");
    $(this).removeClass("badge-success");
    $(this).addClass("badge-primary");
    var listo = $(this).attr("id").split("_");
    $(".ctraco").append('Calidad: '+$(this).html());
    $("#select_fromalidad").show();
  });

  $("#select_fromalidad").click(function(){

    if($(".tidiomas").attr("servicio") == "2"){
      service = 2;
    }else if($(".tidiomas").attr("servicio") == "1"){
      service = 1;
    }

    var site_url = $("#site_url").html();
    var data = {
			"action" : "tipos-formalidad",
			service: service
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){
      $(".showformalidad").html("");
      $.each( response, function( key, value ) {
        $(".showformalidad").append('<span id="tformalidad_'+value.id+'" class="badge badge-success custom_badge tformalidaditem">'+value.nombre+'</span>');
      });
    });

    $(".stepsix").hide();
    $(".stepseven").show();
  });
  $(document).on("click", ".tformalidaditem" , function() {
    $(".cformalidad").html("");
    $(this).removeClass("badge-success");
    $(this).addClass("badge-primary");
    var listo = $(this).attr("id").split("_");
    $(".cformalidad").append('Formalidad: '+$(this).html());
    $("#select_comentariofinal").show();
  });
  $("#select_comentariofinal").click(function(){
    $(".stepseven").hide();
    $(".stepfinal").show();
    $(".btnpagar").removeClass("disabled");
  });

  //Esta funcion refresca el precio y tambien lo comunica a la base de datos
  $("#onlypalabras").on('show.bs.modal', function(){
   $("#onlypalabras").addClass("show");
  });
  $(".solopalabras").click(function(){

    $('#onlypalabras').modal('show');

  });

  $("#onlypalabras").on('hide.bs.modal', function(){
    $("#onlypalabras").removeClass("show");

    if($("#inputsolopalabras").val() > 0){
        $("#siguiente_text").trigger("click");
    }

  });

  $("#showTYC").on('show.bs.modal', function(){
   $("#showTYC").addClass("show");
  });
  $("#showTYC").on('hide.bs.modal', function(){
    $("#showTYC").removeClass("show");
  });

  $(".clickshowTYC").click(function(e){
    e.preventDefault();
    $("#showTYC").modal('show');

  });

  function valida_formc_postal(){

    var nombre_cliente = $("#nombre_cliente").val();
    var apellido_cliente = $("#apellido_cliente").val();
    var correo_cliente = $("#correo_cliente").val();
    var correoconfirm_cliente = $("#correoconfirm_cliente").val();

    if(nombre_cliente == null || nombre_cliente.length == 0 || /^\s+$/.test(nombre_cliente)){

      $("#nombre_cliente").css('border', '1px solid red');
      $('#nombre_cliente').tooltip({'trigger':'focus', 'title': 'El campo nombre no debe ir vacío o lleno de solamente espacios en blanco'});
      $('#nombre_cliente').tooltip("show");
      return false;

    }else{

      $("#nombre_cliente").css('border', '1px solid #ced4da');
      $('#nombre_cliente').tooltip("hide");

    }

    if(apellido_cliente == null || apellido_cliente.length == 0 || /^\s+$/.test(apellido_cliente)){

      $("#apellido_cliente").css('border', '1px solid red');
      $('#apellido_cliente').tooltip({'trigger':'focus', 'title': 'El campo nombre no debe ir vacío o lleno de solamente espacios en blanco'});
      $('#apellido_cliente').tooltip("show");
      return false;

    }else{

      $("#apellido_cliente").css('border', '1px solid #ced4da');
      $('#apellido_cliente').tooltip("hide");

    }


    if(!(/\S+@\S+\.\S+/.test(correo_cliente))){
      $("#correo_cliente").css('border', '1px solid red');
      $('#correo_cliente').tooltip({'trigger':'focus', 'title': 'Debe escribir un correo válido'});
      $('#correo_cliente').tooltip("show");
      return false;
    }else{
      $("#correo_cliente").css('border', '1px solid #ced4da');
      $('#correo_cliente').tooltip("hide");
    }

    if(!(/\S+@\S+\.\S+/.test(correoconfirm_cliente)) || correo_cliente != correoconfirm_cliente){
      $("#correoconfirm_cliente").css('border', '1px solid red');
      $('#correoconfirm_cliente').tooltip({'trigger':'focus', 'title': 'Debe escribir un correo válido'});
      $('#correoconfirm_cliente').tooltip("show");
      return false;
    }else{
      $("#correoconfirm_cliente").css('border', '1px solid #ced4da');
      $('#correoconfirm_cliente').tooltip("hide");
    }

    return true;

  }




  $('#checkbox_atyc').change(function() {

    if(this.checked) {

      if(valida_formc_postal() == true){

        $(".btnpagar").removeClass("disabled");
        $(".btnimpr").removeClass("disabled");

      }else{
        $('#checkbox_atyc').prop('checked', false);
      }

    }else{

      $(".btnpagar").addClass("disabled");
      $(".btnimpr").addClass("disabled");

    }



  });

  function forceDownload(href) {

			const a = document.createElement("a");
			a.style.display = "none";
			document.body.appendChild(a);


			a.href = href;

			a.setAttribute("download", "cotizacion.pdf");
      a.setAttribute("target", "_blank");


			a.click();


			document.body.removeChild(a);

  }


  $(".btnimpr").click(function(){

    var site_url = $("#site_url").html();

    var nombre_cliente = $("#nombre_cliente").val();
    var apellido_cliente = $("#apellido_cliente").val();
    var correo_cliente = $("#correo_cliente").val();
    var correoconfirm_cliente = $("#correoconfirm_cliente").val();
    var telefono = $("#telefono_cliente").val();

    var data = {
			"action" : "formpdf",
      nombre_cliente: nombre_cliente,
      apellido_cliente: apellido_cliente,
      correo_cliente: correo_cliente,
      correoconfirm_cliente: correoconfirm_cliente,
      telefono: telefono
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

      forceDownload(site_url+"/wp-content/plugins/grumer/impresos/files/"+response);
      //$("#form_pdf")[0].reset();

    });

  });


  $("#boton_pago_f").click(function(e){
    e.preventDefault();

    var site_url = $("#site_url").html();

    var nombre_cliente = $("#nombre_cliente").val();
    var apellido_cliente = $("#apellido_cliente").val();
    var correo_cliente = $("#correo_cliente").val();
    var correoconfirm_cliente = $("#correoconfirm_cliente").val();
    var telefono = $("#telefono_cliente").val();
    var instrucciones_cliente = $("#instrucciones_cliente").val();
    if($('#checkbox_arf').is(":checked"))
    {
      var factura = true;
    }else{
      var factura = false;
    }

    var data = {
			"action" : "formpdf",
      nombre_cliente: nombre_cliente,
      apellido_cliente: apellido_cliente,
      correo_cliente: correo_cliente,
      correoconfirm_cliente: correoconfirm_cliente,
      telefono: telefono,
      instrucciones_cliente: instrucciones_cliente,
      factura: factura
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

      //$("#form_pdf")[0].reset();
      window.location.href = $("#boton_pago_f").attr("href");

    });


  });

  function regenera_ultimo_estado(){

    alert("TU COMPRA NO FUE EXITOSA.");

    $(".stepone").hide();
    $(".stepfinal").show();

    var site_url = $("#site_url").html();
    var data = {
			"action" : "regenera_ultimo_estado"
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

      $.each( response, function( key, value ) {

        console.log(key);
        if(key == "stepfinal"){
          //step final
          $("#nombre_cliente").val(value.nombre);
          $("#apellido_cliente").val(value.apellido);
          $("#correo_cliente").val(value.mail);
          $("#correoconfirm_cliente").val(value.mail);
          $("#telefono_cliente").val(value.telefono);
          $("#instrucciones_cliente").html(value.instrucciones_cliente);

          if(value.factura == 0){
            $('#checkbox_arf').prop('checked', false);
          }else{
            $('#checkbox_arf').prop('checked', true);
          }

          $('#checkbox_atyc').prop('checked', false);

          $("#select_traco").show();

        }else if(key == "stepfive"){
          //step stepfive

          $(".showtiptraco").html("");
          var tarjetitas = ""
          var ccs_activo = "";
          $.each( value, function( key, value ) {

            if(value.activo == 0){
              ccs_activo = "badge-warning";
            }else if(value.selected == true){
              ccs_activo = "badge-primary";

              $(".ctipotraco").attr("id",value.id);
              $(".ctipotraco").html("Tipo de servicio: "+value.nombre);

            }else{
              ccs_activo = "badge-success";
            }

            //tarjetitas = tarjetitas + '<div id="tipotraco_'+value.id+'" class="card bg-light mb-3 tipotracoitem"><div class="card-header"><h5 class="card-title">'+value.nombre+'</h5></div><div class="card-body"><p class="card-text">'+value.info+'</p></div></div>';
            tarjetitas = tarjetitas + '<span id="tipotraco_'+value.id+'" class="badge '+ccs_activo+' custom_badge tipotracoitem">'+value.nombre+'</span>';
          });

          $(".showtiptraco").append(tarjetitas);

          $("#select_tipotraco").show();

        }else if(key == "stepfor"){
          //step stepfor

          $(".showtipocont").html("");
          var ccs_activo = "";
          $.each( value, function( key, value ) {

            if(value.activo == 0){
              ccs_activo = "badge-warning";
            }else if(value.selected == true){
              ccs_activo = "badge-primary";

              $(".ctraduccion").attr("id",value.id);
              $(".ctraduccion").html("Tipo de contenido: "+value.nombre);

            }else{
              ccs_activo = "badge-success";
            }

            $(".showtipocont").append('<span id="tipocontenido_'+value.id+'" class="badge '+ccs_activo+' custom_badge tipocontitem">'+value.nombre+'</span>');
          });

          $("#selec_calidad").show();

        }else if(key == "stepthree"){
          //step stepthree
          $(".tidiomas").attr("servicio",value.servicio);
          $(".tidiomas").attr("fromidioma",value.idioma_origen_id);

          $(".tidiomas").html(value.idioma_origen);
          $(".tidiomas").css("color","#28a745");

            $.each( value.idiomas_finales, function( key, value ) {

              $(".idioma_list").append('<span id="listo_'+value.idiomafinal_id+'" class="badge badge-success custom_badge">'+value.idioma_final+'</span>');

            });

          $(".ctentrega").html("Tiempo de entrega: "+value.tiempoentrega+" hábiles");

          $(".costo_total span").html("Total $"+value.nuevoprecio+" MXN");

          $(".table_all_languages").html(value.html_tabla);
          $(".table_all_languages").show();

          //$(".btn_all_languages_to").hide();
          $(".btn_all_languages_to_hidde").hide();

          $("#selec_idioma").show();
        }else if(key == "steptwo"){
          //step steptwo

          //var obj = JSON.parse(response);
          var totwords = 0;
          var alert_error = false;
          var num_itesm = 0;
          $( ".file_line" ).remove();
          $.each(value, function(i,item){


               var claseimg;
               if(item.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"){
                  claseimg = "icodocx";
               }else if(item.type == "application/pdf"){
                  claseimg = "icopdf";
               }else if(item.type == "application/msword"){
                  claseimg = "icoword";
               }

               totwords = totwords + parseInt(item.totalwords);
               $(".file_line_box").append('<div class="file_line"><div class="img_file '+claseimg+'"></div><span class="name_file">'+item.nombrefile+'</span><span class="size_file">'+item.totalwords+' palabras</span></div>');


               num_itesm++;


           });



           if(num_itesm > 1){
             label_Elementos = "Archivos";
           }else{
             label_Elementos = "Archivo";
           }

           if(totwords > 1){
             label_palabras = "palabras";
           }else{
             label_palabras = "palabra";
           }
           $(".file_line_box").append('<div class="file_line"><div class="img_file icofiles"></div><span class="name_file">'+num_itesm+' '+label_Elementos+'</span><span class="size_file">'+totwords+' '+label_palabras+'</span></div>');
           $("#selec_idioma").show();
           $("#del_all_files").show();

           $(".narticulo .items").html(num_itesm);
           $(".narticulo .npalabrasarticulo").html(totwords);
           $(".narticulo .labelarticulo").html(label_Elementos);
           $(".narticulo .labelpalabras").html(label_palabras);

        }




      });



    });

  }

  $(document).on("click", "#more_idio_cost" , function() {

    $("#langbtn_to").trigger( "click" );

  });

  $(document).on("click", ".delet_list_lang" , function() {

    $(".loader_grumer").show();

    $( "#listo_"+$(this).attr("id_lang_sel") ).remove();
    $("#to_"+$(this).attr("id_lang_sel")).removeClass("badge-primary");
    $("#to_"+$(this).attr("id_lang_sel")).addClass("badge-success");

    var idiomas_get_precios = new Array();
    $(".idioma_list span").each(function(){
        var id_precio_idioma = $(this).attr("id").split("_");
        idiomas_get_precios.push(id_precio_idioma[1]);
    });


    var site_url = $("#site_url").html();
    var data = {
			"action" : "del_land_list",
      idlangdel : $(this).attr("id_lang_sel"),
      fromidioma: $(".tidiomas").attr("fromidioma"),
      ididiomas: idiomas_get_precios
		};
    $.post(site_url+"/wp-admin/admin-ajax.php", data, function(response){

      $(".table_all_languages").html(response);
      $(".loader_grumer").hide();
      $(".table_all_languages").show();
      $(".costo_total span").html("Total "+$("#totalcompra_final").html());
      $("#selec_calidad").show();

    });

  });


});
