<?
function set_new_cookie() {

  if(isset($_COOKIE["userID"])){
    setcookie("userID",$_COOKIE["userID"],time() + (60*60*24*10),"/");
  }else{
    $userID = "tmp_".rand();
    setcookie("userID",$userID,time() + (60*60*24*10),"/");
  }
}
add_action( 'init', 'set_new_cookie');

function del_cookie() {
  $userID = "tmp_".rand();
  setcookie("userID",$userID,time() + (60*60*24*10),"/");
}
?>
