<?

function grumer_db_install() {

  global $wpdb;
  global $your_db_name;

  $your_db_name = $wpdb->prefix . 'archivos';

	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`usuarioID` varchar(200) NOT NULL,
		`fileurl` varchar(500) NOT NULL,
    `textotra` TEXT DEFAULT NULL,
    `totalwords` int(50) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'usuariosfile';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`usuarioTMP` varchar(200) NOT NULL,
		`mail` varchar(200) NOT NULL,
    `precioF` DOUBLE(11,2) NOT NULL,
    `precioCont` DOUBLE(11,2) NOT NULL,
    `precioTipotraco` DOUBLE(11,2) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'idiomas';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`idioma` varchar(200) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'idiomas_to';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`idiomafromID` int(11) NOT NULL,
    `idiomatoID` int(11) NOT NULL,
    `preciotraduccion` DOUBLE(11,2) NOT NULL,
    `servicio` int(11) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'tipocontenido';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`nombre` varchar(100) NOT NULL,
    `precio` DOUBLE(11,2) NOT NULL,
    `imagen` varchar(250) NOT NULL,
    `servicio` int(11) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'tipotraco';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`nombre` varchar(100) NOT NULL,
    `info` TEXT NULL,
    `precio` DOUBLE(11,2) NOT NULL,
    `servicio` int(11) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'traco';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`nombre` varchar(100) NOT NULL,
    `precio` DOUBLE(11,2) NOT NULL,
    `info` TEXT NULL,
    `servicio` int(11) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'paquetepalabras';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`cantidadpalabras` varchar(100) NOT NULL,
    `precio` DOUBLE(11,2) NOT NULL,
    `servicio` int(11) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'formalidadpalabra';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`nombre` varchar(100) NOT NULL,
    `servicio` int(11) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'trabajospendientes';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`usuarioID` int(11) NOT NULL,
    `servicioID` int(11) NOT NULL,
    `tipocontenidoID` int(11) NOT NULL,
    `tipotracoID` int(11) NOT NULL,
    `tracoID` int(11) NOT NULL,
    `paquetepalabrasID` int(11) NOT NULL,
    `formalidadpalabraID` int(11) NOT NULL,
    `comentarioFinal` LONGTEXT NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'fechaspuente';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
		`fecha` DATE NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

  $your_db_name = $wpdb->prefix . 'maxipalabras';
	if($wpdb->get_var("show tables like '$your_db_name'") != $your_db_name)
	{
		$sql = "CREATE TABLE " . $your_db_name . " (
		`id` bigint(20) NOT NULL AUTO_INCREMENT,
    `npalabras` int(11) NOT NULL,
		`precio` DOUBLE(11,2) NOT NULL,
    `servicio` int(11) NOT NULL,
    `activo` int(11) NOT NULL,
		UNIQUE KEY id (id)
		);";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

}
function myplugin_desactivate() {
  global $wpdb;
  //Borrar tabla de mysql
  //Elimina archivos
  $table_name=$wpdb->prefix.'archivos';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina usuariosfile
  $table_name=$wpdb->prefix.'usuariosfile';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina idiomas
  $table_name=$wpdb->prefix.'idiomas';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina idiomas_to
  $table_name=$wpdb->prefix.'idiomas_to';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina tipocontenido
  $table_name=$wpdb->prefix.'tipocontenido';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina tipotraco
  $table_name=$wpdb->prefix.'tipotraco';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina traco
  $table_name=$wpdb->prefix.'traco';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina paquetepalabras
  $table_name=$wpdb->prefix.'paquetepalabras';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina formalidadpalabra
  $table_name=$wpdb->prefix.'formalidadpalabra';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina trabajospendientes
  $table_name=$wpdb->prefix.'trabajospendientes';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina fechaspuente
  $table_name=$wpdb->prefix.'fechaspuente';
  $wpdb->query( "DROP TABLE $table_name");

  //Elimina maxipalabras
  $table_name=$wpdb->prefix.'maxipalabras';
  $wpdb->query( "DROP TABLE $table_name");
}

?>
