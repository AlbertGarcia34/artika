<?php
  require_once ('../../../wp-config.php');


  global $wpdb;

  $usuarioTMP = $_COOKIE['userID'];
  $usuarioID = $wpdb->get_results($wpdb->prepare(
    "
      SELECT *
      FROM ".$wpdb->prefix."usuariosfile
      WHERE usuarioTMP = %s
    ",
    $usuarioTMP
  ));

	//URL Paypal Modo pruebas.
	//$paypal_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
	//URL Paypal para Recibir pagos
	$paypal_url = 'https://www.paypal.com/cgi-bin/webscr';
	//Correo electronico del comercio.
  $merchant_email = 'yoalicrespo@consultoriagrumer.mx';
	//Pon aqui la URL para redireccionar cuando el pago es completado
	$cancel_return  = "https://www.consultoriagrumer.mx/cotiza_y_compra_en_linea/?response=false";
	//Colocal la URL donde se redicciona cuando el pago fue completado con exito.
	$success_return = "https://www.consultoriagrumer.mx/cotiza_y_compra_en_linea/?response=true";



?>
<div style="margin-left: 40%"><img src="img/processing_animation.gif"/>
<form name="myform" action="<?php echo $paypal_url; ?>" method="post" target="_top">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="cancel_return" value="<?php echo $cancel_return ?>">
<input type="hidden" name="return" value="<?php echo $success_return; ?>">
<input type="hidden" name="business" value="<?php echo $merchant_email; ?>">
<input type="hidden" name="lc" value="C2">
<input type="hidden" name="item_name" value="Compra de servicio">
<input type="hidden" name="item_number" value="<?php echo $product_id; ?>">
<input type="hidden" name="amount" value="<?php echo $usuarioID[0]->precioTipotraco;?>">
<input type="hidden" name="locale.x" value="es_XC">
<input type="hidden" name="lc" value="MX">
<input type="hidden" name="currency_code" value="MXN">
<input type="hidden" name="country" value="MX">
<input type="hidden" name="button_subtype" value="services">
<input type="hidden" name="no_note" value="0">
</form>
<script type="text/javascript">
  document.myform.submit();
</script>
<?php
