<?php
/**
* Plugin Name: Contador de palabras
* Plugin URI: http://farfalle.com.mx/
* Description: Este plugin permite contar palabras de un archivo.
* Version: 1.0
* Author: Oscar Aparicio Copyright (c) 2019 Copyright Holder All Rights Reserved.
* Author URI: http://farfalle.com.mx/
**/
define( 'GRUMMER__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

require_once( GRUMMER__PLUGIN_DIR . 'shortcode_core.php' );
require_once( GRUMMER__PLUGIN_DIR . 'functions_core.php' );
require_once( GRUMMER__PLUGIN_DIR . 'ajaxfunctions_core.php' );
require_once( GRUMMER__PLUGIN_DIR . '/cms/ajaxfunctions_cms_core.php' );
require_once( GRUMMER__PLUGIN_DIR . '/cms/cms_core.php' );

require_once( GRUMMER__PLUGIN_DIR . 'install_core.php' );
register_activation_hook(__FILE__,'grumer_db_install');
//register_deactivation_hook( __FILE__, 'myplugin_desactivate' );

?>
