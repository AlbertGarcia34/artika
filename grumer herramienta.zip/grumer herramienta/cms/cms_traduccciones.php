<?
add_action('admin_init', 'Grumer_idiomas_servicios_sampleoptions_init' );
add_action('admin_menu', 'Grumer_idiomas_servicios_sampleoptions_add_page');

function Grumer_idiomas_servicios_sampleoptions_init(){
	register_setting( 'Grumer_idiomas_servicios_sampleoptions_options', 'Grumer_idiomas_servicios_sample', 'Grumer_idiomas_servicios_sampleoptions_validate' );
}
function Grumer_idiomas_servicios_sampleoptions_add_page() {
	add_submenu_page('grumer_config_csm','Lista de traducciones', 'Traducciones', 'manage_options', "grumer_traduccion_csm", 'Grumer_idiomas_servicios_sampleoptions_de_page');
}
function Grumer_idiomas_servicios_sampleoptions_de_page(){

  wp_enqueue_script('jquery3', 'https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js');
  wp_enqueue_script('popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js');
  wp_enqueue_script('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js');

	wp_enqueue_script('dataTables', '//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js');

  wp_enqueue_script('fontawesome', 'https://kit.fontawesome.com/2e754cd8e3.js');
  wp_enqueue_script('corejs', plugins_url(). '/grumer/js/cms_core.js');

  wp_enqueue_style( 'bootstrap_styles', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' );
  wp_enqueue_style( 'styles_principal', plugins_url(). '/grumer/style/main.css' );

	wp_enqueue_style( 'dataTables_styles', '//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' );

  global $wpdb;
?>
<div id="site_url" style="display:none;"><?=get_site_url()?></div>
<h3>Traducciones  <i class="fas fa-plus-circle" data-toggle="modal" data-target="#modal_add"></i></h3>
<div class="container" style="margin-left: 0px;margin-right: 0px;">
<table id="dtHorizontal_traducciones" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#ID</th>
      <th scope="col">Idioma origen</th>
      <th scope="col">Idioma final</th>
      <th scope="col">Precio</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody class="items_cont">
<?
$traducciones = $wpdb->get_results("
    SELECT
       ift.`id` Idtraduccion,
       idi.`id` Ididiomafrom,
       idi.`idioma` idiomafrom,
       idi2.`id` Ididiomato,
       idi2.`idioma` idiomato,
       ift.`preciotraduccion` precio,
       ift.`activo` activo
    FROM `".$wpdb->prefix."idiomas_to` ift
    INNER JOIN ".$wpdb->prefix."idiomas idi ON ift.`idiomafromID` =  idi.`id`
    INNER JOIN ".$wpdb->prefix."idiomas idi2 ON ift.`idiomatoID` =  idi2.`id`
    WHERE ift.`servicio` = 1
");
foreach ( $traducciones as $res_traducciones )
{

		if($res_traducciones->activo == 0){
			$ccs_noactivo = "ccs_noactivo";
		}else{
			$ccs_noactivo = "";
		}

?>
    <tr id="row_cms_item_<?=$res_traducciones->Idtraduccion?>" tradactivo="<?=$res_traducciones->activo?>" class="<?=$ccs_noactivo?>">
      <th scope="row"><?=$res_traducciones->Idtraduccion?></th>
      <td id="<?=$res_traducciones->Ididiomafrom?>" class="traidifrom"><?=$res_traducciones->idiomafrom?></td>
      <td id="<?=$res_traducciones->Ididiomato?>" class="traidito"><?=$res_traducciones->idiomato?></td>
      <td class="traidiprecio"><?=$res_traducciones->precio?></td>
      <td>
        <span id="edit_cms_id_<?=$res_traducciones->Idtraduccion?>" class="action_edit_cms_trad"><i class="fas fa-edit"></i></span>
        <span id="delete_cms_id_<?=$res_traducciones->Idtraduccion?>" class="action_deleted_cms_trad"><i class="far fa-trash-alt"></i></span>
      </td>
    </tr>
<?
}
?>
  </tbody>
</table>
</div>

<div class="modal fade" id="modal_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Agregar traduccion</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <div class="form-group">
          <input type="hidden" class="idolditem_trad">
          <label for="idiomaorigen">Idioma Origen</label>
          <select class="form-control" id="idiomaorigen">
            <option value="0">Selecciona</option>
<?
$idiomas = $wpdb->get_results("
    SELECT id,idioma
    FROM ".$wpdb->prefix."idiomas
    WHERE activo = 1 ORDER BY idioma ASC
");
foreach ( $idiomas as $res_idiomas )
{
?>
            <option value="<?=$res_idiomas->id?>"><?=$res_idiomas->idioma?></option>
<?
}
?>
          </select>
        </div>

        <div class="form-group">
          <label for="idiomafinal">Idioma Final</label>
          <select class="form-control" id="idiomafinal">
            <option value="0">Selecciona</option>
<?
$idiomas = $wpdb->get_results("
    SELECT id,idioma
    FROM ".$wpdb->prefix."idiomas
    WHERE activo = 1 ORDER BY idioma ASC
");
foreach ( $idiomas as $res_idiomas )
{
?>
            <option value="<?=$res_idiomas->id?>"><?=$res_idiomas->idioma?></option>
<?
}
?>
          </select>
        </div>

        <div class="form-group">
          <label for="preciotraduccion">Precio</label>
          <input type="number" class="form-control" id="preciotraduccion" placeholder="00.00">
        </div>

        <div class="form-group">
          <label for="traduccionactivo">Activo</label>
          <select class="form-control" id="traduccionactivo">
            <option value="1">Si</option>
            <option value="0">No</option>
          </select>
        </div>

        <input type="hidden" class="idolditem_trad">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button id="save_new_item_trad" type="button" class="btn btn-primary">Guardar</button>
      </div>
    </div>
  </div>
</div>

<?
}
function Grumer_idiomas_servicios_sampleoptions_validate($input) {
	return $input;
}
