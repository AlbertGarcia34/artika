<?php

add_action('admin_init', 'Grumer_sampleoptions_init' );
add_action('admin_menu', 'Grumer_sampleoptions_add_page');

// Init plugin options to white list our options
function Grumer_sampleoptions_init(){
	register_setting( 'Grumer_sampleoptions_options', 'Grumer_sample', 'Grumer_sampleoptions_validate' );
}

// Add menu page

function Grumer_sampleoptions_add_page() {
	add_menu_page('Opciones de Tema', 'Grumer Home', 'manage_options', "grumer_config_csm", 'Grumer_sampleoptions_de_page');
}

// Draw the menu page itself
function Grumer_sampleoptions_de_page() {

  wp_enqueue_media();
	wp_register_script( 'mediamanager-image', get_template_directory_uri(). '/plugins/themeoptions/mediamanager.js', array( 'jquery' ) );
	wp_localize_script( 'mediamanager-image', 'meta_image',
		array(
			'title' => __( 'Selecciona o sube una imagen', 'cpi-textdomain' ),
			'button' => __( 'Usar esta imagen', 'cpi-textdomain' ),
		)
	);
	wp_enqueue_script( 'mediamanager-image' );

	wp_enqueue_style( 'cpi_meta_box_styles', get_template_directory_uri(). '/plugins/themeoptions/custom-post-images.css' );

	?>
	<div class="wrap">
		<h2>Grumer Home - Configuración del Homepage</h2>
		<form method="post" action="options.php">
			<?php settings_fields('Grumer_sampleoptions_options'); ?>
			<?php $options = get_option('Grumer_sample'); ?>
            <table class="form-table" style="width:670px;">

							<tr valign="top" style="background-color:#fff;">
									<td COLSPAN=2 style="text-align:center;"><label>Comunicación</label></td>
							</tr>
                <tr valign="top" style="background-color:#fff;">
                    <td COLSPAN=2 style="text-align:center;"><label>Contacto</label></td>
                </tr>
                <tr valign="top"  style="background-color:#efefef;"><th scope="row">Mail:</th>
                    <td style="float: left;"><input type="text" name="Grumer_sample[mail]" value="<?php echo $options['mail']; ?>"/></td>
                </tr>
                <tr valign="top"  style="background-color:#efefef;"><th scope="row">Telefono:</th>
                    <td style="float: left;"><input type="text" name="Grumer_sample[telco]" value="<?php echo $options['telco']; ?>"/></td>
                </tr>
								<tr valign="top" style="background-color:#fff;">
                    <td COLSPAN=2 style="text-align:center;"><label>Terminos y condiciones</label></td>
                </tr>
                <tr valign="top"  style="background-color:#efefef;"><th scope="row">Terminos y condiciones:</th>
                    <td style="float: left;"><textarea name="Grumer_sample[ytSos]" style="width: 500px;height: 400px;"><?php echo $options['ytSos']; ?></textarea></td>
                </tr>

			</table>
			<p class="submit">
			<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
			</p>
		</form>

	</div>
	<?php
}

// Sanitize and validate input. Accepts an array, return a sanitized array.
function Grumer_sampleoptions_validate($input) {
	return $input;
}

//Submenus

require_once( GRUMMER__PLUGIN_DIR . '/cms/cms_idiomas.php' );
require_once( GRUMMER__PLUGIN_DIR . '/cms/cms_traduccciones.php' );
require_once( GRUMMER__PLUGIN_DIR . '/cms/cms_tipo_servicio.php' );
require_once( GRUMMER__PLUGIN_DIR . '/cms/cms_tipo_contenido.php' );
require_once( GRUMMER__PLUGIN_DIR . '/cms/cms_tool_lang.php' );
require_once( GRUMMER__PLUGIN_DIR . '/cms/cms_tool_traslate.php' );
