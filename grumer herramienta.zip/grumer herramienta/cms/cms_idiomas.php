<?
add_action('admin_init', 'Grumer_idiomas_sampleoptions_init' );
add_action('admin_menu', 'Grumer_idiomas_sampleoptions_add_page');

function Grumer_idiomas_sampleoptions_init(){
	register_setting( 'Grumer_idiomas_sampleoptions_options', 'Grumer_idiomas_sample', 'Grumer_idiomas_sampleoptions_validate' );
}
function Grumer_idiomas_sampleoptions_add_page() {
	add_submenu_page('grumer_config_csm','Lista de idiomas', 'Idiomas', 'manage_options', "grumer_idioma_csm", 'Grumer_idiomas_sampleoptions_de_page');
}
function Grumer_idiomas_sampleoptions_de_page(){

  wp_enqueue_script('jquery3', 'https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js');
  wp_enqueue_script('popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js');
  wp_enqueue_script('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js');

	wp_enqueue_script('dataTables', '//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js');

  wp_enqueue_script('fontawesome', 'https://kit.fontawesome.com/2e754cd8e3.js');
  wp_enqueue_script('corejs', plugins_url(). '/grumer/js/cms_core.js');

  wp_enqueue_style( 'bootstrap_styles', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' );
  wp_enqueue_style( 'styles_principal', plugins_url(). '/grumer/style/main.css' );

	wp_enqueue_style( 'dataTables_styles', '//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' );

  global $wpdb;
?>
<div id="site_url" style="display:none;"><?=get_site_url()?></div>
<h3>Idiomas  <i class="fas fa-plus-circle" data-toggle="modal" data-target="#modal_add"></i></h3>
<div class="container" style="margin-left: 0px;margin-right: 0px;">
<table id="dtHorizontalExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#ID</th>
      <th scope="col">Idioma</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody class="items_cont">
<?
$idiomas = $wpdb->get_results("
    SELECT id,idioma
    FROM ".$wpdb->prefix."idiomas
   	ORDER BY idioma ASC
");
foreach ( $idiomas as $res_idiomas )
{
?>
    <tr id="row_cms_item_<?=$res_idiomas->id?>">
      <th scope="row"><?=$res_idiomas->id?></th>
      <td><?=$res_idiomas->idioma?></td>
      <td>
        <span id="edit_cms_id_<?=$res_idiomas->id?>" name_item="<?=$res_idiomas->idioma?>" class="action_edit_cms_lang"><i class="fas fa-edit"></i></span>
        <span id="delete_cms_id_<?=$res_idiomas->id?>" class="action_deleted_cms_lang"><i class="far fa-trash-alt"></i></span>
      </td>
    </tr>
<?
}
?>
  </tbody>
</table>
</div>

<div class="modal fade" id="modal_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Agregar idioma</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <div class="input-group">
          <input type="hidden" class="idolditem_lang">
          <div class="input-group-prepend">
            <span class="input-group-text" id="">Idioma</span>
          </div>
          <input type="text" class="form-control textnameidioma">
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button id="save_new_item_lang" type="button" class="btn btn-primary">Guardar</button>
      </div>
    </div>
  </div>
</div>

<?
}
function Grumer_idiomas_sampleoptions_validate($input) {
	return $input;
}
