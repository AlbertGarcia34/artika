<?
add_action( 'wp_ajax_nopriv_cms-idioma-control', 'cms_idioma_control' );
add_action( 'wp_ajax_cms-idioma-control', 'cms_idioma_control' );
function cms_idioma_control() {
  $jsontmp = array();
  $jsonfinal = array();
  global $wpdb;

  if( $_POST['type'] == "delete"){

    $preciotraduccion = $wpdb->get_results(
      "
        DELETE FROM ".$wpdb->prefix."idiomas
        WHERE id = ".$_POST['idlang']."
      "
    );
    $jsontmp[deleted] = "item_deleted";
    array_push($jsonfinal,$jsontmp);
    unset($jsontmp);

    header('Content-Type: application/json');
    echo json_encode($jsonfinal);

  }else if( $_POST['type'] == "add" ){

    $wpdb->insert( $wpdb->prefix.'idiomas',
      array(
        'idioma' => $_POST['idioma'],
        'activo' => 1
      )
    );
    $lastid = $wpdb->insert_id;

    $jsontmp[row] = '
    <tr id="row_cms_item_'.$lastid.'">
      <th scope="row">'.$lastid.'</th>
      <td>'.$_POST['idioma'].'</td>
      <td>
        <span id="edit_cms_id_'.$lastid.'" class="action_edit_cms_lang" name_item="'.$_POST['idioma'].'"><i class="fas fa-edit"></i></span>
        <span id="delete_cms_id_'.$lastid.'" class="action_deleted_cms_lang"><i class="far fa-trash-alt"></i></span>
      </td>
    </tr>';

    array_push($jsonfinal,$jsontmp);
    unset($jsontmp);

    header('Content-Type: application/json');
    echo json_encode($jsonfinal);

  }else if( $_POST['type'] == "edit" ){

    $wpdb->update(
    	$wpdb->prefix.'idiomas',
    	array(
    		'idioma' => $_POST['idioma']
    	),
    	array( 'id' => $_POST['id'] ),
    	array(
    		'%s'
    	),
    	array( '%d' )
    );

    $jsontmp[row] = '
    <tr id="row_cms_item_'.$_POST['id'].'">
      <th scope="row">'.$_POST['id'].'</th>
      <td>'.$_POST['idioma'].'</td>
      <td>
        <span id="edit_cms_id_'.$_POST['id'].'" class="action_edit_cms_lang" name_item="'.$_POST['idioma'].'"><i class="fas fa-edit"></i></span>
        <span id="delete_cms_id_'.$_POST['id'].'" class="action_deleted_cms_lang"><i class="far fa-trash-alt"></i></span>
      </td>
    </tr>';

    array_push($jsonfinal,$jsontmp);
    unset($jsontmp);

    header('Content-Type: application/json');
    echo json_encode($jsonfinal);


  }
  die(1);
}
add_action( 'wp_ajax_nopriv_cms-traduccion-control', 'cms_traduccion_control' );
add_action( 'wp_ajax_cms-traduccion-control', 'cms_traduccion_control' );
function cms_traduccion_control() {
  $jsontmp = array();
  $jsonfinal = array();
  global $wpdb;

  if( $_POST['type'] == "delete"){

    $preciotraduccion = $wpdb->get_results(
      "
        DELETE FROM ".$wpdb->prefix."idiomas_to
        WHERE id = ".$_POST['idtrad']."
      "
    );
    echo "item_deleted";
    die(1);

  }else if( $_POST['type'] == "add" ){

    $wpdb->insert( $wpdb->prefix.'idiomas_to',
      array(
        'idiomafromID' => $_POST['idioma1'],
        'idiomatoID' => $_POST['idioma2'],
        'preciotraduccion' => $_POST['precio'],
        'servicio' => 1,
        'activo' => $_POST['activo']
      )
    );
    $lastid = $wpdb->insert_id;

    $idioma1 = $wpdb->get_var("
        SELECT idioma
        FROM ".$wpdb->prefix."idiomas
        WHERE id ='".$_POST['idioma1']."' AND activo = 1
    ");

    $idioma2 = $wpdb->get_var("
        SELECT idioma
        FROM ".$wpdb->prefix."idiomas
        WHERE id ='".$_POST['idioma2']."' AND activo = 1
    ");

    $jsontmp[row] = '
    <tr id="row_cms_item_'.$lastid.'" tradactivo="'.$_POST['activo'].'">
      <th scope="row">'.$lastid.'</th>
      <td id="'.$_POST['idioma1'].'" class="traidifrom">'.$idioma1.'</td>
      <td id="'.$_POST['idioma2'].'" class="traidito">'.$idioma2.'</td>
      <td class="traidiprecio">'.$_POST['precio'].'</td>
      <td>
        <span id="edit_cms_id_'.$lastid.'" class="action_edit_cms_trad"><i class="fas fa-edit"></i></span>
        <span id="delete_cms_id_'.$lastid.'" class="action_deleted_cms_trad"><i class="far fa-trash-alt"></i></span>
      </td>
    </tr>';

    array_push($jsonfinal,$jsontmp);
    unset($jsontmp);

    header('Content-Type: application/json');
    echo json_encode($jsonfinal);
    die(1);

  }else if( $_POST['type'] == "edit" ){

    $wpdb->update(
      $wpdb->prefix.'idiomas_to',
      array(
        'idiomafromID' => $_POST['idioma1'],
        'idiomatoID' => $_POST['idioma2'],
        'preciotraduccion' => $_POST['precio'],
        'activo' => $_POST['activo']
      ),
      array( 'id' => $_POST['id'] ),
      array(
        '%d',
        '%d',
        '%f',
        '%d'
      ),
      array( '%d' )
    );

    $idioma1 = $wpdb->get_var("
        SELECT idioma
        FROM ".$wpdb->prefix."idiomas
        WHERE id ='".$_POST['idioma1']."' AND activo = 1
    ");

    $idioma2 = $wpdb->get_var("
        SELECT idioma
        FROM ".$wpdb->prefix."idiomas
        WHERE id ='".$_POST['idioma2']."' AND activo = 1
    ");

    $jsontmp[row] = '
    <tr id="row_cms_item_'.$_POST['id'].'" tradactivo="'.$_POST['activo'].'">
      <th scope="row">'.$_POST['id'].'</th>
      <td id="'.$_POST['idioma1'].'" class="traidifrom">'.$idioma1.'</td>
      <td id="'.$_POST['idioma2'].'" class="traidito">'.$idioma2.'</td>
      <td class="traidiprecio">'.$_POST['precio'].'</td>
      <td>
        <span id="edit_cms_id_'.$_POST['id'].'" class="action_edit_cms_trad"><i class="fas fa-edit"></i></span>
        <span id="delete_cms_id_'.$_POST['id'].'" class="action_deleted_cms_trad"><i class="far fa-trash-alt"></i></span>
      </td>
    </tr>';

    array_push($jsonfinal,$jsontmp);
    unset($jsontmp);

    header('Content-Type: application/json');
    echo json_encode($jsonfinal);
    die(1);

  }
}
?>
