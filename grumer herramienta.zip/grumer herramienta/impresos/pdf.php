<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>

<div style="margin:0 auto;width: 700px; font-size:12px;">

  <div style="text-align: center;">Logo</div>
  <div style="text-align: right;margin-right: 70px;">día de mes de año</div>

  <div style="text-align: left;margin-left: 70px; margin-top: 40px;">En atención a: nombre de la persona</div>
  <div style="text-align: left;margin-left: 70px; margin-top: 15px;">Concepto: Traducción/corrección de idioma original a idioma meta/[nada para corrección]</div>

<div style="text-align: center; margin-top: 15px;">
<table style="border: 1px solid #92D050; border-collapse: collapse; margin-left: 125px; font-size:12px;">
  <tr>
    <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">SERVICIO</th>
    <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">IDIOMA</th>
    <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">PRECIO UNITARIO</th>
    <th style="border: 1px solid #92D050;  background-color: #92D050; color: #fff; border-collapse: collapse; width: 115px;height: 35px; font-size:12px;">PRECIO TOTAL</th>
  </tr>
  <tr>
    <td style="border: 1px solid #92D050; border-collapse: collapse;">test</td>
    <td style="border: 1px solid #92D050; border-collapse: collapse;">test</td>
    <td style="border: 1px solid #92D050; border-collapse: collapse;">50</td>
    <td style="border: 1px solid #92D050; border-collapse: collapse;">50</td>
  </tr>
</table>
</div>

<div style="text-align: left;margin-left: 70px; margin-top: 15px;"><span style="color:#0070C0;">Tiempo de entrega máximo:</span> formato en horas totales</div>

<div style="text-align: left;margin-left: 70px; margin-top: 15px; color:#0070C0;">Consideraciones del servicio:</div>

<div style="text-align: left;margin-left: 70px; margin-top: 15px;">

  <ul>
    <li>Estos precios no incluyen impuestos.</li>
    <li>Cotización válida por 30 días hábiles.</li>
    <li>Hasta dos revisiones por parte del cliente.</li>
    <li>Por defecto se utilizan manuales de estilo y glosarios estándar salvo se proporcione uno por parte del cliente.</li>
    <li>El tiempo de entrega puede cambiar a petición del cliente sujeto a cambios en las tarifas.</li>
    <li>No incluye costos de diseño, maquetación ni traducción de imágenes. En caso de ser necesarios, deben de solicitarse por aparte y están sujetos a cambios en las tarifas.</li>
    <li>El servicio no es certificado ante perito. En caso de ser necesario, debe de solicitarse por aparte y está sujeto a cambios en las tarifas. </li>
    <li>Esquema de pagos sugerido: revisar con cliente.</li>
  </ul>

</div>

<div style="text-align: left;margin-left: 70px; margin-top: 15px;">Calidad en el servicio</div>

<p style="margin-left: 70px;">
  Las mejores traducciones son aquellas en las que un cliente nos proporciona sus listas terminológicas, glosarios, manuales de estilo, pero sobre todo contexto e instrucciones claras. La calidad de las traducciones depende de varios factores. Nuestros servicios de traducción están diseñados para documentos profesionales y personales.
</p>

<div style="text-align: center;">Acuerdo de confidencialidad</div>


<p style="margin-left: 70px;">
Grumer Grupo Mexicano de Redacción, S.C. (“Grumer”) es una persona moral debidamente constituida de conformidad con las leyes mexicanas y tiene por negocio principal la prestación de servicios profesionales de consultoría y asesoría en redacción, edición y traducción de todo tipo de textos y en cualquier idioma; así como diseñar, editar, imprimir, publicar, vender, importar, exportar, consignar y distribuir toda clase de libros, catálogos, reproducciones y todo tipo de publicaciones, incluyendo, de forma enunciativa mas no limitativa, todo tipo de revistas de interés general; así como cualquier texto susceptible de ser editado en formato digital.
</p>


<div style="text-align: left;margin-left: 70px; margin-top: 15px;">Considerando lo anterior:</div>

<div style="text-align: left;margin-left: 70px; margin-top: 15px;">

  <ul>
    <li>Grumer se compromete a salvaguardar la Información Confidencial a la que tenga acceso con motivo de una posible prestación de servicios a un cliente determinado (“Posible Negocio”), impidiendo y evitando su sustracción, destrucción, ocultamiento, inutilización, divulgación o alteración total o parcial, así como su uso para cualquier otro fin no relacionado con la posible transacción que Posible Negocio, manteniéndola bajo el mismo nivel de cuidado que le aplicaría a su propia Información Confidencial.<br/><br/></li>
    <li>Para efectos del presente Aviso de Confidencialidad, se considera como “Información Confidencial” toda aquella información proporcionada de forma escrita, verbal o gráfica en cualquier tipo de medio impreso, electrónico o electromagnético, que se identifique con tal carácter y que, con motivo de un Posible Negocio, sea proporcionada a Grumer.
      <br/>
      <br/>
      Dentro de este tipo de información se incluye, de manera enunciativa más no limitativa, propiedad intelectual, derechos de autor, secretos industriales o, en general, cualquier información que, de divulgarse, pudiera ocasionar un daño en la posición competitiva o económica del cliente, y respecto de la cual hayan adoptado los medios o sistemas suficientes para preservar su confidencialidad y el acceso restringido a la misma; así como aquella que se encuentra protegida por la legislación, reglamentos y demás disposiciones legales aplicables, conforme a los cuales ningún tercero puede, sin autorización previa, divulgar o utilizar la referida Información Confidencial, en provecho propio o de terceros.
      <br/>
      <br/>
    </li>

    <li>
      Grumer no tendrá obligación alguna de mantener como confidencial la información a que se refiere este Aviso de Confidencialidad cuando la Información Confidencial encuadre en los siguientes supuestos:<br/>
      <ul>
        <li>Que se halle en registros o fuentes de acceso públicos;</li>
        <li>Que previamente a su divulgación, la Información Confidencial fuera conocida por Grumer libre de cualquier obligación de mantenerla como Información Confidencial, según se evidencie por documentación que posea;</li>
        <li>Que se haga pública durante la vigencia del Posible Negocio sin que medie violación a este Aviso de Confidencialidad, o</li>
        <li>Que haya sido obtenida legalmente de un tercero, siempre que este no haya violado alguna obligación de confidencialidad de la que Grumer tenga conocimiento para su obtención o divulgación.</li>
      </ul>
    </li>
  </ul>

</div>

<div style="text-align: left;margin-left: 70px; margin-top: 15px;">

  <ul>
    <li>Grumer reconoce que la Información Confidencial del cliente es de su propiedad exclusiva. En ninguna circunstancia se entenderá que exista una transmisión de propiedad de la Información Confidencial respecto de la que Grumer tenga acceso en virtud del Posible Negocio.<br/><br/></li>
    <li>Grumer reconoce que el acceso que tenga a Información Confidencial del cliente con motivo de un Posible Negocio no le confiere derecho, autorización, permiso, o licencia de propiedad industrial o intelectual alguna.<br/><br/></li>

    <li>
      Grumer sólo podrá revelar la Información Confidencial proporcionada por el cliente a sus empleados, prestadores de servicios, agentes, asesores, representantes o personas que la requieran de manera justificada y únicamente para los fines relacionados con el Posible Negocio.
      <br/><br/>
      Grumer hará que sus empleados, prestadores de servicios, agentes, asesores, representantes o personas que la requieran de manera justificada que tengan acceso o conocimiento de la Información Confidencial, la guarden y mantengan bajo dicho carácter, cumpliendo con las obligaciones de confidencialidad que aquí se estipulan. Lo anterior, en el entendido que, en caso de ser necesario, celebrará todos aquellos convenios de confidencialidad que resulten necesarios a fin de que sus empleados, prestadores de servicios o representantes protejan la Información Confidencial.
    </li>
  </ul>

</div>

</div>

</body>
</html>
